#!/usr/bin/env python3
"""
Servidor WebSocket mock do protocolo v1 (Docs/Contracts.md §6.1).
Ferramenta de desenvolvimento: não faz parte do jogo (decisão D12).

Uso:
  pip install websockets
  python mock_server.py                               # entrega builds/reference.json após o handshake
  python mock_server.py --build builds/incompatible_psu.json
  python mock_server.py --scenario malformed          # envia JSON inválido dentro do payload
  python mock_server.py --scenario oversize           # mensagem > 64 KiB (cliente deve fechar com 1009)
  python mock_server.py --scenario silent             # não responde pings (cliente deve dar Timeout)
  python mock_server.py --scenario no-hello           # não completa o handshake
  python mock_server.py --scenario duplicate          # entrega a mesma build duas vezes (2ª = DuplicateBuild)
"""
import argparse
import asyncio
import json
import pathlib
import time
import uuid

import websockets

HERE = pathlib.Path(__file__).parent


def envelope(msg_type: str, payload: dict, request_id: str | None = None) -> str:
    return json.dumps({
        "type": msg_type,
        "version": 1,
        "requestId": request_id or str(uuid.uuid4()),
        "timestamp": int(time.time()),
        "payload": payload,
    })


def log(direction: str, text: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {direction} {text}", flush=True)


async def handle(ws, args) -> None:
    peer = getattr(ws, "remote_address", "?")
    log("++", f"cliente conectado {peer}")
    build = json.loads(pathlib.Path(args.build).read_text(encoding="utf-8"))
    delivered = 0

    async for raw in ws:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            log("!!", f"JSON inválido do cliente: {raw[:120]}")
            continue

        msg_type = msg.get("type")
        log("<-", f"{msg_type} {json.dumps(msg.get('payload'))[:160]}")

        if msg_type == "connection.hello":
            if args.scenario == "no-hello":
                continue
            await ws.send(envelope("connection.hello", {"serverVersion": "mock-1.0", "sessionId": str(uuid.uuid4())}))
            log("->", "connection.hello")
            await asyncio.sleep(args.delay)

            if args.scenario == "malformed":
                await ws.send('{"type":"build.deliver","version":1,"requestId":"%s","timestamp":1,"payload":{"schemaVersion":1,' % uuid.uuid4())
                log("->", "build.deliver (malformado)")
            elif args.scenario == "oversize":
                await ws.send(envelope("build.deliver", {"padding": "x" * 70000}))
                log("->", "build.deliver (> 64 KiB)")
            else:
                repeats = 2 if args.scenario == "duplicate" else 1
                for _ in range(repeats):
                    await ws.send(envelope("build.deliver", build))
                    delivered += 1
                    log("->", f"build.deliver #{delivered} buildId={build.get('buildId')}")

        elif msg_type == "ping":
            if args.scenario == "silent":
                continue
            await ws.send(envelope("pong", {}, msg.get("requestId")))
            log("->", "pong")

        elif msg_type in ("build.ack", "build.error"):
            pass  # já registrado acima

    log("--", f"cliente desconectou {peer}")


async def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--build", default=str(HERE / "builds" / "reference.json"))
    parser.add_argument("--delay", type=float, default=1.0, help="segundos entre o handshake e a entrega")
    parser.add_argument("--scenario", default="valid",
                        choices=["valid", "malformed", "oversize", "silent", "no-hello", "duplicate"])
    args = parser.parse_args()

    async with websockets.serve(lambda ws: handle(ws, args), args.host, args.port, max_size=None):
        log("**", f"mock ouvindo em ws://{args.host}:{args.port} cenário={args.scenario}")
        await asyncio.Future()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
