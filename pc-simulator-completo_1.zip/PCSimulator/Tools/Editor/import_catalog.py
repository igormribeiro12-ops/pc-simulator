"""
Importa Data/Catalog/components_2026.json para DataAssets dentro da Unreal.

Como usar (no editor da Unreal, com o projeto aberto):
  Tools > Execute Python Script... > escolha este arquivo.
Pode rodar de novo quando o catálogo mudar: atualiza os assets existentes em vez de duplicar.

Cria /Game/PC/Components/<Tipo>/DA_<id>. Se o Blueprint BP_<Tipo> já existir em /Game/PC/Blueprints,
ele é ligado como ActorClass; senão o campo fica vazio (o Data Validation vai avisar).
"""
import json
import os

import unreal

PROJECT_DIR = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_dir())
CATALOG = os.path.join(PROJECT_DIR, "Data", "Catalog", "components_2026.json")

TYPES = {
    "Component.CPU": ("CPU", unreal.PCCPUDataAsset),
    "Component.GPU": ("GPU", unreal.PCGPUDataAsset),
    "Component.Motherboard": ("Motherboard", unreal.PCMotherboardDataAsset),
    "Component.RAM": ("RAM", unreal.PCRAMDataAsset),
    "Component.Storage": ("SSD", unreal.PCStorageDataAsset),
    "Component.PSU": ("PSU", unreal.PCPSUDataAsset),
    "Component.Case": ("Case", unreal.PCCaseDataAsset),
    "Component.Fan": ("Fan", unreal.PCFanDataAsset),
}

tag = unreal.PCEditorScriptingLibrary.make_tag
tags = unreal.PCEditorScriptingLibrary.make_tag_container


def set_prop(asset, names, value):
    """Tenta o nome Python (snake_case) e depois o nome C++; avisa se nenhum existir."""
    for name in names:
        try:
            asset.set_editor_property(name, value)
            return
        except Exception:
            continue
    unreal.log_warning(f"[catálogo] {asset.get_name()}: propriedade {names[0]} não encontrada")


def get_or_create(folder, asset_name, cls):
    path = f"/Game/PC/Components/{folder}"
    full = f"{path}/{asset_name}"
    if unreal.EditorAssetLibrary.does_asset_exist(full):
        return unreal.EditorAssetLibrary.load_asset(full)
    factory = unreal.DataAssetFactory()
    factory.set_editor_property("data_asset_class", cls)
    return unreal.AssetToolsHelpers.get_asset_tools().create_asset(asset_name, path, cls, factory)


def apply(asset, c):
    set_prop(asset, ["component_id", "ComponentId"], unreal.Name(c["id"]))
    set_prop(asset, ["type", "Type"], tag(c["type"]))
    set_prop(asset, ["display_name", "DisplayName"], c["name"])
    set_prop(asset, ["reference_price_usd", "ReferencePriceUsd"], float(c.get("priceUsd") or 0))
    set_prop(asset, ["power_draw_watts", "PowerDrawWatts"], int(c.get("watts", 0)))
    if c.get("socket"):
        set_prop(asset, ["required_socket", "RequiredSocket"], tag(c["socket"]))
    if c.get("recommendedPsu"):
        set_prop(asset, ["recommended_psu_watts", "RecommendedPsuWatts"], int(c["recommendedPsu"]))

    t = c["type"]
    if t == "Component.CPU":
        set_prop(asset, ["cores", "Cores"], c["cores"])
        set_prop(asset, ["threads", "Threads"], c["threads"])
    elif t == "Component.GPU":
        set_prop(asset, ["length_mm", "LengthMm"], c["lengthMm"])
        set_prop(asset, ["power_connectors", "PowerConnectors"], tags(c["powerConnectors"]))
    elif t == "Component.Motherboard":
        set_prop(asset, ["cpu_socket", "CpuSocket"], tag(c["cpuSocket"]))
        set_prop(asset, ["ram_socket", "RamSocket"], tag(c["ramSocket"]))
        set_prop(asset, ["ram_slot_count", "RamSlotCount"], c["ramSlots"])
        set_prop(asset, ["form_factor", "FormFactor"], tag(c["formFactor"]))
        set_prop(asset, ["pcie_x16_slots", "PcieX16Slots"], c["pcieX16Slots"])
        set_prop(asset, ["m2_slots", "M2Slots"], c["m2Slots"])
    elif t == "Component.RAM":
        set_prop(asset, ["module_count", "ModuleCount"], c["modules"])
        set_prop(asset, ["capacity_per_module_gb", "CapacityPerModuleGB"], c["gbPerModule"])
        set_prop(asset, ["speed_m_ts", "speed_mts", "SpeedMTs"], c["speedMTs"])
    elif t == "Component.Storage":
        set_prop(asset, ["capacity_gb", "CapacityGB"], c["capacityGb"])
    elif t == "Component.PSU":
        set_prop(asset, ["capacity_watts", "CapacityWatts"], c["capacityWatts"])
        set_prop(asset, ["efficiency", "Efficiency"], c["efficiency"])
        set_prop(asset, ["connectors", "Connectors"], tags(c["connectors"]))
    elif t == "Component.Case":
        set_prop(asset, ["supported_form_factors", "SupportedFormFactors"], tags(c["formFactors"]))
        set_prop(asset, ["max_gpu_length_mm", "MaxGpuLengthMm"], c["maxGpuLengthMm"])
        set_prop(asset, ["fan_slots", "FanSlots"], c["fanSlots"])
    elif t == "Component.Fan":
        set_prop(asset, ["size_mm", "SizeMm"], c["sizeMm"])


def main():
    with open(CATALOG, encoding="utf-8") as f:
        catalog = json.load(f)

    created = 0
    with unreal.ScopedSlowTask(len(catalog["components"]), "Importando catálogo de peças") as task:
        task.make_dialog(True)
        for c in catalog["components"]:
            if task.should_cancel():
                break
            task.enter_progress_frame(1, c["name"])

            folder, cls = TYPES[c["type"]]
            asset = get_or_create(folder, f"DA_{c['id']}", cls)
            if not asset:
                unreal.log_error(f"[catálogo] falhou ao criar {c['id']}")
                continue

            apply(asset, c)

            bp = f"/Game/PC/Blueprints/BP_{folder}"
            if unreal.EditorAssetLibrary.does_asset_exist(bp):
                set_prop(asset, ["actor_class", "ActorClass"], unreal.EditorAssetLibrary.load_blueprint_class(bp))

            unreal.EditorAssetLibrary.save_loaded_asset(asset)
            created += 1

    unreal.log(f"[catálogo] {created} peças importadas de {catalog['snapshotDate']}.")


main()
