# PC Simulator

Simulador 3D de montagem de PC em Unreal Engine com gameplay 100% em C++.

| Item | Valor |
|---|---|
| Engine | Unreal Engine **5.4** (registrar o hotfix exato aqui ao abrir o projeto, ex.: `5.4.4`) |
| Linguagem | C++20 (padrão do UBT na 5.4) |
| Plataforma | Windows 64-bit, standalone, single-player |
| IDE | Visual Studio 2022, com as cargas "Desenvolvimento para jogos com C++" e ".NET desktop" |
| Versão | 0.2.0 (código das fases 1–19; ver `Docs/ImplementationNotes.md`) |

Documentação: [`Architecture`](Docs/Architecture.md) · [`Contracts`](Docs/Contracts.md) · [`ImplementationNotes`](Docs/ImplementationNotes.md) (status, desvios, assets pendentes) · [`PROMPT_MESTRE_v2`](Docs/PROMPT_MESTRE_v2.md)

## Não-objetivos (v1)

- Multiplayer, co-op ou replicação.
- Editor de builds embutido no jogo.
- Modelos 3D finais antes da fase de modelos (placeholders até lá).
- VR, conquistas, loja, monetização.
- Física realista de encaixe (snap assistido).
- Cabos com física (são conexões lógicas).
- Mais de uma unidade do mesmo tipo, exceto kits de RAM.
- Sincronização de relógio com o servidor.

## Estrutura

```
PCSimulator.uproject
Config/                  DefaultEngine.ini, DefaultInput.ini, DefaultGame.ini
Source/
  PCSimulator.Target.cs         Game (Development/Shipping)
  PCSimulatorEditor.Target.cs   Editor (+ módulo de testes)
  PCSimulator/                  módulo de runtime (camadas por pasta)
  PCSimulatorTests/             specs Unit / Functional / Integration (somente editor)
Tools/MockServer/        servidor WebSocket mock + builds de exemplo
Docs/                    arquitetura, contratos, schema, notas
```

## Catálogo de peças (2026)

95 peças reais e atuais em `Data/Catalog/components_2026.json` (lista legível em [`Docs/Catalogo2026.md`](Docs/Catalogo2026.md)). Para criá-las dentro da Unreal: **Tools → Execute Python Script → `Tools/Editor/import_catalog.py`**. O importador cria uma ficha (DataAsset) por peça e pode ser rodado de novo quando o catálogo mudar.

## Controles

| Tecla | Ação |
|---|---|
| WASD | Desloca a câmera sobre a bancada |
| Mouse | Orbita |
| Roda | Zoom |
| Botão esquerdo | Pegar / instalar / ligar cabo / abrir-fechar painel |
| Botão direito | Soltar |
| Q / E | Girar a peça 15° |
| F | Inspecionar |
| P | Ligar o PC |

## Console (dev)

- `PC.LoadBuildFile <caminho.json>`: injeta uma build pelo mesmo pipeline da rede.
- `PCResetSession`: limpa a montagem e volta a aguardar uma build.

## Primeira abertura (Fase 1)

1. Clique com o botão direito em `PCSimulator.uproject` → **Generate Visual Studio project files**.
2. Abra `PCSimulator.sln` e compile **Development Editor | Win64**.
3. Abra o projeto e crie os assets da tabela abaixo e os de `Docs/ImplementationNotes.md` §3–§4 (DataAssets, slots, HUD, sons, materiais).

### Assets a criar no editor

| Asset | Caminho | Configuração |
|---|---|---|
| `IA_Move` | `/Game/PC/Input/Actions` | Value Type **Axis2D** |
| `IA_Look` | idem | **Axis2D** |
| `IA_Zoom` | idem | **Axis1D** |
| `IA_Rotate` | idem | **Axis1D** |
| `IA_Interact`, `IA_Drop`, `IA_Inspect`, `IA_Power` | idem | **Digital (bool)** |
| `IMC_Default` | `/Game/PC/Input` | ver mapeamentos abaixo |
| `BP_PCPlayerController` | `/Game/PC/Core` | pai `PCPlayerController`; atribuir o IMC e as 8 IAs |
| `BP_PCGameMode` | `/Game/PC/Core` | pai `PCGameMode`; Player Controller Class = `BP_PCPlayerController` |
| `L_Sandbox` | `/Game/PC/Maps` | chão, luz direcional, Sky Atmosphere, um cubo como bancada e um **Player Start** |

**Mapeamentos sugeridos em `IMC_Default`:**

| Ação | Tecla | Modificadores |
|---|---|---|
| IA_Move | W / S | W: *Swizzle Input Axis Values* (YXZ). S: *Swizzle* + *Negate* |
| IA_Move | D / A | A: *Negate* |
| IA_Look | Mouse XY 2D-Axis | *Negate* só no Y, se quiser a órbita invertida |
| IA_Zoom | Mouse Wheel Axis | — |
| IA_Rotate | E / Q | Q: *Negate* |
| IA_Interact | Left Mouse Button | — |
| IA_Drop | Right Mouse Button | — |
| IA_Inspect | F | — |
| IA_Power | P | — |

## Build de linha de comando

```bat
:: Editor
"%UE_ROOT%\Engine\Build\BatchFiles\Build.bat" PCSimulatorEditor Win64 Development -Project="%CD%\PCSimulator.uproject" -WaitMutex

:: Shipping empacotado
"%UE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat" BuildCookRun -project="%CD%\PCSimulator.uproject" -noP4 -platform=Win64 -clientconfig=Shipping -build -cook -stage -pak -archive -archivedirectory="%CD%\Dist"
```

## Testes

```bat
"%UE_ROOT%\Engine\Binaries\Win64\UnrealEditor-Cmd.exe" "%CD%\PCSimulator.uproject" -ExecCmds="Automation RunTests PCSimulator" -TestExit="Automation Test Queue Empty" -unattended -nopause -NullRHI -ReportExportPath="%CD%\Saved\TestReports"
```

Suítes: `PCSimulator.Unit.*` (Json, Network, Compatibility, Catalog, Tags, Ids, FSM, SlotMath, Camera.OrbitMath, Core.Defaults), `PCSimulator.Functional.Assembly`, `PCSimulator.Integration.BuildToBoot`.

Os testes funcionais e de integração criam o próprio mundo; se algum exigir RHI, rode sem `-NullRHI`.

## Servidor mock

```bat
pip install -r Tools\MockServer\requirements.txt
python Tools\MockServer\mock_server.py            :: entrega builds\reference.json
```
Cenários de erro: `Docs/ImplementationNotes.md` §5.
