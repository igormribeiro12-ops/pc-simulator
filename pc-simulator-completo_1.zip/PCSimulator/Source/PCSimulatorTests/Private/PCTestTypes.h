﻿#pragma once

#include "CoreMinimal.h"
#include "Compatibility/PCCompatibilityRule.h"
#include "GameplayTagContainer.h"
#include "PCTestTypes.generated.h"

class AComputerComponent;

/** Regra de teste: prova que uma regra nova funciona sem alterar UPCCompatibilitySystem. */
UCLASS(NotBlueprintable, HideDropdown)
class UPCTestAlwaysFailRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override
	{
		Out = FCompatibilityResult::Fail(FGameplayTag::RequestGameplayTag(TEXT("AssemblyError.Incompatible")),
			FText::FromString(TEXT("TestAlwaysFail")));
		return false;
	}
};

/** Captura eventos dinâmicos do AssemblySystem nos testes. */
UCLASS(NotBlueprintable, HideDropdown)
class UPCTestAssemblyListener : public UObject
{
	GENERATED_BODY()
public:
	UFUNCTION()
	void OnFailed(AComputerComponent* Item, FGameplayTag Code, FText Reason)
	{
		LastCode = Code;
		LastReason = Reason;
		++FailureCount;
	}

	FGameplayTag LastCode;
	FText LastReason;
	int32 FailureCount = 0;

	void Reset()
	{
		LastCode = FGameplayTag();
		LastReason = FText::GetEmpty();
		FailureCount = 0;
	}
};
