﻿#include "../PCTestHelpers.h"
#include "../PCTestTypes.h"
#include "Assembly/PCAssemblyProgressTracker.h"
#include "Assembly/PCAssemblySystem.h"
#include "Build/PCBuildJsonParser.h"
#include "Build/PCBuildSpawner.h"
#include "Catalog/PCComponentCatalog.h"
#include "Compatibility/PCCompatibilitySystem.h"
#include "Effects/PCPowerSystem.h"
#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

/**
 * Fluxo canônico ponta a ponta sem rede e sem mapa:
 * JSON → parser → catálogo → compatibilidade → spawn → montagem → cabos → painel → Power → Running.
 * A perna de rede é coberta por Tools/MockServer (procedimento em Docs/ImplementationNotes.md).
 */
BEGIN_DEFINE_SPEC(FPCBuildToBootSpec, "PCSimulator.Integration.BuildToBoot",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
END_DEFINE_SPEC(FPCBuildToBootSpec)

void FPCBuildToBootSpec::Define()
{
	It("assembles the reference build and boots", [this]()
	{
		PCTest::FTestWorld TestWorld;
		PCTest::FScopedFastSettings FastSettings;
		const PCTest::FReferenceBuild Build = PCTest::MakeReferenceBuild();
		UPCCompatibilityRuleSet* Rules = PCTest::MakeDefaultRuleSet();

		// 1) Parser
		const FString Json = TEXT(R"json({"schemaVersion":1,"buildId":"a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d","components":{
			"Component.CPU":"ryzen_5_5600","Component.GPU":"rx_7600","Component.Motherboard":"b550m",
			"Component.RAM":"16gb_ddr4_3200","Component.Storage":"ssd_nvme_1tb","Component.PSU":"psu_650w_80plus",
			"Component.Case":"case_midtower_atx"}})json");
		FBuildConfiguration Config;
		FPCError Error;
		if (!TestTrue(TEXT("Parse"), FPCBuildJsonParser::ParseBuild(Json, Config, Error, 32)))
		{
			return;
		}

		// 2) Catálogo (entradas em memória)
		UPCComponentCatalog* Catalog = NewObject<UPCComponentCatalog>(GetTransientPackage());
		for (UPCComponentDataAsset* Data : Build.All())
		{
			Catalog->RegisterEntryForTests(Data);
		}
		TArray<FPCComponentRef> Refs;
		if (!TestTrue(TEXT("Resolve"), Catalog->ResolveAll(Config, Refs, Error)))
		{
			return;
		}
		TArray<UPCComponentDataAsset*> DataList;
		for (const FPCComponentRef& Ref : Refs)
		{
			DataList.Add(Catalog->GetLoaded(Ref));
		}

		// 3) Compatibilidade da build inteira
		FCompatibilityResult Compatibility;
		TestTrue(TEXT("Build compatível"), UPCCompatibilitySystem::EvaluateRuleSet(Rules, FPCBuildContext::Make(DataList), Compatibility));

		// 4) Spawn
		UPCBuildSpawner* Spawner = TestWorld.Get<UPCBuildSpawner>();
		const double SpawnStart = FPlatformTime::Seconds();
		TestTrue(TEXT("Spawn"), Spawner->SpawnFromData(DataList));
		const double SpawnMs = (FPlatformTime::Seconds() - SpawnStart) * 1000.0;
		AddInfo(FString::Printf(TEXT("Spawn: %.2f ms"), SpawnMs));
		TestTrue(TEXT("Spawn < 200 ms"), SpawnMs < 200.0);

		TArray<AComputerComponent*> Items;
		Spawner->GetSpawned(Items);
		TestEqual(TEXT("8 atores (RAM = 2 módulos)"), Items.Num(), 8);

		ACaseComponent* Case = nullptr; AMotherboardComponent* Board = nullptr; ACPUComponent* Cpu = nullptr;
		AGPUComponent* Gpu = nullptr; ASSDComponent* Ssd = nullptr; APSUComponent* Psu = nullptr; TArray<ARAMComponent*> Ram;
		for (AComputerComponent* Item : Items)
		{
			if (auto* C = Cast<ACaseComponent>(Item)) { Case = C; }
			else if (auto* B = Cast<AMotherboardComponent>(Item)) { Board = B; }
			else if (auto* P = Cast<ACPUComponent>(Item)) { Cpu = P; }
			else if (auto* G = Cast<AGPUComponent>(Item)) { Gpu = G; }
			else if (auto* S = Cast<ASSDComponent>(Item)) { Ssd = S; }
			else if (auto* U = Cast<APSUComponent>(Item)) { Psu = U; }
			else if (auto* R = Cast<ARAMComponent>(Item)) { Ram.Add(R); }
		}
		if (!TestTrue(TEXT("Todos os tipos"), Case && Board && Cpu && Gpu && Ssd && Psu && Ram.Num() == 2))
		{
			return;
		}

		// Slots equivalentes aos dos Blueprints.
		using namespace PCTest;
		UPCAssemblySlotComponent* SBoard = AddSlot(Case, TEXT("Slot.Case.Motherboard"), TEXT("Component.Motherboard"), nullptr, FVector(0, 0, 20));
		UPCAssemblySlotComponent* SPsu = AddSlot(Case, TEXT("Slot.PSU"), TEXT("Component.PSU"), nullptr, FVector(0, 0, -20));
		UPCAssemblySlotComponent* SCpu = AddSlot(Board, TEXT("Slot.CPU"), TEXT("Component.CPU"), TEXT("Socket.CPU.AM4"), FVector(5, 0, 1));
		UPCAssemblySlotComponent* SRam1 = AddSlot(Board, TEXT("Slot.RAM.1"), TEXT("Component.RAM"), TEXT("Socket.RAM.DDR4"), FVector(5, 10, 1));
		UPCAssemblySlotComponent* SRam2 = AddSlot(Board, TEXT("Slot.RAM.2"), TEXT("Component.RAM"), TEXT("Socket.RAM.DDR4"), FVector(5, 13, 1));
		UPCAssemblySlotComponent* SM2 = AddSlot(Board, TEXT("Slot.M2.1"), TEXT("Component.Storage"), TEXT("Socket.M2.NVMe"), FVector(-2, 5, 1));
		UPCAssemblySlotComponent* SPcie = AddSlot(Board, TEXT("Slot.PCIe.1"), TEXT("Component.GPU"), TEXT("Socket.PCIe.x16"), FVector(-5, 0, 1), TEXT("Slot.Case.Motherboard"));
		UPCAssemblySlotComponent* C24 = AddSlot(Board, TEXT("Slot.Cable.ATX24"), TEXT("Component.Cable"), TEXT("Socket.PSU.ATX24"), FVector(10, 15, 1));
		UPCAssemblySlotComponent* C8 = AddSlot(Board, TEXT("Slot.Cable.EPS8"), TEXT("Component.Cable"), TEXT("Socket.Power.EPS8"), FVector(10, -15, 1));
		UPCAssemblySlotComponent* CGpu = AddSlot(Gpu, TEXT("Slot.Cable.PCIe8"), TEXT("Component.Cable"), TEXT("Socket.Power.PCIe8"), FVector(0, 5, 2));

		UPCAssemblySystem* Assembly = TestWorld.Get<UPCAssemblySystem>();
		Assembly->SetRuleSetOverride(Rules);
		UPCAssemblyProgressTracker* Tracker = TestWorld.Get<UPCAssemblyProgressTracker>();
		Tracker->SetTrackedItems(Items);

		// 7 itens + 3 cabos + painel
		TestEqual(TEXT("Total de requisitos"), Tracker->GetTotalCount(), 11);

		UPCPowerSystem* Power = TestWorld.Get<UPCPowerSystem>();
		TestFalse(TEXT("Power antes de montar"), Power->RequestPowerOn());

		// 5) Montagem na ordem real: placa na bancada, depois no gabinete.
		TestTrue(TEXT("CPU"), PlaceAndInstall(Assembly, Cpu, SCpu));
		TestTrue(TEXT("RAM 1"), PlaceAndInstall(Assembly, Ram[0], SRam1));
		TestTrue(TEXT("RAM 2"), PlaceAndInstall(Assembly, Ram[1], SRam2));
		TestTrue(TEXT("SSD"), PlaceAndInstall(Assembly, Ssd, SM2));
		TestTrue(TEXT("Placa no gabinete"), PlaceAndInstall(Assembly, Board, SBoard));
		TestTrue(TEXT("GPU"), PlaceAndInstall(Assembly, Gpu, SPcie));

		TestFalse(TEXT("Cabo sem PSU"), Assembly->TryConnectCable(C24));
		TestTrue(TEXT("PSU"), PlaceAndInstall(Assembly, Psu, SPsu));

		TestFalse(TEXT("Fechar sem cabos"), Assembly->TrySetPanelClosed(Case, true));
		TestTrue(TEXT("Cabo 24"), Assembly->TryConnectCable(C24));
		TestTrue(TEXT("Cabo EPS8"), Assembly->TryConnectCable(C8));
		TestTrue(TEXT("Cabo PCIe8"), Assembly->TryConnectCable(CGpu));
		TestTrue(TEXT("Componentes e cabos"), Tracker->AreComponentsAndCablesDone());
		TestTrue(TEXT("Fecha painel"), Assembly->TrySetPanelClosed(Case, true));

		TestTrue(TEXT("Completo"), Tracker->IsComplete());
		TestEqual(TEXT("11/11"), Tracker->GetDoneCount(), 11);

		// 6) Energia
		TestTrue(TEXT("Power"), Power->RequestPowerOn());
		TestTrue(TEXT("Running"), Power->GetPowerState() == EPCPowerState::Running);
		TestTrue(TEXT("Montagem travada"), Assembly->IsLocked());
		TestFalse(TEXT("Não pega com o PC ligado"), Assembly->TryPickUp(Cpu));
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
