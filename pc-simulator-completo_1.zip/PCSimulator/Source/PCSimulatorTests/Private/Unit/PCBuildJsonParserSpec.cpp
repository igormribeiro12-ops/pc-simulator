﻿#include "Build/PCBuildJsonParser.h"
#include "Misc/AutomationTest.h"
#include "Utilities/PCGameplayTags.h"

#if WITH_DEV_AUTOMATION_TESTS

namespace
{
	const TCHAR* ValidBuild = TEXT(R"json({
		"schemaVersion": 1,
		"buildId": "a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d",
		"components": {
			"Component.CPU": "ryzen_5_5600",
			"Component.GPU": "rx_7600",
			"Component.Motherboard": "b550m",
			"Component.RAM": "16gb_ddr4_3200",
			"Component.Storage": "ssd_nvme_1tb",
			"Component.PSU": "psu_650w_80plus",
			"Component.Case": "case_midtower_atx"
		}
	})json");

	FString Variant(const TCHAR* From, const TCHAR* To)
	{
		return FString(ValidBuild).Replace(From, To, ESearchCase::CaseSensitive);
	}
}

BEGIN_DEFINE_SPEC(FPCBuildJsonParserSpec, "PCSimulator.Unit.Json",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

	FBuildConfiguration Build;
	FPCError Error;

	bool Parse(const FString& Json) { return FPCBuildJsonParser::ParseBuild(Json, Build, Error, 32); }

	void ExpectError(const FGameplayTag& Expected, const FString& Json)
	{
		TestFalse(TEXT("Parse deve falhar"), Parse(Json));
		TestEqual(TEXT("Código"), Error.Code.ToString(), Expected.ToString());
	}

END_DEFINE_SPEC(FPCBuildJsonParserSpec)

void FPCBuildJsonParserSpec::Define()
{
	It("Valid", [this]()
	{
		TestTrue(TEXT("Parse"), Parse(ValidBuild));
		TestFalse(TEXT("Sem erro"), Error.IsSet());
		TestEqual(TEXT("Componentes"), Build.Components.Num(), 7);
		TestEqual(TEXT("CPU"), Build.Components.FindRef(FGameplayTag(PCTags::Component_CPU)).ToString(), FString(TEXT("ryzen_5_5600")));
		TestFalse(TEXT("Não validada ainda"), Build.bValidated);
	});

	It("Malformed", [this]()
	{
		ExpectError(PCTags::BuildError_MalformedJson, TEXT("{\"schemaVersion\": 1, \"buildId\": "));
	});

	It("FutureSchema", [this]()
	{
		ExpectError(PCTags::BuildError_SchemaVersionUnsupported, Variant(TEXT("\"schemaVersion\": 1"), TEXT("\"schemaVersion\": 2")));
	});

	It("NonIntegerSchema", [this]()
	{
		ExpectError(PCTags::BuildError_InvalidFieldValue, Variant(TEXT("\"schemaVersion\": 1"), TEXT("\"schemaVersion\": 1.5")));
	});

	It("MissingField", [this]()
	{
		ExpectError(PCTags::BuildError_MissingField, Variant(TEXT("\"schemaVersion\": 1,"), TEXT("")));
		TestEqual(TEXT("Campo"), Error.Field, FString(TEXT("schemaVersion")));
	});

	It("InvalidBuildId", [this]()
	{
		ExpectError(PCTags::BuildError_InvalidFieldValue,
			Variant(TEXT("a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d"), TEXT("A7E0C1D2-3B4F-4A5B-8C6D-7E8F9A0B1C2D")));
	});

	It("UnknownTag", [this]()
	{
		ExpectError(PCTags::BuildError_UnknownComponentTag, Variant(TEXT("Component.GPU"), TEXT("Component.Toaster")));
	});

	It("NonComponentTag", [this]()
	{
		ExpectError(PCTags::BuildError_UnknownComponentTag, Variant(TEXT("Component.GPU"), TEXT("Socket.PCIe.x16")));
	});

	It("DuplicateComponentTag", [this]()
	{
		ExpectError(PCTags::BuildError_DuplicateComponentTag,
			Variant(TEXT("\"Component.GPU\": \"rx_7600\","), TEXT("\"Component.GPU\": \"rx_7600\", \"Component.GPU\": \"rx_7700\",")));
		TestEqual(TEXT("Campo"), Error.Field, FString(TEXT("components.Component.GPU")));
	});

	It("InvalidIdFormat", [this]()
	{
		ExpectError(PCTags::BuildError_InvalidFieldValue, Variant(TEXT("rx_7600"), TEXT("RX-7600")));
	});

	It("MissingRequiredComponent", [this]()
	{
		ExpectError(PCTags::BuildError_MissingRequiredComponent, Variant(TEXT("\"Component.GPU\": \"rx_7600\","), TEXT("")));
	});

	It("EmptyComponents", [this]()
	{
		ExpectError(PCTags::BuildError_InvalidFieldValue,
			TEXT("{\"schemaVersion\":1,\"buildId\":\"a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d\",\"components\":{}}"));
	});

	It("ExtraRootFieldIgnored", [this]()
	{
		TestTrue(TEXT("Parse"), Parse(Variant(TEXT("\"schemaVersion\": 1,"), TEXT("\"schemaVersion\": 1, \"futureField\": true,"))));
	});

	It("EnvelopePayload", [this]()
	{
		const FString Envelope = FString::Printf(
			TEXT("{\"type\":\"build.deliver\",\"version\":1,\"requestId\":\"3f1c2a9e-8d4b-4c7a-9e21-5b6d0f7a1c33\",\"timestamp\":1,\"payload\":%s}"),
			ValidBuild);
		TestTrue(TEXT("Parse"), FPCBuildJsonParser::ParseEnvelopePayload(Envelope, Build, Error, 32));
		TestEqual(TEXT("Componentes"), Build.Components.Num(), 7);
	});

	It("EnvelopeDuplicateInsidePayload", [this]()
	{
		const FString Payload = Variant(TEXT("\"Component.CPU\": \"ryzen_5_5600\","),
			TEXT("\"Component.CPU\": \"ryzen_5_5600\", \"Component.CPU\": \"ryzen_5_5600\","));
		const FString Envelope = FString::Printf(
			TEXT("{\"type\":\"build.deliver\",\"version\":1,\"requestId\":\"3f1c2a9e-8d4b-4c7a-9e21-5b6d0f7a1c33\",\"timestamp\":1,\"payload\":%s}"),
			*Payload);
		TestFalse(TEXT("Parse"), FPCBuildJsonParser::ParseEnvelopePayload(Envelope, Build, Error, 32));
		TestEqual(TEXT("Código"), Error.Code.ToString(), FGameplayTag(PCTags::BuildError_DuplicateComponentTag).ToString());
		TestEqual(TEXT("Campo"), Error.Field, FString(TEXT("payload.components.Component.CPU")));
	});

	It("PerfUnder50ms", [this]()
	{
		constexpr int32 Iterations = 200;
		const double Start = FPlatformTime::Seconds();
		for (int32 i = 0; i < Iterations; ++i)
		{
			Parse(ValidBuild);
		}
		const double AverageMs = (FPlatformTime::Seconds() - Start) * 1000.0 / Iterations;
		AddInfo(FString::Printf(TEXT("Parse médio: %.4f ms"), AverageMs));
		TestTrue(TEXT("< 50 ms"), AverageMs < 50.0);
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
