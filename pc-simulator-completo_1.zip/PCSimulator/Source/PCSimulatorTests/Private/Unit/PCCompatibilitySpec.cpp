﻿#include "../PCTestHelpers.h"
#include "../PCTestTypes.h"
#include "Compatibility/PCCompatibilitySystem.h"
#include "Misc/AutomationTest.h"
#include "Utilities/PCGameplayTags.h"

#if WITH_DEV_AUTOMATION_TESTS

BEGIN_DEFINE_SPEC(FPCCompatibilitySpec, "PCSimulator.Unit.Compatibility",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

	PCTest::FReferenceBuild Build;
	UPCCompatibilityRuleSet* Rules = nullptr;
	FCompatibilityResult Result;

	bool Evaluate(const TArray<UPCComponentDataAsset*>& Items)
	{
		return UPCCompatibilitySystem::EvaluateRuleSet(Rules, FPCBuildContext::Make(Items), Result);
	}

	void ExpectIncompatible(const TArray<UPCComponentDataAsset*>& Items)
	{
		TestFalse(TEXT("Deve ser incompatível"), Evaluate(Items));
		TestEqual(TEXT("Código"), Result.ErrorCode.ToString(), FGameplayTag(PCTags::AssemblyError_Incompatible).ToString());
		TestFalse(TEXT("Motivo preenchido"), Result.Reason.IsEmpty());
	}

END_DEFINE_SPEC(FPCCompatibilitySpec)

void FPCCompatibilitySpec::Define()
{
	BeforeEach([this]()
	{
		Build = PCTest::MakeReferenceBuild();
		Rules = PCTest::MakeDefaultRuleSet();
	});

	It("ValidBuildPasses", [this]()
	{
		TestTrue(TEXT("Compatível"), Evaluate(Build.All()));
		TestTrue(TEXT("bCompatible"), Result.bCompatible);
	});

	It("CpuSocketMismatch", [this]()
	{
		Build.Cpu->RequiredSocket = PCTest::Tag(TEXT("Socket.CPU.LGA1700"));
		ExpectIncompatible(Build.All());
	});

	It("RamGenerationMismatch", [this]()
	{
		Build.Ram->RequiredSocket = PCTest::Tag(TEXT("Socket.RAM.DDR5"));
		ExpectIncompatible(Build.All());
	});

	It("RamKitExceedsSlots", [this]()
	{
		Build.Ram->ModuleCount = 4;
		ExpectIncompatible(Build.All());
	});

	It("GpuNoPcieSlot", [this]()
	{
		Build.Board->PcieX16Slots = 0;
		ExpectIncompatible(Build.All());
	});

	It("PsuUnderpowered", [this]()
	{
		Build.Psu->CapacityWatts = 250;
		ExpectIncompatible(Build.All());
	});

	It("PsuBelowGpuRecommendation", [this]()
	{
		Build.Psu->CapacityWatts = 500; // cobre o consumo com margem, mas abaixo dos 550 W recomendados
		ExpectIncompatible(Build.All());
	});

	It("PsuMissingGpuConnector", [this]()
	{
		Build.Psu->Connectors.RemoveTag(PCTest::Tag(TEXT("Socket.Power.PCIe8")));
		ExpectIncompatible(Build.All());
	});

	It("FormFactorUnsupported", [this]()
	{
		Build.Case->SupportedFormFactors.RemoveTag(PCTest::Tag(TEXT("FormFactor.MicroATX")));
		ExpectIncompatible(Build.All());
	});

	It("GpuTooLong", [this]()
	{
		Build.Gpu->LengthMm = 400;
		ExpectIncompatible(Build.All());
	});

	It("RuleNotApplicableWhenMissing", [this]()
	{
		// Só CPU (sem placa-mãe): a regra de soquete não se aplica.
		Build.Cpu->RequiredSocket = PCTest::Tag(TEXT("Socket.CPU.LGA1700"));
		TestTrue(TEXT("Compatível"), Evaluate({ Build.Cpu }));
	});

	It("FailsClosedWithoutRuleSet", [this]()
	{
		Rules = nullptr;
		TestFalse(TEXT("Sem regras = rejeita"), Evaluate(Build.All()));
	});

	It("NewRuleWithoutSystemChange", [this]()
	{
		Rules->Rules.Add(NewObject<UPCTestAlwaysFailRule>(Rules));
		TestFalse(TEXT("Nova regra aplicada"), Evaluate(Build.All()));
		TestEqual(TEXT("Motivo"), Result.Reason.ToString(), FString(TEXT("TestAlwaysFail")));
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
