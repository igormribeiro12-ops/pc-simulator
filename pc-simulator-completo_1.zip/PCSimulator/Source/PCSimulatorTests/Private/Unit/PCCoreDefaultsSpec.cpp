﻿#include "Camera/PCCameraComponent.h"
#include "Core/PCGameMode.h"
#include "Core/PCGameState.h"
#include "Core/PCPlayerController.h"
#include "Core/PCPlayerPawn.h"
#include "Interaction/PCInteractionComponent.h"
#include "Misc/AutomationTest.h"
#include "UI/PCHUD.h"

#if WITH_DEV_AUTOMATION_TESTS

BEGIN_DEFINE_SPEC(FPCCoreDefaultsSpec, "PCSimulator.Unit.Core.Defaults",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
END_DEFINE_SPEC(FPCCoreDefaultsSpec)

void FPCCoreDefaultsSpec::Define()
{
	Describe("APCGameMode", [this]()
	{
		It("uses the project classes", [this]()
		{
			const APCGameMode* GameMode = GetDefault<APCGameMode>();
			TestTrue(TEXT("Pawn"), GameMode->DefaultPawnClass && GameMode->DefaultPawnClass->IsChildOf(APCPlayerPawn::StaticClass()));
			TestTrue(TEXT("Controller"), GameMode->PlayerControllerClass && GameMode->PlayerControllerClass->IsChildOf(APCPlayerController::StaticClass()));
			TestTrue(TEXT("GameState"), GameMode->GameStateClass && GameMode->GameStateClass->IsChildOf(APCGameState::StaticClass()));
			TestTrue(TEXT("HUD"), GameMode->HUDClass && GameMode->HUDClass->IsChildOf(APCHUD::StaticClass()));
		});
	});

	Describe("APCPlayerPawn", [this]()
	{
		It("does not tick (project rule)", [this]()
		{
			TestFalse(TEXT("bCanEverTick"), GetDefault<APCPlayerPawn>()->PrimaryActorTick.bCanEverTick);
		});

		It("has arm, camera and interaction", [this]()
		{
			const APCPlayerPawn* Pawn = GetDefault<APCPlayerPawn>();
			TestNotNull(TEXT("SpringArm"), Pawn->GetSpringArm());
			TestNotNull(TEXT("Camera"), Pawn->GetCamera());
			TestNotNull(TEXT("Interaction"), Pawn->GetInteraction());
		});

		It("camera starts with tick disabled", [this]()
		{
			const UPCCameraComponent* Camera = GetDefault<APCPlayerPawn>()->GetCamera();
			TestFalse(TEXT("bStartWithTickEnabled"), Camera->PrimaryComponentTick.bStartWithTickEnabled);
		});
	});

	Describe("APCPlayerController", [this]()
	{
		It("reports every missing input asset on the native class", [this]()
		{
			TArray<FString> Missing;
			TestFalse(TEXT("Complete"), GetDefault<APCPlayerController>()->HasCompleteInputConfig(Missing));
			TestEqual(TEXT("Missing count"), Missing.Num(), 9);
		});
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
