﻿#include "../PCTestHelpers.h"
#include "Catalog/PCComponentCatalog.h"
#include "Misc/AutomationTest.h"
#include "Utilities/PCGameplayTags.h"

#if WITH_DEV_AUTOMATION_TESTS

BEGIN_DEFINE_SPEC(FPCCatalogSpec, "PCSimulator.Unit.Catalog",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
	UPCComponentCatalog* Catalog = nullptr;
	PCTest::FReferenceBuild Build;
	FPCError Error;
END_DEFINE_SPEC(FPCCatalogSpec)

void FPCCatalogSpec::Define()
{
	BeforeEach([this]()
	{
		// Sem GameInstance: o catálogo é usado isoladamente com entradas injetadas.
		Catalog = NewObject<UPCComponentCatalog>(GetTransientPackage());
		Build = PCTest::MakeReferenceBuild();
		for (UPCComponentDataAsset* Data : Build.All())
		{
			Catalog->RegisterEntryForTests(Data);
		}
	});

	It("ResolvesKnownId", [this]()
	{
		FPCComponentRef Ref;
		TestTrue(TEXT("Resolve"), Catalog->Resolve(PCTags::Component_GPU, TEXT("rx_7600"), Ref, Error));
		TestTrue(TEXT("Carregado"), Catalog->GetLoaded(Ref) == Build.Gpu);
		TestEqual(TEXT("AssetId"), Ref.AssetId.ToString(), FString(TEXT("PCComponent:rx_7600")));
	});

	It("UnknownIdFails", [this]()
	{
		FPCComponentRef Ref;
		TestFalse(TEXT("Resolve"), Catalog->Resolve(PCTags::Component_GPU, TEXT("gtx_9999"), Ref, Error));
		TestEqual(TEXT("Código"), Error.Code.ToString(), FGameplayTag(PCTags::BuildError_UnknownComponentId).ToString());
		TestEqual(TEXT("Campo"), Error.Field, FString(TEXT("components.Component.GPU")));
	});

	It("ResolveAllIsAllOrNothing", [this]()
	{
		FBuildConfiguration Config;
		for (UPCComponentDataAsset* Data : Build.All())
		{
			Config.Components.Add(Data->Type, Data->ComponentId);
		}
		TArray<FPCComponentRef> Refs;
		TestTrue(TEXT("Tudo resolvido"), Catalog->ResolveAll(Config, Refs, Error));
		TestEqual(TEXT("7 refs"), Refs.Num(), 7);

		Config.Components.Add(FGameplayTag(PCTags::Component_Fan), FName(TEXT("fan_unknown")));
		TestFalse(TEXT("Falha"), Catalog->ResolveAll(Config, Refs, Error));
		TestEqual(TEXT("Nada parcial"), Refs.Num(), 0);
	});

	It("TypeMismatchDetectedOnLoad", [this]()
	{
		// ID de GPU enviado na chave de CPU: o catálogo resolve, a carga detecta o tipo errado.
		FPCComponentRef Ref;
		TestTrue(TEXT("Resolve"), Catalog->Resolve(PCTags::Component_CPU, TEXT("rx_7600"), Ref, Error));

		FPCError LoadError;
		bool bCalled = false;
		Catalog->LoadAsync({ Ref }, UPCComponentCatalog::FOnLoadComplete::CreateLambda(
			[&LoadError, &bCalled](const FPCError& InError) { LoadError = InError; bCalled = true; }));

		TestTrue(TEXT("Callback síncrono para entradas em memória"), bCalled);
		TestEqual(TEXT("Código"), LoadError.Code.ToString(), FGameplayTag(PCTags::BuildError_ComponentTypeMismatch).ToString());
	});

	It("IdsAreGloballyUnique", [this]()
	{
		TSet<FName> Ids;
		for (const UPCComponentDataAsset* Data : Build.All())
		{
			bool bDuplicate = false;
			Ids.Add(Data->ComponentId, &bDuplicate);
			TestFalse(*FString::Printf(TEXT("%s único"), *Data->ComponentId.ToString()), bDuplicate);
		}
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
