﻿#include "Dom/JsonObject.h"
#include "Misc/AutomationTest.h"
#include "Networking/PCBackoff.h"
#include "Networking/PCEnvelope.h"

#if WITH_DEV_AUTOMATION_TESTS

BEGIN_DEFINE_SPEC(FPCNetworkSpec, "PCSimulator.Unit.Network",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
	FPCEnvelope Envelope;
	FString Error;
	bool bTooLarge = false;
END_DEFINE_SPEC(FPCNetworkSpec)

void FPCNetworkSpec::Define()
{
	Describe("Backoff", [this]()
	{
		It("BackoffSequence is 1,2,4,8,16,30,30", [this]()
		{
			const float Expected[] = { 1.f, 2.f, 4.f, 8.f, 16.f, 30.f, 30.f };
			for (int32 Attempt = 0; Attempt < static_cast<int32>(UE_ARRAY_COUNT(Expected)); ++Attempt)
			{
				TestEqual(*FString::Printf(TEXT("Tentativa %d"), Attempt),
					PCBackoff::GetDelaySeconds(Attempt, 1.f, 30.f), Expected[Attempt]);
			}
		});
	});

	Describe("Envelope", [this]()
	{
		It("parses a valid envelope", [this]()
		{
			const FString Raw = TEXT("{\"type\":\"ping\",\"version\":1,\"requestId\":\"3f1c2a9e-8d4b-4c7a-9e21-5b6d0f7a1c33\",\"timestamp\":1790000000,\"payload\":{}}");
			TestTrue(TEXT("Parse"), FPCEnvelope::Parse(Raw, 65536, Envelope, Error, bTooLarge));
			TestEqual(TEXT("Type"), Envelope.Type, FString(TEXT("ping")));
			TestEqual(TEXT("Timestamp"), Envelope.Timestamp, static_cast<int64>(1790000000));
		});

		It("rejects unsupported protocol version", [this]()
		{
			const FString Raw = TEXT("{\"type\":\"ping\",\"version\":2,\"requestId\":\"3f1c2a9e-8d4b-4c7a-9e21-5b6d0f7a1c33\",\"timestamp\":1,\"payload\":{}}");
			TestFalse(TEXT("Parse"), FPCEnvelope::Parse(Raw, 65536, Envelope, Error, bTooLarge));
			TestFalse(TEXT("Não é tamanho"), bTooLarge);
		});

		It("rejects non-canonical requestId", [this]()
		{
			const FString Raw = TEXT("{\"type\":\"ping\",\"version\":1,\"requestId\":\"abc\",\"timestamp\":1,\"payload\":{}}");
			TestFalse(TEXT("Parse"), FPCEnvelope::Parse(Raw, 65536, Envelope, Error, bTooLarge));
		});

		It("OversizeRejected", [this]()
		{
			const FString Raw = FString::ChrN(2048, TEXT('x'));
			TestFalse(TEXT("Parse"), FPCEnvelope::Parse(Raw, 1024, Envelope, Error, bTooLarge));
			TestTrue(TEXT("Tamanho"), bTooLarge);
		});

		It("round-trips Serialize → Parse", [this]()
		{
			const FString Id = FPCEnvelope::NewRequestId();
			const TSharedRef<FJsonObject> Payload = MakeShared<FJsonObject>();
			Payload->SetStringField(TEXT("buildId"), TEXT("x"));
			const FString Raw = FPCEnvelope::Serialize(TEXT("build.ack"), Id, Payload);
			TestTrue(TEXT("Parse"), FPCEnvelope::Parse(Raw, 65536, Envelope, Error, bTooLarge));
			TestEqual(TEXT("RequestId"), Envelope.RequestId, Id);
			TestEqual(TEXT("Payload"), Envelope.Payload->GetStringField(TEXT("buildId")), FString(TEXT("x")));
		});

		It("knows incoming types", [this]()
		{
			TestTrue(TEXT("build.deliver"), FPCEnvelope::IsKnownIncomingType(TEXT("build.deliver")));
			TestFalse(TEXT("build.ack é só de saída"), FPCEnvelope::IsKnownIncomingType(TEXT("build.ack")));
		});
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
