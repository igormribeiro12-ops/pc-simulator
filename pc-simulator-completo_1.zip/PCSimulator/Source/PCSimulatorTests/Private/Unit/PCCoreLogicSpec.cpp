﻿#include "Assembly/PCSlotMath.h"
#include "Core/PCGameState.h"
#include "Data/PCTypes.h"
#include "GameplayTagsManager.h"
#include "Misc/AutomationTest.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Utilities/PCGameplayTags.h"

#if WITH_DEV_AUTOMATION_TESTS

BEGIN_DEFINE_SPEC(FPCCoreLogicSpec, "PCSimulator.Unit",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
END_DEFINE_SPEC(FPCCoreLogicSpec)

void FPCCoreLogicSpec::Define()
{
	Describe("Tags", [this]()
	{
		It("NativeTagsExistInIni", [this]()
		{
			FString Ini;
			const FString Path = FPaths::Combine(FPaths::ProjectConfigDir(), TEXT("DefaultGameplayTags.ini"));
			if (!TestTrue(TEXT("Lê DefaultGameplayTags.ini"), FFileHelper::LoadFileToString(Ini, *Path)))
			{
				return;
			}

			TSet<FString> IniTags;
			int32 Cursor = 0;
			const FString Marker = TEXT("Tag=\"");
			while ((Cursor = Ini.Find(Marker, ESearchCase::CaseSensitive, ESearchDir::FromStart, Cursor)) != INDEX_NONE)
			{
				Cursor += Marker.Len();
				const int32 End = Ini.Find(TEXT("\""), ESearchCase::CaseSensitive, ESearchDir::FromStart, Cursor);
				IniTags.Add(Ini.Mid(Cursor, End - Cursor));
				Cursor = End;
			}

			for (const FGameplayTag& Native : PCTags::GetAllNativeTags())
			{
				const FString Name = Native.ToString();
				bool bFound = IniTags.Contains(Name);
				for (const FString& IniTag : IniTags)
				{
					bFound = bFound || IniTag.StartsWith(Name + TEXT(".")); // pai implícito
				}
				TestTrue(*FString::Printf(TEXT("%s está no .ini"), *Name), bFound);
			}
		});
	});

	Describe("Ids", [this]()
	{
		It("validates component ids", [this]()
		{
			TestTrue(TEXT("ok"), PCIds::IsValidComponentId(TEXT("ryzen_5_5600")));
			TestFalse(TEXT("maiúscula"), PCIds::IsValidComponentId(TEXT("Ryzen")));
			TestFalse(TEXT("hífen"), PCIds::IsValidComponentId(TEXT("rx-7600")));
			TestFalse(TEXT("vazio"), PCIds::IsValidComponentId(TEXT("")));
			TestFalse(TEXT("65 chars"), PCIds::IsValidComponentId(FString::ChrN(65, TEXT('a'))));
		});

		It("validates canonical uuids", [this]()
		{
			TestTrue(TEXT("ok"), PCIds::IsCanonicalUuid(TEXT("a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d")));
			TestFalse(TEXT("maiúsculo"), PCIds::IsCanonicalUuid(TEXT("A7E0C1D2-3B4F-4A5B-8C6D-7E8F9A0B1C2D")));
			TestFalse(TEXT("sem hífen"), PCIds::IsCanonicalUuid(TEXT("a7e0c1d23b4f4a5b8c6d7e8f9a0b1c2d")));
		});
	});

	Describe("FSM", [this]()
	{
		It("allows the canonical path", [this]()
		{
			using S = EPCGameState;
			const S Path[] = { S::WaitingForBuild, S::LoadingBuild, S::BuildReady, S::AssemblyInProgress,
				S::AssemblyCompleted, S::PowerSequence, S::ComputerRunning, S::WaitingForBuild };
			for (int32 i = 0; i + 1 < static_cast<int32>(UE_ARRAY_COUNT(Path)); ++i)
			{
				TestTrue(*FString::Printf(TEXT("Passo %d"), i), PCFsm::IsTransitionAllowed(Path[i], Path[i + 1]));
			}
		});

		It("allows regressions defined in the table", [this]()
		{
			TestTrue(TEXT("Completed→InProgress"), PCFsm::IsTransitionAllowed(EPCGameState::AssemblyCompleted, EPCGameState::AssemblyInProgress));
			TestTrue(TEXT("Power→Completed"), PCFsm::IsTransitionAllowed(EPCGameState::PowerSequence, EPCGameState::AssemblyCompleted));
			TestTrue(TEXT("Any→Error"), PCFsm::IsTransitionAllowed(EPCGameState::BuildReady, EPCGameState::Error));
			TestTrue(TEXT("Error→Waiting"), PCFsm::IsTransitionAllowed(EPCGameState::Error, EPCGameState::WaitingForBuild));
		});

		It("rejects skips and self-transitions", [this]()
		{
			TestFalse(TEXT("Waiting→Running"), PCFsm::IsTransitionAllowed(EPCGameState::WaitingForBuild, EPCGameState::ComputerRunning));
			TestFalse(TEXT("InProgress→PowerSequence"), PCFsm::IsTransitionAllowed(EPCGameState::AssemblyInProgress, EPCGameState::PowerSequence));
			TestFalse(TEXT("Ready→Completed"), PCFsm::IsTransitionAllowed(EPCGameState::BuildReady, EPCGameState::AssemblyCompleted));
			TestFalse(TEXT("Self"), PCFsm::IsTransitionAllowed(EPCGameState::BuildReady, EPCGameState::BuildReady));
			TestFalse(TEXT("Error→Loading"), PCFsm::IsTransitionAllowed(EPCGameState::Error, EPCGameState::LoadingBuild));
		});
	});

	Describe("SlotMath", [this]()
	{
		It("accepts yaw within tolerance", [this]()
		{
			TestTrue(TEXT("3°"), PCSlotMath::IsOrientationValid(3.0, { 0.f }, 5.0));
			TestFalse(TEXT("15°"), PCSlotMath::IsOrientationValid(15.0, { 0.f }, 5.0));
		});

		It("supports multiple allowed yaws across ±180", [this]()
		{
			TestTrue(TEXT("-178 ≈ 180"), PCSlotMath::IsOrientationValid(-178.0, { 0.f, 180.f }, 5.0));
			TestEqual(TEXT("Mais próximo"), PCSlotMath::ClosestAllowedYaw(170.0, { 0.f, 180.f }), 180.0);
		});

		It("treats empty list as {0}", [this]()
		{
			TestTrue(TEXT("0°"), PCSlotMath::IsOrientationValid(0.0, {}, 5.0));
		});

		It("snaps yaw to steps", [this]()
		{
			TestEqual(TEXT("22 → 15"), PCSlotMath::SnapYaw(22.0, 15.0), 15.0);
			TestEqual(TEXT("23 → 30"), PCSlotMath::SnapYaw(23.0, 15.0), 30.0);
		});
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
