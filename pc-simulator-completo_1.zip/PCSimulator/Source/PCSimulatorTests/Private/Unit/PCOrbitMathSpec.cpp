﻿#include "Core/PCOrbitMath.h"
#include "Misc/AutomationTest.h"

#if WITH_DEV_AUTOMATION_TESTS

BEGIN_DEFINE_SPEC(FPCOrbitMathSpec, "PCSimulator.Unit.Camera.OrbitMath",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
END_DEFINE_SPEC(FPCOrbitMathSpec)

void FPCOrbitMathSpec::Define()
{
	Describe("ApplyOrbit", [this]()
	{
		It("adds yaw and pitch within limits", [this]()
		{
			const FRotator R = PCOrbitMath::ApplyOrbit(FRotator(-30.0, 10.0, 0.0), 20.0, -10.0, -80.0, -5.0);
			TestEqual(TEXT("Yaw"), R.Yaw, 30.0);
			TestEqual(TEXT("Pitch"), R.Pitch, -40.0);
		});

		It("clamps pitch to the maximum", [this]()
		{
			const FRotator R = PCOrbitMath::ApplyOrbit(FRotator(-10.0, 0.0, 0.0), 0.0, 50.0, -80.0, -5.0);
			TestEqual(TEXT("Pitch"), R.Pitch, -5.0);
		});

		It("clamps pitch to the minimum", [this]()
		{
			const FRotator R = PCOrbitMath::ApplyOrbit(FRotator(-70.0, 0.0, 0.0), 0.0, -50.0, -80.0, -5.0);
			TestEqual(TEXT("Pitch"), R.Pitch, -80.0);
		});

		It("normalizes yaw across 180 degrees", [this]()
		{
			const FRotator R = PCOrbitMath::ApplyOrbit(FRotator(-30.0, 170.0, 0.0), 30.0, 0.0, -80.0, -5.0);
			TestEqual(TEXT("Yaw"), R.Yaw, -160.0);
		});

		It("always zeroes roll", [this]()
		{
			const FRotator R = PCOrbitMath::ApplyOrbit(FRotator(-30.0, 0.0, 45.0), 0.0, 0.0, -80.0, -5.0);
			TestEqual(TEXT("Roll"), R.Roll, 0.0);
		});
	});

	Describe("ApplyZoom", [this]()
	{
		It("clamps to minimum and maximum", [this]()
		{
			TestEqual(TEXT("Min"), PCOrbitMath::ApplyZoom(40.f, -50.f, 30.f, 250.f), 30.f);
			TestEqual(TEXT("Max"), PCOrbitMath::ApplyZoom(240.f, 50.f, 30.f, 250.f), 250.f);
			TestEqual(TEXT("Mid"), PCOrbitMath::ApplyZoom(100.f, 10.f, 30.f, 250.f), 110.f);
		});
	});

	Describe("ComputePanDelta", [this]()
	{
		It("moves forward along +X at yaw 0", [this]()
		{
			const FVector D = PCOrbitMath::ComputePanDelta(FVector2D(0.0, 1.0), 0.0, 10.0);
			TestEqual(TEXT("Delta"), D, FVector(10.0, 0.0, 0.0), 1e-4);
		});

		It("moves forward along +Y at yaw 90", [this]()
		{
			const FVector D = PCOrbitMath::ComputePanDelta(FVector2D(0.0, 1.0), 90.0, 10.0);
			TestEqual(TEXT("Delta"), D, FVector(0.0, 10.0, 0.0), 1e-4);
		});

		It("moves right along +Y at yaw 0", [this]()
		{
			const FVector D = PCOrbitMath::ComputePanDelta(FVector2D(1.0, 0.0), 0.0, 10.0);
			TestEqual(TEXT("Delta"), D, FVector(0.0, 10.0, 0.0), 1e-4);
		});

		It("never changes Z", [this]()
		{
			const FVector D = PCOrbitMath::ComputePanDelta(FVector2D(0.7, 0.7), 37.0, 25.0);
			TestEqual(TEXT("Z"), D.Z, 0.0);
		});
	});

	Describe("ClampToBounds", [this]()
	{
		It("clamps outside points to the box", [this]()
		{
			const FBox Box(FVector(-100.0, -100.0, 0.0), FVector(100.0, 100.0, 0.0));
			const FVector C = PCOrbitMath::ClampToBounds(FVector(250.0, -300.0, 50.0), Box);
			TestEqual(TEXT("Clamped"), C, FVector(100.0, -100.0, 0.0), 1e-4);
		});

		It("does not clamp when the box is invalid", [this]()
		{
			const FVector P(999.0, 999.0, 999.0);
			TestEqual(TEXT("Unchanged"), PCOrbitMath::ClampToBounds(P, FBox(ForceInit)), P, 1e-4);
		});
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
