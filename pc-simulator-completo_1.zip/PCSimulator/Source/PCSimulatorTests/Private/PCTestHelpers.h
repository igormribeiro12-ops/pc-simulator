﻿#pragma once

#include "CoreMinimal.h"
#include "Assembly/PCAssemblySlotComponent.h"
#include "Assembly/PCAssemblySystem.h"
#include "Compatibility/PCCompatibilityRules.h"
#include "Components/PCHardwareComponents.h"
#include "Data/PCComponentDataAsset.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "GameFramework/WorldSettings.h"
#include "UObject/Package.h"
#include "Utilities/PCSimulatorSettings.h"

namespace PCTest
{
	inline FGameplayTag Tag(const TCHAR* Name)
	{
		return FGameplayTag::RequestGameplayTag(FName(Name));
	}

	template <class T>
	T* MakeData(const TCHAR* Id, const TCHAR* Socket, int32 Watts, UClass* ActorClass)
	{
		T* Data = NewObject<T>(GetTransientPackage(), NAME_None, RF_Transient);
		Data->ComponentId = FName(Id);
		Data->Type = Data->GetExpectedType();
		Data->DisplayName = FText::FromString(Id);
		if (Socket)
		{
			Data->RequiredSocket = Tag(Socket);
		}
		Data->PowerDrawWatts = Watts;
		Data->ActorClass = TSoftClassPtr<AComputerComponent>(ActorClass);
		return Data;
	}

	/** Build de referência (§8.2) com valores coerentes e compatíveis. */
	struct FReferenceBuild
	{
		UPCCPUDataAsset* Cpu = nullptr;
		UPCGPUDataAsset* Gpu = nullptr;
		UPCMotherboardDataAsset* Board = nullptr;
		UPCRAMDataAsset* Ram = nullptr;
		UPCStorageDataAsset* Ssd = nullptr;
		UPCPSUDataAsset* Psu = nullptr;
		UPCCaseDataAsset* Case = nullptr;

		TArray<UPCComponentDataAsset*> All() const
		{
			return { Cpu, Gpu, Board, Ram, Ssd, Psu, Case };
		}
	};

	inline FReferenceBuild MakeReferenceBuild()
	{
		FReferenceBuild B;
		B.Cpu = MakeData<UPCCPUDataAsset>(TEXT("ryzen_5_5600"), TEXT("Socket.CPU.AM4"), 65, ACPUComponent::StaticClass());

		B.Gpu = MakeData<UPCGPUDataAsset>(TEXT("rx_7600"), TEXT("Socket.PCIe.x16"), 165, AGPUComponent::StaticClass());
		B.Gpu->RecommendedPsuWatts = 550;
		B.Gpu->LengthMm = 204;
		B.Gpu->PowerConnectors.AddTag(Tag(TEXT("Socket.Power.PCIe8")));

		B.Board = MakeData<UPCMotherboardDataAsset>(TEXT("b550m"), nullptr, 50, AMotherboardComponent::StaticClass());
		B.Board->CpuSocket = Tag(TEXT("Socket.CPU.AM4"));
		B.Board->RamSocket = Tag(TEXT("Socket.RAM.DDR4"));
		B.Board->RamSlotCount = 2;
		B.Board->FormFactor = Tag(TEXT("FormFactor.MicroATX"));
		B.Board->PcieX16Slots = 1;
		B.Board->M2Slots = 1;

		B.Ram = MakeData<UPCRAMDataAsset>(TEXT("16gb_ddr4_3200"), TEXT("Socket.RAM.DDR4"), 6, ARAMComponent::StaticClass());
		B.Ram->ModuleCount = 2;

		B.Ssd = MakeData<UPCStorageDataAsset>(TEXT("ssd_nvme_1tb"), TEXT("Socket.M2.NVMe"), 7, ASSDComponent::StaticClass());

		B.Psu = MakeData<UPCPSUDataAsset>(TEXT("psu_650w_80plus"), nullptr, 0, APSUComponent::StaticClass());
		B.Psu->CapacityWatts = 650;
		B.Psu->Connectors.AddTag(Tag(TEXT("Socket.PSU.ATX24")));
		B.Psu->Connectors.AddTag(Tag(TEXT("Socket.Power.EPS8")));
		B.Psu->Connectors.AddTag(Tag(TEXT("Socket.Power.PCIe8")));

		B.Case = MakeData<UPCCaseDataAsset>(TEXT("case_midtower_atx"), nullptr, 0, ACaseComponent::StaticClass());
		B.Case->SupportedFormFactors.AddTag(Tag(TEXT("FormFactor.ATX")));
		B.Case->SupportedFormFactors.AddTag(Tag(TEXT("FormFactor.MicroATX")));
		B.Case->SupportedFormFactors.AddTag(Tag(TEXT("FormFactor.MiniITX")));
		B.Case->MaxGpuLengthMm = 330;
		return B;
	}

	inline UPCCompatibilityRuleSet* MakeDefaultRuleSet()
	{
		UPCCompatibilityRuleSet* Set = NewObject<UPCCompatibilityRuleSet>(GetTransientPackage(), NAME_None, RF_Transient);
		Set->Rules.Add(NewObject<UPCCPUSocketRule>(Set));
		Set->Rules.Add(NewObject<UPCRAMGenerationRule>(Set));
		Set->Rules.Add(NewObject<UPCGPUSlotRule>(Set));
		Set->Rules.Add(NewObject<UPCPSUWattageRule>(Set));
		Set->Rules.Add(NewObject<UPCPowerConnectorRule>(Set));
		Set->Rules.Add(NewObject<UPCFormFactorRule>(Set));
		Set->Rules.Add(NewObject<UPCGPULengthRule>(Set));
		return Set;
	}

	/** Zera animação/temporizações para os testes rodarem síncronos; restaura ao sair. */
	struct FScopedFastSettings
	{
		UPCSimulatorSettings* Settings;
		float Install, Fan, Boot;

		FScopedFastSettings()
			: Settings(GetMutableDefault<UPCSimulatorSettings>())
			, Install(Settings->InstallAnimationSeconds)
			, Fan(Settings->FanSpinUpDelaySeconds)
			, Boot(Settings->BootDurationSeconds)
		{
			Settings->InstallAnimationSeconds = 0.f;
			Settings->FanSpinUpDelaySeconds = 0.f;
			Settings->BootDurationSeconds = 0.f;
		}

		~FScopedFastSettings()
		{
			Settings->InstallAnimationSeconds = Install;
			Settings->FanSpinUpDelaySeconds = Fan;
			Settings->BootDurationSeconds = Boot;
		}
	};

	/** Mundo de jogo isolado com BeginPlay despachado (subsystems de mundo inicializados). */
	struct FTestWorld
	{
		UWorld* World = nullptr;

		FTestWorld()
		{
			World = UWorld::CreateWorld(EWorldType::Game, /*bInformEngineOfWorld*/ false, TEXT("PCTestWorld"));
			FWorldContext& Context = GEngine->CreateNewWorldContext(EWorldType::Game);
			Context.SetCurrentWorld(World);
			World->InitializeActorsForPlay(FURL());
			if (AWorldSettings* WorldSettings = World->GetWorldSettings())
			{
				WorldSettings->NotifyBeginPlay();
			}
		}

		~FTestWorld()
		{
			GEngine->DestroyWorldContext(World);
			World->DestroyWorld(/*bInformEngineOfWorld*/ false);
		}

		template <class T>
		T* Get() const { return World->GetSubsystem<T>(); }
	};

	template <class T>
	T* SpawnItem(UWorld* World, UPCComponentDataAsset* Data, const FVector& Location)
	{
		const FTransform Transform(Location);
		T* Actor = World->SpawnActorDeferred<T>(T::StaticClass(), Transform, nullptr, nullptr,
			ESpawnActorCollisionHandlingMethod::AlwaysSpawn);
		Actor->InitializeFromData(Data);
		Actor->FinishSpawning(Transform);
		return Actor;
	}

	/** Cria e registra um slot (em produção os slots vêm do Blueprint). */
	inline UPCAssemblySlotComponent* AddSlot(AActor* Owner, const TCHAR* SlotTag, const TCHAR* AllowedType,
		const TCHAR* Socket, const FVector& RelativeLocation, const TCHAR* Prerequisite = nullptr)
	{
		UPCAssemblySlotComponent* Slot = NewObject<UPCAssemblySlotComponent>(Owner);
		Slot->SlotTag = Tag(SlotTag);
		Slot->AllowedTypes.AddTag(Tag(AllowedType));
		if (Socket)
		{
			Slot->RequiredSocket = Tag(Socket);
		}
		if (Prerequisite)
		{
			Slot->Prerequisites.AddTag(Tag(Prerequisite));
		}
		Slot->SetupAttachment(Owner->GetRootComponent());
		Slot->SetRelativeLocation(RelativeLocation);
		Slot->RegisterComponent();
		if (UPCAssemblySystem* Assembly = Owner->GetWorld()->GetSubsystem<UPCAssemblySystem>())
		{
			Assembly->RegisterSlot(Slot); // idempotente (BeginPlay do slot também registra)
		}
		return Slot;
	}

	/** Coloca o item exatamente sobre o slot, alinhado, e tenta instalar. */
	inline bool PlaceAndInstall(UPCAssemblySystem* Assembly, AComputerComponent* Item, UPCAssemblySlotComponent* Slot,
		double ExtraYaw = 0.0, const FVector& Offset = FVector::ZeroVector)
	{
		Item->SetActorLocationAndRotation(Slot->GetComponentLocation() + Offset,
			FRotator(0.0, Slot->GetComponentRotation().Yaw + ExtraYaw, 0.0));
		return Assembly->TryInstall(Item, Slot);
	}
}
