﻿#include "../PCTestHelpers.h"
#include "../PCTestTypes.h"
#include "Assembly/PCAssemblyProgressTracker.h"
#include "Assembly/PCAssemblySystem.h"
#include "Build/PCBuildSpawner.h"
#include "Misc/AutomationTest.h"
#include "Utilities/PCGameplayTags.h"

#if WITH_DEV_AUTOMATION_TESTS

/**
 * Cenários de montagem num mundo de jogo real (sem mapa): slots criados em código
 * (em produção vêm dos Blueprints). Prefixo Functional por exercitar atores/mundo.
 */
BEGIN_DEFINE_SPEC(FPCAssemblySpec, "PCSimulator.Functional.Assembly",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

	TUniquePtr<PCTest::FTestWorld> TestWorld;
	TUniquePtr<PCTest::FScopedFastSettings> FastSettings;
	PCTest::FReferenceBuild Build;
	UPCAssemblySystem* Assembly = nullptr;
	UPCTestAssemblyListener* Listener = nullptr;

	ACaseComponent* Case = nullptr;
	AMotherboardComponent* Board = nullptr;
	ACPUComponent* Cpu = nullptr;
	AGPUComponent* Gpu = nullptr;
	TArray<ARAMComponent*> Ram;
	APSUComponent* Psu = nullptr;

	UPCAssemblySlotComponent* CaseBoardSlot = nullptr;
	UPCAssemblySlotComponent* PsuSlot = nullptr;
	UPCAssemblySlotComponent* CpuSlot = nullptr;
	UPCAssemblySlotComponent* Ram1Slot = nullptr;
	UPCAssemblySlotComponent* PcieSlot = nullptr;

	void ExpectFailure(bool bInstalled, const FGameplayTag& Expected)
	{
		TestFalse(TEXT("Não deve instalar"), bInstalled);
		TestEqual(TEXT("Código"), Listener->LastCode.ToString(), Expected.ToString());
	}

END_DEFINE_SPEC(FPCAssemblySpec)

void FPCAssemblySpec::Define()
{
	BeforeEach([this]()
	{
		TestWorld = MakeUnique<PCTest::FTestWorld>();
		FastSettings = MakeUnique<PCTest::FScopedFastSettings>();
		UWorld* World = TestWorld->World;

		Build = PCTest::MakeReferenceBuild();
		Assembly = TestWorld->Get<UPCAssemblySystem>();
		Assembly->SetRuleSetOverride(PCTest::MakeDefaultRuleSet());

		Listener = NewObject<UPCTestAssemblyListener>(GetTransientPackage());
		Assembly->OnInstallFailed.AddDynamic(Listener, &UPCTestAssemblyListener::OnFailed);

		UPCBuildSpawner* Spawner = TestWorld->Get<UPCBuildSpawner>();
		TestTrue(TEXT("Spawn"), Spawner->SpawnFromData(Build.All()));
		TArray<AComputerComponent*> Items;
		Spawner->GetSpawned(Items);

		Ram.Reset();
		for (AComputerComponent* Item : Items)
		{
			if (auto* C = Cast<ACaseComponent>(Item)) { Case = C; }
			else if (auto* B = Cast<AMotherboardComponent>(Item)) { Board = B; }
			else if (auto* P = Cast<ACPUComponent>(Item)) { Cpu = P; }
			else if (auto* G = Cast<AGPUComponent>(Item)) { Gpu = G; }
			else if (auto* R = Cast<ARAMComponent>(Item)) { Ram.Add(R); }
			else if (auto* S = Cast<APSUComponent>(Item)) { Psu = S; }
		}

		CaseBoardSlot = PCTest::AddSlot(Case, TEXT("Slot.Case.Motherboard"), TEXT("Component.Motherboard"), nullptr, FVector(0, 0, 20));
		PsuSlot = PCTest::AddSlot(Case, TEXT("Slot.PSU"), TEXT("Component.PSU"), nullptr, FVector(0, 0, -20));
		CpuSlot = PCTest::AddSlot(Board, TEXT("Slot.CPU"), TEXT("Component.CPU"), TEXT("Socket.CPU.AM4"), FVector(5, 0, 1));
		Ram1Slot = PCTest::AddSlot(Board, TEXT("Slot.RAM.1"), TEXT("Component.RAM"), TEXT("Socket.RAM.DDR4"), FVector(5, 10, 1));
		PcieSlot = PCTest::AddSlot(Board, TEXT("Slot.PCIe.1"), TEXT("Component.GPU"), TEXT("Socket.PCIe.x16"), FVector(-5, 0, 1),
			TEXT("Slot.Case.Motherboard"));

		(void)World;
	});

	AfterEach([this]()
	{
		FastSettings.Reset();
		TestWorld.Reset();
		Listener = nullptr;
	});

	It("InstallValid", [this]()
	{
		TestTrue(TEXT("Instala CPU"), PCTest::PlaceAndInstall(Assembly, Cpu, CpuSlot));
		TestTrue(TEXT("Slot ocupado"), CpuSlot->GetOccupant() == Cpu);
		TestTrue(TEXT("Item anexado ao slot"), Cpu->GetAttachParentActor() == Board);
		TestEqual(TEXT("Sem falhas"), Listener->FailureCount, 0);
	});

	It("WrongType", [this]()
	{
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, Gpu, CpuSlot), PCTags::AssemblyError_SlotMismatch);
	});

	It("WrongSocket", [this]()
	{
		UPCCPUDataAsset* Intel = PCTest::MakeData<UPCCPUDataAsset>(TEXT("i5_13600k"), TEXT("Socket.CPU.LGA1700"), 125,
			ACPUComponent::StaticClass());
		ACPUComponent* IntelCpu = PCTest::SpawnItem<ACPUComponent>(TestWorld->World, Intel, FVector(300, 0, 100));
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, IntelCpu, CpuSlot), PCTags::AssemblyError_SlotMismatch);
	});

	It("WrongOrientation", [this]()
	{
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, Ram[0], Ram1Slot, /*ExtraYaw*/ 90.0), PCTags::AssemblyError_WrongOrientation);
	});

	It("SlotOccupied", [this]()
	{
		TestTrue(TEXT("Primeiro módulo"), PCTest::PlaceAndInstall(Assembly, Ram[0], Ram1Slot));
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, Ram[1], Ram1Slot), PCTags::AssemblyError_SlotOccupied);
	});

	It("OutOfRange", [this]()
	{
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, Cpu, CpuSlot, 0.0, FVector(0, 0, 100)), PCTags::AssemblyError_OutOfRange);
	});

	It("MissingPrerequisite", [this]()
	{
		// GPU exige a placa-mãe já no gabinete.
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, Gpu, PcieSlot), PCTags::AssemblyError_MissingPrerequisite);
	});

	It("Incompatible", [this]()
	{
		TestTrue(TEXT("Placa no gabinete"), PCTest::PlaceAndInstall(Assembly, Board, CaseBoardSlot));
		TestTrue(TEXT("GPU"), PCTest::PlaceAndInstall(Assembly, Gpu, PcieSlot));

		UPCPSUDataAsset* Weak = PCTest::MakeData<UPCPSUDataAsset>(TEXT("psu_300w"), nullptr, 0, APSUComponent::StaticClass());
		Weak->CapacityWatts = 300;
		APSUComponent* WeakPsu = PCTest::SpawnItem<APSUComponent>(TestWorld->World, Weak, FVector(300, 0, 100));
		ExpectFailure(PCTest::PlaceAndInstall(Assembly, WeakPsu, PsuSlot), PCTags::AssemblyError_Incompatible);
	});

	It("PickUpRemovesAndRotateSnaps", [this]()
	{
		TestTrue(TEXT("Instala"), PCTest::PlaceAndInstall(Assembly, Cpu, CpuSlot));
		TestTrue(TEXT("Pega"), Assembly->TryPickUp(Cpu));
		TestFalse(TEXT("Slot liberado"), CpuSlot->IsOccupied());
		TestFalse(TEXT("Não instalado"), Cpu->IsInstalled());

		const double YawBefore = Cpu->GetActorRotation().Yaw;
		Assembly->RotateHeld(+1);
		TestEqual(TEXT("+15°"), FRotator::NormalizeAxis(Cpu->GetActorRotation().Yaw - YawBefore), 15.0, 0.01);
	});

	It("CannotPickUpCase", [this]()
	{
		TestFalse(TEXT("Gabinete é a base"), Assembly->TryPickUp(Case));
	});
}

#endif // WITH_DEV_AUTOMATION_TESTS
