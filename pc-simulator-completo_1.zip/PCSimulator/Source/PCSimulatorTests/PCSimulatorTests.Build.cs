// Módulo de testes (Type = Editor no .uproject). Nunca entra no target Game/Shipping.
using UnrealBuildTool;

public class PCSimulatorTests : ModuleRules
{
	public PCSimulatorTests(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine",
			"GameplayTags",
			"Json",
			"DeveloperSettings",
			"PCSimulator"
		});
	}
}
