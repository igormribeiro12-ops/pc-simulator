﻿#include "Assembly/PCAssemblySystem.h"

#include "Animation/PCInstallAnimationComponent.h"
#include "Assembly/PCAssemblySlotComponent.h"
#include "Assembly/PCSlotMath.h"
#include "Compatibility/PCCompatibilitySystem.h"
#include "Components/PCHardwareComponents.h"
#include "Data/PCComponentDataAsset.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"
#include "Utilities/PCGameplayTags.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCMessages.h"
#include "Utilities/PCSimulatorSettings.h"

#define LOCTEXT_NAMESPACE "PCAssembly"

// ---------------------------------------------------------------- Registro

void UPCAssemblySystem::RegisterSlot(UPCAssemblySlotComponent* Slot)
{
	if (Slot)
	{
		Slots.AddUnique(Slot);
	}
}

void UPCAssemblySystem::UnregisterSlot(UPCAssemblySlotComponent* Slot)
{
	Slots.Remove(Slot);
}

void UPCAssemblySystem::GetRegisteredSlots(TArray<UPCAssemblySlotComponent*>& OutSlots) const
{
	OutSlots.Reset();
	for (const TWeakObjectPtr<UPCAssemblySlotComponent>& Weak : Slots)
	{
		if (UPCAssemblySlotComponent* Slot = Weak.Get())
		{
			OutSlots.Add(Slot);
		}
	}
}

// ---------------------------------------------------------------- Ações

bool UPCAssemblySystem::TryPickUp(AComputerComponent* Item)
{
	if (bLocked || !Item || HeldItem.IsValid() || !Item->GetData())
	{
		return false;
	}
	if (Item->IsA<ACaseComponent>())
	{
		return false; // O gabinete é a base da montagem; não é carregado.
	}
	if (Item->GetInstallAnimation() && Item->GetInstallAnimation()->IsPlaying())
	{
		return false;
	}
	if (IsInsideClosedCase(*Item))
	{
		Fail(Item, PCTags::AssemblyError_MissingPrerequisite, LOCTEXT("PanelClosed", "Abra o painel lateral primeiro."));
		return false;
	}

	if (UPCAssemblySlotComponent* From = Item->GetInstalledSlot())
	{
		From->ClearOccupant();
		Item->SetInstalledSlot(nullptr);
		Item->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		UE_LOG(LogPCAssembly, Log, TEXT("Removido %s de %s."), *Item->GetName(), *From->SlotTag.ToString());
		OnRemoved.Broadcast(Item, From);
	}

	// Sem snap ao grid do mundo: os itens nascem com o yaw da origem da build (bancada), e os passos
	// de 15° são relativos a esse yaw. Assim os slots (alinhados ao gabinete) sempre são alcançáveis,
	// mesmo com a bancada girada em um ângulo qualquer.
	HeldRotation = FRotator(0.0, FRotator::NormalizeAxis(Item->GetActorRotation().Yaw), 0.0);
	HeldItem = Item;
	Item->SetCollisionEnabledRecursive(false);
	Item->SetActorRotation(HeldRotation);

	OnPickedUp.Broadcast(Item);
	return true;
}

void UPCAssemblySystem::UpdateHeldLocation(const FVector& WorldLocation)
{
	if (AComputerComponent* Item = HeldItem.Get())
	{
		Item->SetActorLocationAndRotation(WorldLocation, HeldRotation);
	}
}

void UPCAssemblySystem::RotateHeld(int32 Direction)
{
	AComputerComponent* Item = HeldItem.Get();
	if (!Item || Direction == 0)
	{
		return;
	}
	const double Step = UPCSimulatorSettings::Get().RotationSnapDegrees;
	HeldRotation.Yaw = FRotator::NormalizeAxis(HeldRotation.Yaw + FMath::Sign(Direction) * Step);
	Item->SetActorRotation(HeldRotation);
	OnHeldRotated.Broadcast(Item);
}

bool UPCAssemblySystem::TryInstallHeld()
{
	AComputerComponent* Item = HeldItem.Get();
	if (!Item)
	{
		return false;
	}
	UPCAssemblySlotComponent* Slot = FindNearestPhysicalSlot(Item->GetActorLocation(),
		UPCSimulatorSettings::Get().SlotSearchRadiusCm, Item);
	if (!Slot)
	{
		Fail(Item, PCTags::AssemblyError_OutOfRange);
		return false;
	}
	return TryInstall(Item, Slot);
}

bool UPCAssemblySystem::TryInstall(AComputerComponent* Item, UPCAssemblySlotComponent* Slot)
{
	if (bLocked || !Item || !Slot || !Item->GetData())
	{
		return false;
	}

	// Não encaixar um item em si mesmo nem em algo que ele carrega.
	AActor* SlotOwner = Slot->GetOwner();
	if (SlotOwner == Item || (SlotOwner && SlotOwner->IsAttachedTo(Item)))
	{
		Fail(Item, PCTags::AssemblyError_SlotMismatch);
		return false;
	}

	const FTransform ItemTransform = Item->GetActorTransform();
	const FGameplayTag PhysicalError = Slot->CheckPhysicalFit(*Item, ItemTransform,
		UPCSimulatorSettings::Get().OrientationToleranceDegrees);
	if (PhysicalError.IsValid())
	{
		Fail(Item, PhysicalError);
		return false;
	}
	if (!ArePrerequisitesMet(*Slot))
	{
		Fail(Item, PCTags::AssemblyError_MissingPrerequisite);
		return false;
	}

	// Contexto = instalado + dono do slot + o que o item carrega + candidato.
	TArray<UPCComponentDataAsset*> ContextData;
	GetInstalledData(ContextData);
	if (const AComputerComponent* Owner = Slot->GetOwningComputerComponent())
	{
		ContextData.AddUnique(Owner->GetData());
	}
	TArray<AActor*> Carried;
	Item->GetAttachedActors(Carried, true, true);
	for (AActor* Actor : Carried)
	{
		if (const AComputerComponent* Child = Cast<AComputerComponent>(Actor))
		{
			ContextData.AddUnique(Child->GetData());
		}
	}

	FCompatibilityResult Result;
	const FPCBuildContext Context = FPCBuildContext::Make(ContextData, Item->GetData(), Slot->SlotTag);
	if (!UPCCompatibilitySystem::EvaluateRuleSet(GetRuleSet(), Context, Result))
	{
		Fail(Item, PCTags::AssemblyError_Incompatible, Result.Reason);
		return false;
	}

	// Reserva imediata: evita dupla instalação durante a animação.
	Slot->SetOccupant(Item);
	Item->SetInstalledSlot(Slot);
	if (HeldItem.Get() == Item)
	{
		HeldItem.Reset();
	}
	OnInstallStarted.Broadcast(Item, Slot);

	const FSimpleDelegate OnFinished = FSimpleDelegate::CreateUObject(this, &ThisClass::FinishInstall,
		TWeakObjectPtr<AComputerComponent>(Item), TWeakObjectPtr<UPCAssemblySlotComponent>(Slot));

	if (UPCInstallAnimationComponent* Animation = Item->GetInstallAnimation())
	{
		Animation->Play(Slot->ComputeSnapTransform(ItemTransform), UPCSimulatorSettings::Get().InstallAnimationSeconds, OnFinished);
	}
	else
	{
		Item->SetActorTransform(Slot->ComputeSnapTransform(ItemTransform));
		OnFinished.ExecuteIfBound();
	}
	return true;
}

void UPCAssemblySystem::FinishInstall(TWeakObjectPtr<AComputerComponent> WeakItem, TWeakObjectPtr<UPCAssemblySlotComponent> WeakSlot)
{
	AComputerComponent* Item = WeakItem.Get();
	UPCAssemblySlotComponent* Slot = WeakSlot.Get();
	if (!Item || !Slot || Slot->GetOccupant() != Item)
	{
		return;
	}
	Item->AttachToComponent(Slot, FAttachmentTransformRules::KeepWorldTransform);
	Item->SetCollisionEnabledRecursive(true);

	UE_LOG(LogPCAssembly, Log, TEXT("Instalado %s em %s."), *Item->GetName(), *Slot->SlotTag.ToString());
	OnInstalled.Broadcast(Item, Slot);
}

void UPCAssemblySystem::DropHeld()
{
	AComputerComponent* Item = HeldItem.Get();
	if (!Item)
	{
		return;
	}
	HeldItem.Reset();

	// Apoia na superfície abaixo (bancada/chão) usando os bounds do ator.
	if (UWorld* World = GetWorld())
	{
		FVector Origin, Extent;
		Item->GetActorBounds(/*bOnlyCollidingComponents*/ false, Origin, Extent, /*bIncludeFromChildActors*/ true);
		const FVector Start = Item->GetActorLocation();
		const FVector End = Start - FVector(0.0, 0.0, 500.0);

		FCollisionQueryParams Params(SCENE_QUERY_STAT(PCDrop), false, Item);
		TArray<AActor*> Carried;
		Item->GetAttachedActors(Carried, true, true);
		Params.AddIgnoredActors(Carried);

		FHitResult Hit;
		if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params))
		{
			const double BottomOffset = Start.Z - (Origin.Z - Extent.Z);
			Item->SetActorLocation(FVector(Start.X, Start.Y, Hit.ImpactPoint.Z + BottomOffset));
		}
	}

	Item->SetCollisionEnabledRecursive(true);
	OnDropped.Broadcast(Item);
}

bool UPCAssemblySystem::TryConnectCable(UPCAssemblySlotComponent* Connector)
{
	if (bLocked || !Connector || !Connector->IsConnectorSlot() || !Connector->bEnabled)
	{
		return false;
	}
	if (Connector->IsCableConnected())
	{
		Fail(nullptr, PCTags::AssemblyError_SlotOccupied);
		return false;
	}

	const AComputerComponent* Owner = Connector->GetOwningComputerComponent();
	if (!Owner || !Owner->IsInstalled() || !ArePrerequisitesMet(*Connector))
	{
		Fail(nullptr, PCTags::AssemblyError_MissingPrerequisite, LOCTEXT("InstallFirst", "Instale o componente antes de ligar o cabo."));
		return false;
	}

	const UPCPSUDataAsset* Psu = FindInstalledPSU();
	if (!Psu)
	{
		Fail(nullptr, PCTags::AssemblyError_MissingPrerequisite, LOCTEXT("NoPsu", "Instale a fonte antes de ligar cabos."));
		return false;
	}
	if (Connector->RequiredSocket.IsValid() && !Psu->Connectors.HasTagExact(Connector->RequiredSocket))
	{
		Fail(nullptr, PCTags::AssemblyError_Incompatible, FText::Format(
			LOCTEXT("NoConnector", "A fonte {0} não tem o conector {1}."),
			Psu->DisplayName, FText::FromName(Connector->RequiredSocket.GetTagName())));
		return false;
	}

	Connector->SetCableConnected(true);
	UE_LOG(LogPCAssembly, Log, TEXT("Cabo conectado: %s."), *Connector->SlotTag.ToString());
	OnCableConnected.Broadcast(Connector);
	return true;
}

bool UPCAssemblySystem::TrySetPanelClosed(ACaseComponent* Case, bool bClosed)
{
	if (bLocked || !Case || Case->IsPanelClosed() == bClosed)
	{
		return false;
	}
	if (bClosed && PanelGate.IsBound() && !PanelGate.Execute())
	{
		Fail(Case, PCTags::AssemblyError_MissingPrerequisite, LOCTEXT("NotReady", "Instale todos os componentes e cabos antes de fechar."));
		return false;
	}
	Case->SetPanelClosed(bClosed);
	OnPanelChanged.Broadcast(Case, bClosed);
	return true;
}

void UPCAssemblySystem::ResetState()
{
	HeldItem.Reset();
	bLocked = false;
	Slots.RemoveAll([](const TWeakObjectPtr<UPCAssemblySlotComponent>& Weak) { return !Weak.IsValid(); });
}

// ---------------------------------------------------------------- Consultas

UPCAssemblySlotComponent* UPCAssemblySystem::FindNearestPhysicalSlot(const FVector& Location, float MaxDistance,
	const AComputerComponent* IgnoreItem) const
{
	UPCAssemblySlotComponent* Best = nullptr;
	double BestDistance = MaxDistance;

	for (const TWeakObjectPtr<UPCAssemblySlotComponent>& Weak : Slots)
	{
		UPCAssemblySlotComponent* Slot = Weak.Get();
		if (!Slot || !Slot->bEnabled || Slot->IsConnectorSlot())
		{
			continue;
		}
		const AActor* Owner = Slot->GetOwner();
		if (IgnoreItem && (Owner == IgnoreItem || (Owner && Owner->IsAttachedTo(IgnoreItem))))
		{
			continue;
		}
		const double Distance = FVector::Dist(Location, Slot->GetComponentLocation());
		if (Distance <= BestDistance)
		{
			BestDistance = Distance;
			Best = Slot;
		}
	}
	return Best;
}

bool UPCAssemblySystem::ArePrerequisitesMet(const UPCAssemblySlotComponent& Slot) const
{
	for (const FGameplayTag& Required : Slot.Prerequisites)
	{
		bool bSatisfied = false;
		for (const TWeakObjectPtr<UPCAssemblySlotComponent>& Weak : Slots)
		{
			const UPCAssemblySlotComponent* Other = Weak.Get();
			if (Other && Other->SlotTag.MatchesTagExact(Required) && Other->IsSatisfied())
			{
				bSatisfied = true;
				break;
			}
		}
		if (!bSatisfied)
		{
			return false;
		}
	}
	return true;
}

void UPCAssemblySystem::GetInstalledData(TArray<UPCComponentDataAsset*>& OutData) const
{
	OutData.Reset();
	for (const TWeakObjectPtr<UPCAssemblySlotComponent>& Weak : Slots)
	{
		const UPCAssemblySlotComponent* Slot = Weak.Get();
		const AComputerComponent* Occupant = Slot ? Slot->GetOccupant() : nullptr;
		if (!Occupant)
		{
			continue;
		}
		OutData.AddUnique(Occupant->GetData());
		if (const AComputerComponent* Owner = Slot->GetOwningComputerComponent())
		{
			OutData.AddUnique(Owner->GetData());
		}
	}
	OutData.Remove(nullptr);
}

// ---------------------------------------------------------------- Internos

void UPCAssemblySystem::Fail(AComputerComponent* Item, const FGameplayTag& Code, const FText& Reason)
{
	UE_LOG(LogPCAssembly, Log, TEXT("Falha (%s) em %s: %s"), *Code.ToString(),
		Item ? *Item->GetName() : TEXT("<conector/painel>"), *Reason.ToString());
	OnInstallFailed.Broadcast(Item, Code, Reason);
}

void UPCAssemblySystem::Fail(AComputerComponent* Item, const FGameplayTag& Code)
{
	Fail(Item, Code, PCMessages::Get(Code));
}

const UPCCompatibilityRuleSet* UPCAssemblySystem::GetRuleSet() const
{
	if (RuleSetOverride)
	{
		return RuleSetOverride;
	}
	const UGameInstance* GameInstance = GetWorld() ? GetWorld()->GetGameInstance() : nullptr;
	const UPCCompatibilitySystem* Compatibility = GameInstance ? GameInstance->GetSubsystem<UPCCompatibilitySystem>() : nullptr;
	return Compatibility ? Compatibility->GetRuleSet() : nullptr;
}

bool UPCAssemblySystem::IsInsideClosedCase(const AComputerComponent& Item) const
{
	for (const AActor* Parent = Item.GetAttachParentActor(); Parent; Parent = Parent->GetAttachParentActor())
	{
		if (const ACaseComponent* Case = Cast<ACaseComponent>(Parent))
		{
			return Case->IsPanelClosed();
		}
	}
	return false;
}

const UPCPSUDataAsset* UPCAssemblySystem::FindInstalledPSU() const
{
	for (const TWeakObjectPtr<UPCAssemblySlotComponent>& Weak : Slots)
	{
		const UPCAssemblySlotComponent* Slot = Weak.Get();
		if (const APSUComponent* Psu = Slot ? Cast<APSUComponent>(Slot->GetOccupant()) : nullptr)
		{
			return Psu->GetPSUData();
		}
	}
	return nullptr;
}

#undef LOCTEXT_NAMESPACE
