﻿#pragma once

#include "CoreMinimal.h"

/**
 * Regras geométricas puras dos slots (testáveis sem World).
 * Orientação é avaliada só no yaw relativo ao slot: o jogador escolhe a direção do item
 * (15° por passo); pitch/roll vêm do próprio slot no encaixe assistido.
 */
namespace PCSlotMath
{
	inline double SnapYaw(double YawDeg, double StepDeg)
	{
		if (StepDeg <= 0.0)
		{
			return FRotator::NormalizeAxis(YawDeg);
		}
		return FRotator::NormalizeAxis(FMath::RoundToDouble(YawDeg / StepDeg) * StepDeg);
	}

	/** Diferença angular absoluta em [0, 180]. */
	inline double AngularDistance(double A, double B)
	{
		return FMath::Abs(FRotator::NormalizeAxis(A - B));
	}

	/** Yaw permitido mais próximo (lista vazia = {0}). */
	inline double ClosestAllowedYaw(double RelativeYawDeg, const TArray<float>& AllowedYaws)
	{
		if (AllowedYaws.IsEmpty())
		{
			return 0.0;
		}
		double Best = AllowedYaws[0];
		for (const float Yaw : AllowedYaws)
		{
			if (AngularDistance(RelativeYawDeg, Yaw) < AngularDistance(RelativeYawDeg, Best))
			{
				Best = Yaw;
			}
		}
		return Best;
	}

	inline bool IsOrientationValid(double RelativeYawDeg, const TArray<float>& AllowedYaws, double ToleranceDeg)
	{
		return AngularDistance(RelativeYawDeg, ClosestAllowedYaw(RelativeYawDeg, AllowedYaws)) <= ToleranceDeg;
	}
}
