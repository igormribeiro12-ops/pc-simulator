﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Subsystems/WorldSubsystem.h"
#include "PCAssemblySystem.generated.h"

class ACaseComponent;
class AComputerComponent;
class UPCAssemblySlotComponent;
class UPCComponentDataAsset;
class UPCCompatibilityRuleSet;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FPCOnItemEvent, AComputerComponent*, Item);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnSlotItemEvent, AComputerComponent*, Item, UPCAssemblySlotComponent*, Slot);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FPCOnInstallFailed, AComputerComponent*, Item, FGameplayTag, ErrorCode, FText, Reason);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FPCOnSlotEvent, UPCAssemblySlotComponent*, Slot);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnPanelChanged, ACaseComponent*, Case, bool, bClosed);

/** Gate para fechar o painel (fornecido pelo ProgressTracker, sem dependência de include). */
DECLARE_DELEGATE_RetVal(bool, FPCCanClosePanel);

/**
 * Núcleo da montagem: pegar, mover, girar (snap), soltar, instalar, remover, cabos, painel.
 * Estado de ocupação vive nos slots (fonte única). Sem Tick: o item segurado é posicionado
 * pela câmera (UpdateHeldLocation).
 */
UCLASS()
class PCSIMULATOR_API UPCAssemblySystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	// ---- Registro de slots ----
	void RegisterSlot(UPCAssemblySlotComponent* Slot);
	void UnregisterSlot(UPCAssemblySlotComponent* Slot);
	void GetRegisteredSlots(TArray<UPCAssemblySlotComponent*>& OutSlots) const;

	// ---- Ações do jogador ----
	bool TryPickUp(AComputerComponent* Item);
	void UpdateHeldLocation(const FVector& WorldLocation);
	void RotateHeld(int32 Direction);
	/** Instala no slot mais próximo do item segurado. */
	bool TryInstallHeld();
	/** Instala Item em Slot (usado por TryInstallHeld e pelos testes). */
	bool TryInstall(AComputerComponent* Item, UPCAssemblySlotComponent* Slot);
	void DropHeld();
	bool TryConnectCable(UPCAssemblySlotComponent* Connector);
	bool TrySetPanelClosed(ACaseComponent* Case, bool bClosed);

	AComputerComponent* GetHeldItem() const { return HeldItem.Get(); }

	// ---- Consultas ----
	UPCAssemblySlotComponent* FindNearestPhysicalSlot(const FVector& Location, float MaxDistance, const AComputerComponent* IgnoreItem) const;
	bool ArePrerequisitesMet(const UPCAssemblySlotComponent& Slot) const;
	/** DataAssets de tudo que está instalado (+ donos de slots ocupados). */
	void GetInstalledData(TArray<UPCComponentDataAsset*>& OutData) const;

	// ---- Configuração ----
	void SetRuleSetOverride(UPCCompatibilityRuleSet* InRuleSet) { RuleSetOverride = InRuleSet; }
	void SetPanelGate(FPCCanClosePanel InGate) { PanelGate = MoveTemp(InGate); }
	/** Travado durante PowerSequence/ComputerRunning: nenhuma ação altera a montagem. */
	void SetLocked(bool bInLocked) { bLocked = bInLocked; }
	bool IsLocked() const { return bLocked; }

	/** Solta/limpa tudo (reset de sessão). */
	void ResetState();

	// ---- Eventos ----
	UPROPERTY(BlueprintAssignable) FPCOnItemEvent OnPickedUp;
	UPROPERTY(BlueprintAssignable) FPCOnItemEvent OnDropped;
	UPROPERTY(BlueprintAssignable) FPCOnItemEvent OnHeldRotated;
	/** Slot reservado; animação de encaixe começou. */
	UPROPERTY(BlueprintAssignable) FPCOnSlotItemEvent OnInstallStarted;
	/** Animação terminou; item encaixado (equivale ao AnimNotify_InstallationCompleted). */
	UPROPERTY(BlueprintAssignable) FPCOnSlotItemEvent OnInstalled;
	UPROPERTY(BlueprintAssignable) FPCOnSlotItemEvent OnRemoved;
	UPROPERTY(BlueprintAssignable) FPCOnInstallFailed OnInstallFailed;
	UPROPERTY(BlueprintAssignable) FPCOnSlotEvent OnCableConnected;
	UPROPERTY(BlueprintAssignable) FPCOnPanelChanged OnPanelChanged;

private:
	void Fail(AComputerComponent* Item, const FGameplayTag& Code, const FText& Reason);
	void Fail(AComputerComponent* Item, const FGameplayTag& Code);
	void FinishInstall(TWeakObjectPtr<AComputerComponent> WeakItem, TWeakObjectPtr<UPCAssemblySlotComponent> WeakSlot);
	const UPCCompatibilityRuleSet* GetRuleSet() const;
	bool IsInsideClosedCase(const AComputerComponent& Item) const;
	const class UPCPSUDataAsset* FindInstalledPSU() const;

	TArray<TWeakObjectPtr<UPCAssemblySlotComponent>> Slots;
	TWeakObjectPtr<AComputerComponent> HeldItem;
	FRotator HeldRotation = FRotator::ZeroRotator;

	UPROPERTY(Transient)
	TObjectPtr<UPCCompatibilityRuleSet> RuleSetOverride;

	FPCCanClosePanel PanelGate;
	bool bLocked = false;
};
