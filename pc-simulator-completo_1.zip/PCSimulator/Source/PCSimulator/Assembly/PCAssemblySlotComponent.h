﻿#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "GameplayTagContainer.h"
#include "PCAssemblySlotComponent.generated.h"

class AComputerComponent;

/**
 * Ponto de encaixe (§6.5). Posicionado no Blueprint do gabinete / placa-mãe / GPU.
 *  - Slot físico: recebe um AComputerComponent (CPU, RAM, GPU...).
 *  - Slot conector: AllowedTypes contém Component.Cable; representa um cabo lógico (decisão D10).
 * Checa apenas o que é local ao slot. Pré-requisitos e regras cruzadas ficam no UPCAssemblySystem.
 */
UCLASS(ClassGroup = (PC), meta = (BlueprintSpawnableComponent))
class PCSIMULATOR_API UPCAssemblySlotComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	UPCAssemblySlotComponent();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot", meta = (Categories = "Slot"))
	FGameplayTag SlotTag;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot", meta = (Categories = "Component"))
	FGameplayTagContainer AllowedTypes;

	/** Preenchido em runtime pelo dono quando depende do DataAsset (ex.: soquete da placa-mãe). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot", meta = (Categories = "Socket"))
	FGameplayTag RequiredSocket;

	/** Slots que precisam estar ocupados/conectados antes deste. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot", meta = (Categories = "Slot"))
	FGameplayTagContainer Prerequisites;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot", meta = (ClampMin = "0.1"))
	float SnapRadius = 8.f;

	/** Yaws aceitos relativos ao slot (ex.: RAM {0}; ventoinha {0, 180}). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot")
	TArray<float> AllowedYawOffsets = { 0.f };

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Slot")
	bool bEnabled = true;

	bool IsConnectorSlot() const;
	bool IsOccupied() const { return Occupant.IsValid(); }
	AComputerComponent* GetOccupant() const { return Occupant.Get(); }
	bool IsCableConnected() const { return bCableConnected; }

	/** "Concluído": slot físico ocupado ou conector ligado. */
	bool IsSatisfied() const { return IsConnectorSlot() ? bCableConnected : IsOccupied(); }

	void SetOccupant(AComputerComponent* Item) { Occupant = Item; }
	void ClearOccupant() { Occupant.Reset(); }
	void SetCableConnected(bool bConnected) { bCableConnected = bConnected; }

	/** Ator de hardware dono deste slot. */
	AComputerComponent* GetOwningComputerComponent() const;

	/** Checagem física local. Tag vazia = cabe. Não verifica pré-requisitos nem regras. */
	FGameplayTag CheckPhysicalFit(const AComputerComponent& Item, const FTransform& ItemWorldTransform, double OrientationToleranceDeg) const;

	double GetRelativeYaw(const FTransform& ItemWorldTransform) const;

	/** Transform final do item encaixado (posição do slot, yaw permitido mais próximo). */
	FTransform ComputeSnapTransform(const FTransform& ItemWorldTransform) const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	TWeakObjectPtr<AComputerComponent> Occupant;
	bool bCableConnected = false;
};
