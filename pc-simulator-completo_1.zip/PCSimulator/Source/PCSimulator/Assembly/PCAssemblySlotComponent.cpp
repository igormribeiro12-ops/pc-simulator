﻿#include "Assembly/PCAssemblySlotComponent.h"

#include "Assembly/PCAssemblySystem.h"
#include "Assembly/PCSlotMath.h"
#include "Components/ComputerComponent.h"
#include "Data/PCComponentDataAsset.h"
#include "Engine/World.h"
#include "Utilities/PCGameplayTags.h"

UPCAssemblySlotComponent::UPCAssemblySlotComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

bool UPCAssemblySlotComponent::IsConnectorSlot() const
{
	return AllowedTypes.HasTagExact(PCTags::Component_Cable);
}

AComputerComponent* UPCAssemblySlotComponent::GetOwningComputerComponent() const
{
	return Cast<AComputerComponent>(GetOwner());
}

double UPCAssemblySlotComponent::GetRelativeYaw(const FTransform& ItemWorldTransform) const
{
	return FRotator::NormalizeAxis(ItemWorldTransform.Rotator().Yaw - GetComponentRotation().Yaw);
}

FGameplayTag UPCAssemblySlotComponent::CheckPhysicalFit(const AComputerComponent& Item, const FTransform& ItemWorldTransform,
	double OrientationToleranceDeg) const
{
	if (!bEnabled || IsConnectorSlot())
	{
		return PCTags::AssemblyError_SlotMismatch;
	}
	if (IsOccupied())
	{
		return PCTags::AssemblyError_SlotOccupied;
	}

	const UPCComponentDataAsset* ItemData = Item.GetData();
	if (!ItemData || !AllowedTypes.HasTagExact(ItemData->Type))
	{
		return PCTags::AssemblyError_SlotMismatch;
	}
	if (RequiredSocket.IsValid() && !ItemData->RequiredSocket.MatchesTagExact(RequiredSocket))
	{
		return PCTags::AssemblyError_SlotMismatch;
	}
	if (FVector::Dist(ItemWorldTransform.GetLocation(), GetComponentLocation()) > SnapRadius)
	{
		return PCTags::AssemblyError_OutOfRange;
	}
	if (!PCSlotMath::IsOrientationValid(GetRelativeYaw(ItemWorldTransform), AllowedYawOffsets, OrientationToleranceDeg))
	{
		return PCTags::AssemblyError_WrongOrientation;
	}
	return FGameplayTag();
}

FTransform UPCAssemblySlotComponent::ComputeSnapTransform(const FTransform& ItemWorldTransform) const
{
	const double Yaw = PCSlotMath::ClosestAllowedYaw(GetRelativeYaw(ItemWorldTransform), AllowedYawOffsets);
	const FQuat Rotation = GetComponentQuat() * FRotator(0.0, Yaw, 0.0).Quaternion();
	return FTransform(Rotation, GetComponentLocation(), ItemWorldTransform.GetScale3D());
}

void UPCAssemblySlotComponent::BeginPlay()
{
	Super::BeginPlay();
	if (UWorld* World = GetWorld())
	{
		if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
		{
			Assembly->RegisterSlot(this);
		}
	}
}

void UPCAssemblySlotComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UWorld* World = GetWorld())
	{
		if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
		{
			Assembly->UnregisterSlot(this);
		}
	}
	Super::EndPlay(EndPlayReason);
}
