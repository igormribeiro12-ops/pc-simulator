﻿#include "Assembly/PCAssemblyProgressTracker.h"

#include "Assembly/PCAssemblySlotComponent.h"
#include "Assembly/PCAssemblySystem.h"
#include "Components/PCHardwareComponents.h"

#define LOCTEXT_NAMESPACE "PCProgress"

void UPCAssemblyProgressTracker::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	UPCAssemblySystem* AssemblySystem = Collection.InitializeDependency<UPCAssemblySystem>();
	Assembly = AssemblySystem;
	if (!AssemblySystem)
	{
		return;
	}

	AssemblySystem->OnInstalled.AddDynamic(this, &ThisClass::HandleSlotItem);
	AssemblySystem->OnRemoved.AddDynamic(this, &ThisClass::HandleSlotItem);
	AssemblySystem->OnCableConnected.AddDynamic(this, &ThisClass::HandleSlot);
	AssemblySystem->OnPanelChanged.AddDynamic(this, &ThisClass::HandlePanel);
	AssemblySystem->SetPanelGate(FPCCanClosePanel::CreateUObject(this, &ThisClass::AreComponentsAndCablesDone));
}

void UPCAssemblyProgressTracker::Deinitialize()
{
	if (UPCAssemblySystem* AssemblySystem = Assembly.Get())
	{
		AssemblySystem->OnInstalled.RemoveAll(this);
		AssemblySystem->OnRemoved.RemoveAll(this);
		AssemblySystem->OnCableConnected.RemoveAll(this);
		AssemblySystem->OnPanelChanged.RemoveAll(this);
		AssemblySystem->SetPanelGate(FPCCanClosePanel());
	}
	Super::Deinitialize();
}

void UPCAssemblyProgressTracker::SetTrackedItems(const TArray<AComputerComponent*>& Items)
{
	Tracked.Reset();
	TrackedCase.Reset();
	for (AComputerComponent* Item : Items)
	{
		if (ACaseComponent* Case = Cast<ACaseComponent>(Item))
		{
			TrackedCase = Case;
		}
		else if (Item)
		{
			Tracked.Add(Item);
		}
	}
	bWasComplete = false;
	DoneCount = -1; // força emissão do primeiro OnProgressChanged
	Recompute();
}

void UPCAssemblyProgressTracker::ClearTrackedItems()
{
	Tracked.Reset();
	TrackedCase.Reset();
	bWasComplete = false;
	DoneCount = 0;
	TotalCount = 0;
	OnProgressChanged.Broadcast(0, 0);
}

void UPCAssemblyProgressTracker::GatherConnectors(TArray<UPCAssemblySlotComponent*>& Out) const
{
	Out.Reset();
	auto Collect = [&Out](const AComputerComponent* Item)
	{
		TArray<UPCAssemblySlotComponent*> Slots;
		Item->GetSlots(Slots);
		for (UPCAssemblySlotComponent* Slot : Slots)
		{
			if (Slot->IsConnectorSlot() && Slot->bEnabled)
			{
				Out.Add(Slot);
			}
		}
	};
	for (const TWeakObjectPtr<AComputerComponent>& Weak : Tracked)
	{
		if (const AComputerComponent* Item = Weak.Get())
		{
			Collect(Item);
		}
	}
	if (const ACaseComponent* Case = TrackedCase.Get())
	{
		Collect(Case);
	}
}

bool UPCAssemblyProgressTracker::AreComponentsAndCablesDone() const
{
	if (Tracked.IsEmpty())
	{
		return false;
	}
	for (const TWeakObjectPtr<AComputerComponent>& Weak : Tracked)
	{
		const AComputerComponent* Item = Weak.Get();
		if (!Item || !Item->IsInstalled())
		{
			return false;
		}
	}
	TArray<UPCAssemblySlotComponent*> Connectors;
	GatherConnectors(Connectors);
	for (const UPCAssemblySlotComponent* Connector : Connectors)
	{
		if (!Connector->IsCableConnected())
		{
			return false;
		}
	}
	return true;
}

void UPCAssemblyProgressTracker::Recompute()
{
	int32 Done = 0;
	int32 Total = 0;

	for (const TWeakObjectPtr<AComputerComponent>& Weak : Tracked)
	{
		++Total;
		if (const AComputerComponent* Item = Weak.Get(); Item && Item->IsInstalled())
		{
			++Done;
		}
	}

	TArray<UPCAssemblySlotComponent*> Connectors;
	GatherConnectors(Connectors);
	for (const UPCAssemblySlotComponent* Connector : Connectors)
	{
		++Total;
		Done += Connector->IsCableConnected() ? 1 : 0;
	}

	if (const ACaseComponent* Case = TrackedCase.Get())
	{
		++Total;
		Done += Case->IsPanelClosed() ? 1 : 0;
	}

	const bool bChanged = (Done != DoneCount) || (Total != TotalCount);
	DoneCount = Done;
	TotalCount = Total;
	if (bChanged)
	{
		OnProgressChanged.Broadcast(DoneCount, TotalCount);
	}

	const bool bComplete = IsComplete();
	if (bComplete && !bWasComplete)
	{
		bWasComplete = true;
		OnAllRequirementsMet.Broadcast();
	}
	else if (!bComplete && bWasComplete)
	{
		bWasComplete = false;
		OnRequirementsBroken.Broadcast();
	}
}

void UPCAssemblyProgressTracker::GetRequirementStatus(TArray<FPCRequirementStatus>& Out) const
{
	Out.Reset();
	for (const TWeakObjectPtr<AComputerComponent>& Weak : Tracked)
	{
		if (const AComputerComponent* Item = Weak.Get())
		{
			FPCRequirementStatus& Row = Out.AddDefaulted_GetRef();
			Row.Label = Item->GetDisplayName();
			Row.bDone = Item->IsInstalled();
		}
	}

	TArray<UPCAssemblySlotComponent*> Connectors;
	GatherConnectors(Connectors);
	for (const UPCAssemblySlotComponent* Connector : Connectors)
	{
		FPCRequirementStatus& Row = Out.AddDefaulted_GetRef();
		Row.Label = FText::Format(LOCTEXT("Cable", "Cabo {0}"), FText::FromName(Connector->RequiredSocket.GetTagName()));
		Row.bDone = Connector->IsCableConnected();
	}

	if (const ACaseComponent* Case = TrackedCase.Get())
	{
		FPCRequirementStatus& Row = Out.AddDefaulted_GetRef();
		Row.Label = LOCTEXT("Panel", "Gabinete fechado");
		Row.bDone = Case->IsPanelClosed();
	}
}

void UPCAssemblyProgressTracker::HandleSlotItem(AComputerComponent* /*Item*/, UPCAssemblySlotComponent* /*Slot*/)
{
	Recompute();
}

void UPCAssemblyProgressTracker::HandleSlot(UPCAssemblySlotComponent* /*Slot*/)
{
	Recompute();
}

void UPCAssemblyProgressTracker::HandlePanel(ACaseComponent* /*Case*/, bool /*bClosed*/)
{
	Recompute();
}

#undef LOCTEXT_NAMESPACE
