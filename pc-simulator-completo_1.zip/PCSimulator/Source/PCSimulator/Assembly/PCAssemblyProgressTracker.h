﻿#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "PCAssemblyProgressTracker.generated.h"

class ACaseComponent;
class AComputerComponent;
class UPCAssemblySlotComponent;
class UPCAssemblySystem;

USTRUCT(BlueprintType)
struct PCSIMULATOR_API FPCRequirementStatus
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FText Label;

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	bool bDone = false;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnProgressChanged, int32, Done, int32, Total);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FPCOnRequirementsEvent);

/**
 * Requisitos da build atual: cada item instalado (exceto o gabinete), cada conector ligado e o painel fechado.
 * Recalcula apenas em eventos do AssemblySystem (sem polling).
 */
UCLASS()
class PCSIMULATOR_API UPCAssemblyProgressTracker : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	void SetTrackedItems(const TArray<AComputerComponent*>& Items);
	void ClearTrackedItems();

	int32 GetDoneCount() const { return DoneCount; }
	int32 GetTotalCount() const { return TotalCount; }
	float GetProgress01() const { return TotalCount > 0 ? static_cast<float>(DoneCount) / TotalCount : 0.f; }

	/** Tudo exceto o painel (condição para fechar o gabinete). */
	bool AreComponentsAndCablesDone() const;
	bool IsComplete() const { return TotalCount > 0 && DoneCount == TotalCount; }

	void GetRequirementStatus(TArray<FPCRequirementStatus>& Out) const;

	/** Recalcula e emite eventos se algo mudou. */
	void Recompute();

	UPROPERTY(BlueprintAssignable) FPCOnProgressChanged OnProgressChanged;
	UPROPERTY(BlueprintAssignable) FPCOnRequirementsEvent OnAllRequirementsMet;
	UPROPERTY(BlueprintAssignable) FPCOnRequirementsEvent OnRequirementsBroken;

private:
	UFUNCTION() void HandleSlotItem(AComputerComponent* Item, UPCAssemblySlotComponent* Slot);
	UFUNCTION() void HandleSlot(UPCAssemblySlotComponent* Slot);
	UFUNCTION() void HandlePanel(ACaseComponent* Case, bool bClosed);

	void GatherConnectors(TArray<UPCAssemblySlotComponent*>& Out) const;

	TArray<TWeakObjectPtr<AComputerComponent>> Tracked;
	TWeakObjectPtr<ACaseComponent> TrackedCase;
	TWeakObjectPtr<UPCAssemblySystem> Assembly;

	int32 DoneCount = 0;
	int32 TotalCount = 0;
	bool bWasComplete = false;
};
