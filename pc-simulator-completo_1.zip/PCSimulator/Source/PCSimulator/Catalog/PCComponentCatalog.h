﻿#pragma once

#include "CoreMinimal.h"
#include "Data/PCTypes.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "PCComponentCatalog.generated.h"

struct FStreamableHandle;

/**
 * Índice (Tag, Id) → DataAsset, sobre o AssetManager (fonte única; decisão D13).
 * Indexar não carrega assets: usa só FPrimaryAssetId + caminho.
 * Carga da build: DataAssets (LoadPrimaryAssets) → classes e meshes (RequestAsyncLoad), tudo assíncrono.
 */
UCLASS()
class PCSIMULATOR_API UPCComponentCatalog : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	/** Error.IsSet() == false em caso de sucesso. */
	using FOnLoadComplete = TDelegate<void(const FPCError& Error)>;

	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	/** Reconstrói o índice a partir do AssetManager. */
	void RebuildIndex();

	bool IsReady() const { return bIndexReady; }
	int32 Num() const { return Index.Num() + TestEntries.Num(); }

	bool Resolve(const FGameplayTag& Type, FName ComponentId, FPCComponentRef& OutRef, FPCError& OutError) const;
	bool ResolveAll(const FBuildConfiguration& Build, TArray<FPCComponentRef>& OutRefs, FPCError& OutError) const;

	/**
	 * Carrega DataAssets + ActorClass + Mesh. Valida Type (ComponentTypeMismatch) e ActorClass (AssetNotFound).
	 * Mantém tudo carregado até ReleaseLoaded().
	 */
	void LoadAsync(const TArray<FPCComponentRef>& Refs, FOnLoadComplete OnComplete);

	/** DataAsset já em memória (nullptr se não carregado). Nunca carrega. */
	UPCComponentDataAsset* GetLoaded(const FPCComponentRef& Ref) const;

	void ReleaseLoaded();

	/** Injeção para testes (sem AssetManager). O asset precisa estar em memória. */
	void RegisterEntryForTests(UPCComponentDataAsset* Asset);
	void ClearTestEntries();

private:
	void HandleDataLoaded(TArray<FPCComponentRef> Refs, FOnLoadComplete OnComplete);
	void HandleDependenciesLoaded(TArray<FPCComponentRef> Refs, FOnLoadComplete OnComplete);

	TMap<FName, FSoftObjectPath> Index;

	UPROPERTY(Transient)
	TMap<FName, TObjectPtr<UPCComponentDataAsset>> TestEntries;

	/** Mantém os DataAssets da build atual vivos (GC). */
	UPROPERTY(Transient)
	TArray<TObjectPtr<UPCComponentDataAsset>> LoadedBuildData;

	TArray<FPrimaryAssetId> LoadedPrimaryIds;
	TSharedPtr<FStreamableHandle> DataHandle;
	TSharedPtr<FStreamableHandle> DependencyHandle;
	bool bIndexReady = false;
};
