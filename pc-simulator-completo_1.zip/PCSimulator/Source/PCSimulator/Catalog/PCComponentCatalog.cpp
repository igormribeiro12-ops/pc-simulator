﻿#include "Catalog/PCComponentCatalog.h"

#include "Components/ComputerComponent.h" // TSoftClassPtr<AComputerComponent>::Get() exige o tipo completo
#include "Data/PCComponentDataAsset.h"
#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Utilities/PCGameplayTags.h"
#include "Utilities/PCLog.h"

void UPCComponentCatalog::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	if (UAssetManager::IsInitialized())
	{
		UAssetManager::CallOrRegister_OnCompletedInitialScan(
			FSimpleMulticastDelegate::FDelegate::CreateUObject(this, &ThisClass::RebuildIndex));
	}
	else
	{
		UE_LOG(LogPCCatalog, Error, TEXT("AssetManager não inicializado; catálogo vazio."));
	}
}

void UPCComponentCatalog::Deinitialize()
{
	ReleaseLoaded();
	Super::Deinitialize();
}

void UPCComponentCatalog::RebuildIndex()
{
	Index.Reset();
	UAssetManager& AssetManager = UAssetManager::Get();

	TArray<FPrimaryAssetId> Ids;
	AssetManager.GetPrimaryAssetIdList(UPCComponentDataAsset::PrimaryAssetType, Ids);

	for (const FPrimaryAssetId& Id : Ids)
	{
		const FSoftObjectPath Path = AssetManager.GetPrimaryAssetPath(Id);
		if (Path.IsValid())
		{
			Index.Add(Id.PrimaryAssetName, Path);
		}
	}

	bIndexReady = true;
	UE_LOG(LogPCCatalog, Log, TEXT("Catálogo indexado: %d componentes (nenhum asset carregado)."), Index.Num());
}

bool UPCComponentCatalog::Resolve(const FGameplayTag& Type, FName ComponentId, FPCComponentRef& OutRef, FPCError& OutError) const
{
	OutRef = FPCComponentRef();
	OutRef.Type = Type;
	OutRef.ComponentId = ComponentId;
	OutRef.AssetId = FPrimaryAssetId(UPCComponentDataAsset::PrimaryAssetType, ComponentId);

	if (const TObjectPtr<UPCComponentDataAsset>* TestAsset = TestEntries.Find(ComponentId))
	{
		OutRef.DataAsset = TestAsset->Get();
		return true;
	}
	if (const FSoftObjectPath* Path = Index.Find(ComponentId))
	{
		OutRef.DataAsset = TSoftObjectPtr<UPCComponentDataAsset>(*Path);
		return true;
	}

	OutError = FPCError::Make(PCTags::BuildError_UnknownComponentId,
		FString::Printf(TEXT("ID '%s' não existe no catálogo."), *ComponentId.ToString()),
		FString::Printf(TEXT("components.%s"), *Type.ToString()));
	return false;
}

bool UPCComponentCatalog::ResolveAll(const FBuildConfiguration& Build, TArray<FPCComponentRef>& OutRefs, FPCError& OutError) const
{
	OutRefs.Reset();

	// Ordem determinística: primeiro erro reportado não depende do hash do TMap.
	TArray<FGameplayTag> Types;
	Build.Components.GetKeys(Types);
	Types.Sort([](const FGameplayTag& A, const FGameplayTag& B) { return A.ToString() < B.ToString(); });

	for (const FGameplayTag& Type : Types)
	{
		FPCComponentRef Ref;
		if (!Resolve(Type, Build.Components.FindChecked(Type), Ref, OutError))
		{
			OutRefs.Reset();
			return false;
		}
		OutRefs.Add(MoveTemp(Ref));
	}
	return true;
}

void UPCComponentCatalog::LoadAsync(const TArray<FPCComponentRef>& Refs, FOnLoadComplete OnComplete)
{
	ReleaseLoaded();

	TArray<FPrimaryAssetId> ToLoad;
	for (const FPCComponentRef& Ref : Refs)
	{
		if (!TestEntries.Contains(Ref.ComponentId))
		{
			ToLoad.AddUnique(Ref.AssetId);
		}
	}

	if (ToLoad.IsEmpty())
	{
		HandleDataLoaded(Refs, OnComplete);
		return;
	}

	LoadedPrimaryIds = ToLoad;
	DataHandle = UAssetManager::Get().LoadPrimaryAssets(ToLoad, TArray<FName>(),
		FStreamableDelegate::CreateUObject(this, &ThisClass::HandleDataLoaded, Refs, OnComplete));
}

void UPCComponentCatalog::HandleDataLoaded(TArray<FPCComponentRef> Refs, FOnLoadComplete OnComplete)
{
	TArray<FSoftObjectPath> Dependencies;

	for (const FPCComponentRef& Ref : Refs)
	{
		UPCComponentDataAsset* Data = GetLoaded(Ref);
		if (!Data)
		{
			OnComplete.ExecuteIfBound(FPCError::Make(PCTags::BuildError_AssetNotFound,
				FString::Printf(TEXT("DataAsset de '%s' não carregou."), *Ref.ComponentId.ToString()),
				FString::Printf(TEXT("components.%s"), *Ref.Type.ToString())));
			return;
		}
		if (!Data->Type.MatchesTagExact(Ref.Type))
		{
			OnComplete.ExecuteIfBound(FPCError::Make(PCTags::BuildError_ComponentTypeMismatch,
				FString::Printf(TEXT("'%s' é %s, mas veio em %s."),
					*Ref.ComponentId.ToString(), *Data->Type.ToString(), *Ref.Type.ToString()),
				FString::Printf(TEXT("components.%s"), *Ref.Type.ToString())));
			return;
		}
		if (Data->ActorClass.IsNull())
		{
			OnComplete.ExecuteIfBound(FPCError::Make(PCTags::BuildError_AssetNotFound,
				FString::Printf(TEXT("'%s' sem ActorClass."), *Ref.ComponentId.ToString()),
				FString::Printf(TEXT("components.%s"), *Ref.Type.ToString())));
			return;
		}

		LoadedBuildData.AddUnique(Data);
		Dependencies.AddUnique(Data->ActorClass.ToSoftObjectPath());
		if (!Data->Mesh.IsNull())
		{
			Dependencies.AddUnique(Data->Mesh.ToSoftObjectPath());
		}
	}

	if (Dependencies.IsEmpty())
	{
		HandleDependenciesLoaded(Refs, OnComplete);
		return;
	}

	DependencyHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Dependencies,
		FStreamableDelegate::CreateUObject(this, &ThisClass::HandleDependenciesLoaded, Refs, OnComplete));
}

void UPCComponentCatalog::HandleDependenciesLoaded(TArray<FPCComponentRef> Refs, FOnLoadComplete OnComplete)
{
	for (const FPCComponentRef& Ref : Refs)
	{
		const UPCComponentDataAsset* Data = GetLoaded(Ref);
		if (!Data || !Data->ActorClass.Get())
		{
			OnComplete.ExecuteIfBound(FPCError::Make(PCTags::BuildError_AssetNotFound,
				FString::Printf(TEXT("ActorClass de '%s' não carregou."), *Ref.ComponentId.ToString()),
				FString::Printf(TEXT("components.%s"), *Ref.Type.ToString())));
			return;
		}
	}

	UE_LOG(LogPCCatalog, Log, TEXT("Build carregada: %d componentes."), Refs.Num());
	OnComplete.ExecuteIfBound(FPCError());
}

UPCComponentDataAsset* UPCComponentCatalog::GetLoaded(const FPCComponentRef& Ref) const
{
	if (const TObjectPtr<UPCComponentDataAsset>* TestAsset = TestEntries.Find(Ref.ComponentId))
	{
		return TestAsset->Get();
	}
	return Ref.DataAsset.Get();
}

void UPCComponentCatalog::ReleaseLoaded()
{
	if (DependencyHandle.IsValid())
	{
		DependencyHandle->ReleaseHandle();
		DependencyHandle.Reset();
	}
	if (DataHandle.IsValid())
	{
		DataHandle->ReleaseHandle();
		DataHandle.Reset();
	}
	if (!LoadedPrimaryIds.IsEmpty() && UAssetManager::IsInitialized())
	{
		UAssetManager::Get().UnloadPrimaryAssets(LoadedPrimaryIds);
	}
	LoadedPrimaryIds.Reset();
	LoadedBuildData.Reset();
}

void UPCComponentCatalog::RegisterEntryForTests(UPCComponentDataAsset* Asset)
{
	if (Asset && !Asset->ComponentId.IsNone())
	{
		TestEntries.Add(Asset->ComponentId, Asset);
	}
}

void UPCComponentCatalog::ClearTestEntries()
{
	TestEntries.Reset();
}
