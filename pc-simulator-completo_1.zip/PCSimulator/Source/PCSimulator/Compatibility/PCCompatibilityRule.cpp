﻿#include "Compatibility/PCCompatibilityRule.h"

FPCBuildContext FPCBuildContext::Make(const TArray<UPCComponentDataAsset*>& Items,
	UPCComponentDataAsset* InCandidate, FGameplayTag InTargetSlot)
{
	FPCBuildContext Context;
	for (UPCComponentDataAsset* Item : Items)
	{
		if (Item && Item->Type.IsValid())
		{
			Context.Components.Add(Item->Type, Item);
		}
	}
	if (InCandidate && InCandidate->Type.IsValid())
	{
		Context.Components.Add(InCandidate->Type, InCandidate);
	}
	Context.Candidate = InCandidate;
	Context.TargetSlot = InTargetSlot;
	return Context;
}
