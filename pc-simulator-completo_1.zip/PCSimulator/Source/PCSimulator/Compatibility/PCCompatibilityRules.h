﻿#pragma once

#include "CoreMinimal.h"
#include "Compatibility/PCCompatibilityRule.h"
#include "PCCompatibilityRules.generated.h"

/** Soquete da CPU == soquete da placa-mãe. */
UCLASS(meta = (DisplayName = "CPU Socket"))
class PCSIMULATOR_API UPCCPUSocketRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};

/** Geração da RAM == placa-mãe e módulos do kit <= slots de RAM. */
UCLASS(meta = (DisplayName = "RAM Generation"))
class PCSIMULATOR_API UPCRAMGenerationRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};

/** GPU PCIe x16 exige ao menos um slot x16 na placa-mãe. */
UCLASS(meta = (DisplayName = "GPU Slot"))
class PCSIMULATOR_API UPCGPUSlotRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};

/** Capacidade da PSU >= consumo * margem e >= maior recomendação de fonte. */
UCLASS(meta = (DisplayName = "PSU Wattage"))
class PCSIMULATOR_API UPCPSUWattageRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, Category = "Rule", meta = (ClampMin = "1.0", ClampMax = "3.0"))
	float Headroom = 1.3f;

	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};

/** PSU oferece todos os conectores de energia exigidos pela GPU. */
UCLASS(meta = (DisplayName = "Power Connectors"))
class PCSIMULATOR_API UPCPowerConnectorRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};

/** Form factor da placa-mãe suportado pelo gabinete. */
UCLASS(meta = (DisplayName = "Form Factor"))
class PCSIMULATOR_API UPCFormFactorRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};

/** Comprimento da GPU <= limite do gabinete. */
UCLASS(meta = (DisplayName = "GPU Length"))
class PCSIMULATOR_API UPCGPULengthRule : public UPCCompatibilityRule
{
	GENERATED_BODY()
public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const override;
};
