﻿#pragma once

#include "CoreMinimal.h"
#include "Data/PCComponentDataAsset.h"
#include "Data/PCTypes.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "PCCompatibilityRule.generated.h"

/**
 * Conjunto de componentes avaliado pelas regras.
 * Components inclui o candidato (quando houver). Ponteiros não-const: o UHT não aceita TObjectPtr<const T>.
 */
USTRUCT(BlueprintType)
struct PCSIMULATOR_API FPCBuildContext
{
	GENERATED_BODY()

	UPROPERTY()
	TMap<FGameplayTag, TObjectPtr<UPCComponentDataAsset>> Components;

	/** Item sendo instalado (nullptr na validação de build inteira). */
	UPROPERTY()
	TObjectPtr<UPCComponentDataAsset> Candidate = nullptr;

	UPROPERTY()
	FGameplayTag TargetSlot;

	template <class T>
	const T* Get(const FGameplayTag& Type) const
	{
		const TObjectPtr<UPCComponentDataAsset>* Found = Components.Find(Type);
		return Found ? Cast<T>(Found->Get()) : nullptr;
	}

	static FPCBuildContext Make(const TArray<UPCComponentDataAsset*>& Items,
		UPCComponentDataAsset* InCandidate = nullptr, FGameplayTag InTargetSlot = FGameplayTag());
};

/**
 * Regra de compatibilidade (decisão D2: UObject instanciado dentro do RuleSet, configurável no editor).
 * Contrato: devolve true se compatível OU se não aplicável (componentes relevantes ausentes).
 * Nova regra = nova subclasse + entrada no RuleSet. UPCCompatibilitySystem não muda.
 */
UCLASS(Abstract, EditInlineNew, DefaultToInstanced, CollapseCategories)
class PCSIMULATOR_API UPCCompatibilityRule : public UObject
{
	GENERATED_BODY()

public:
	virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
		PURE_VIRTUAL(UPCCompatibilityRule::Evaluate, return true;);
};

UCLASS(BlueprintType)
class PCSIMULATOR_API UPCCompatibilityRuleSet : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Instanced, Category = "Rules")
	TArray<TObjectPtr<UPCCompatibilityRule>> Rules;
};
