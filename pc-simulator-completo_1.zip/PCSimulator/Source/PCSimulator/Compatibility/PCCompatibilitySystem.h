﻿#pragma once

#include "CoreMinimal.h"
#include "Compatibility/PCCompatibilityRule.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "PCCompatibilitySystem.generated.h"

struct FStreamableHandle;

/**
 * Avalia o RuleSet configurado em UPCSimulatorSettings.
 * Não conhece nenhuma regra concreta. Sem RuleSet carregado, falha fechado (nunca aprova às cegas).
 */
UCLASS()
class PCSIMULATOR_API UPCCompatibilitySystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	bool IsReady() const { return RuleSet != nullptr; }

	bool Validate(const FPCBuildContext& Context, FCompatibilityResult& Out) const;

	/** Núcleo sem estado; também usado pelo AssemblySystem e pelos testes. */
	static bool EvaluateRuleSet(const UPCCompatibilityRuleSet* Rules, const FPCBuildContext& Context, FCompatibilityResult& Out);

	UPCCompatibilityRuleSet* GetRuleSet() const { return RuleSet; }

	/** Injeção (testes / ferramentas). */
	void SetRuleSet(UPCCompatibilityRuleSet* InRuleSet) { RuleSet = InRuleSet; }

private:
	void HandleRuleSetLoaded();

	UPROPERTY(Transient)
	TObjectPtr<UPCCompatibilityRuleSet> RuleSet;

	TSharedPtr<FStreamableHandle> LoadHandle;
};
