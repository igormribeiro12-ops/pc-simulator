﻿#include "Compatibility/PCCompatibilitySystem.h"

#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Utilities/PCGameplayTags.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCSimulatorSettings.h"

#define LOCTEXT_NAMESPACE "PCCompatibility"

void UPCCompatibilitySystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	const TSoftObjectPtr<UPCCompatibilityRuleSet>& Configured = UPCSimulatorSettings::Get().RuleSet;
	if (Configured.IsNull())
	{
		UE_LOG(LogPCCompatibility, Error, TEXT("RuleSet não configurado em Project Settings > PC Simulator."));
		return;
	}
	if (!UAssetManager::IsInitialized())
	{
		UE_LOG(LogPCCompatibility, Error, TEXT("AssetManager indisponível; RuleSet não carregado."));
		return;
	}
	LoadHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Configured.ToSoftObjectPath(),
		FStreamableDelegate::CreateUObject(this, &ThisClass::HandleRuleSetLoaded));
}

void UPCCompatibilitySystem::Deinitialize()
{
	if (LoadHandle.IsValid())
	{
		LoadHandle->ReleaseHandle();
		LoadHandle.Reset();
	}
	RuleSet = nullptr;
	Super::Deinitialize();
}

void UPCCompatibilitySystem::HandleRuleSetLoaded()
{
	RuleSet = UPCSimulatorSettings::Get().RuleSet.Get();
	if (RuleSet)
	{
		UE_LOG(LogPCCompatibility, Log, TEXT("RuleSet carregado: %d regras."), RuleSet->Rules.Num());
	}
	else
	{
		UE_LOG(LogPCCompatibility, Error, TEXT("Falha ao carregar o RuleSet configurado."));
	}
}

bool UPCCompatibilitySystem::Validate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	return EvaluateRuleSet(RuleSet, Context, Out);
}

bool UPCCompatibilitySystem::EvaluateRuleSet(const UPCCompatibilityRuleSet* Rules, const FPCBuildContext& Context, FCompatibilityResult& Out)
{
	if (!Rules)
	{
		UE_LOG(LogPCCompatibility, Error, TEXT("Validação sem RuleSet: rejeitando (falha fechada)."));
		Out = FCompatibilityResult::Fail(PCTags::AssemblyError_Incompatible,
			LOCTEXT("NoRules", "Regras de compatibilidade indisponíveis."));
		return false;
	}

	for (const TObjectPtr<UPCCompatibilityRule>& Rule : Rules->Rules)
	{
		if (!Rule)
		{
			continue;
		}
		FCompatibilityResult RuleResult;
		if (!Rule->Evaluate(Context, RuleResult))
		{
			UE_LOG(LogPCCompatibility, Verbose, TEXT("Regra %s reprovou: %s"),
				*Rule->GetClass()->GetName(), *RuleResult.Reason.ToString());
			Out = RuleResult;
			return false;
		}
	}

	Out = FCompatibilityResult::Pass();
	return true;
}

#undef LOCTEXT_NAMESPACE
