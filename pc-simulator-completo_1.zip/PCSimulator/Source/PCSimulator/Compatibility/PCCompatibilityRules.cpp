﻿#include "Compatibility/PCCompatibilityRules.h"

#include "Utilities/PCGameplayTags.h"

#define LOCTEXT_NAMESPACE "PCCompatibility"

namespace
{
	FText TagText(const FGameplayTag& Tag)
	{
		return FText::FromName(Tag.GetTagName());
	}

	bool Pass(FCompatibilityResult& Out)
	{
		Out = FCompatibilityResult::Pass();
		return true;
	}

	bool Reject(FCompatibilityResult& Out, const FText& Reason)
	{
		Out = FCompatibilityResult::Fail(PCTags::AssemblyError_Incompatible, Reason);
		return false;
	}
}

bool UPCCPUSocketRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCCPUDataAsset* Cpu = Context.Get<UPCCPUDataAsset>(PCTags::Component_CPU);
	const UPCMotherboardDataAsset* Board = Context.Get<UPCMotherboardDataAsset>(PCTags::Component_Motherboard);
	if (!Cpu || !Board || Cpu->RequiredSocket.MatchesTagExact(Board->CpuSocket))
	{
		return Pass(Out);
	}
	return Reject(Out, FText::Format(
		LOCTEXT("CpuSocket", "{0} usa o soquete {1}, mas a placa-mãe {2} tem o soquete {3}."),
		Cpu->DisplayName, TagText(Cpu->RequiredSocket), Board->DisplayName, TagText(Board->CpuSocket)));
}

bool UPCRAMGenerationRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCRAMDataAsset* Ram = Context.Get<UPCRAMDataAsset>(PCTags::Component_RAM);
	const UPCMotherboardDataAsset* Board = Context.Get<UPCMotherboardDataAsset>(PCTags::Component_Motherboard);
	if (!Ram || !Board)
	{
		return Pass(Out);
	}
	if (!Ram->RequiredSocket.MatchesTagExact(Board->RamSocket))
	{
		return Reject(Out, FText::Format(
			LOCTEXT("RamGen", "{0} é {1}, mas a placa-mãe {2} aceita {3}."),
			Ram->DisplayName, TagText(Ram->RequiredSocket), Board->DisplayName, TagText(Board->RamSocket)));
	}
	if (Ram->ModuleCount > Board->RamSlotCount)
	{
		return Reject(Out, FText::Format(
			LOCTEXT("RamSlots", "O kit {0} tem {1} módulos, mas a placa-mãe só tem {2} slots."),
			Ram->DisplayName, Ram->ModuleCount, Board->RamSlotCount));
	}
	return Pass(Out);
}

bool UPCGPUSlotRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCGPUDataAsset* Gpu = Context.Get<UPCGPUDataAsset>(PCTags::Component_GPU);
	const UPCMotherboardDataAsset* Board = Context.Get<UPCMotherboardDataAsset>(PCTags::Component_Motherboard);
	if (!Gpu || !Board || !Gpu->RequiredSocket.MatchesTagExact(PCTags::Socket_PCIe_x16) || Board->PcieX16Slots > 0)
	{
		return Pass(Out);
	}
	return Reject(Out, FText::Format(
		LOCTEXT("GpuSlot", "A placa-mãe {0} não tem slot PCIe x16 para {1}."), Board->DisplayName, Gpu->DisplayName));
}

bool UPCPSUWattageRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCPSUDataAsset* Psu = Context.Get<UPCPSUDataAsset>(PCTags::Component_PSU);
	if (!Psu)
	{
		return Pass(Out);
	}

	int32 TotalDraw = 0;
	int32 HighestRecommendation = 0;
	for (const TPair<FGameplayTag, TObjectPtr<UPCComponentDataAsset>>& Pair : Context.Components)
	{
		const UPCComponentDataAsset* Item = Pair.Value.Get();
		if (!Item || Pair.Key.MatchesTagExact(PCTags::Component_PSU))
		{
			continue;
		}
		TotalDraw += Item->PowerDrawWatts;
		HighestRecommendation = FMath::Max(HighestRecommendation, Item->RecommendedPsuWatts);
	}

	const int32 Required = FMath::CeilToInt(static_cast<float>(TotalDraw) * Headroom);
	if (Psu->CapacityWatts < Required)
	{
		return Reject(Out, FText::Format(
			LOCTEXT("PsuDraw", "Fonte {0} ({1} W) insuficiente: consumo estimado de {2} W com {3}% de margem exige {4} W."),
			Psu->DisplayName, Psu->CapacityWatts, TotalDraw, FMath::RoundToInt((Headroom - 1.f) * 100.f), Required));
	}
	if (Psu->CapacityWatts < HighestRecommendation)
	{
		return Reject(Out, FText::Format(
			LOCTEXT("PsuRecommended", "Fonte {0} ({1} W) abaixo da recomendação de {2} W de um componente."),
			Psu->DisplayName, Psu->CapacityWatts, HighestRecommendation));
	}
	return Pass(Out);
}

bool UPCPowerConnectorRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCGPUDataAsset* Gpu = Context.Get<UPCGPUDataAsset>(PCTags::Component_GPU);
	const UPCPSUDataAsset* Psu = Context.Get<UPCPSUDataAsset>(PCTags::Component_PSU);
	if (!Gpu || !Psu || Psu->Connectors.HasAllExact(Gpu->PowerConnectors))
	{
		return Pass(Out);
	}
	return Reject(Out, FText::Format(
		LOCTEXT("PsuConnectors", "A fonte {0} não tem os conectores de energia exigidos por {1} ({2})."),
		Psu->DisplayName, Gpu->DisplayName, FText::FromString(Gpu->PowerConnectors.ToStringSimple())));
}

bool UPCFormFactorRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCMotherboardDataAsset* Board = Context.Get<UPCMotherboardDataAsset>(PCTags::Component_Motherboard);
	const UPCCaseDataAsset* Case = Context.Get<UPCCaseDataAsset>(PCTags::Component_Case);
	if (!Board || !Case || Case->SupportedFormFactors.HasTagExact(Board->FormFactor))
	{
		return Pass(Out);
	}
	return Reject(Out, FText::Format(
		LOCTEXT("FormFactor", "O gabinete {0} não suporta placas {1}."), Case->DisplayName, TagText(Board->FormFactor)));
}

bool UPCGPULengthRule::Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
{
	const UPCGPUDataAsset* Gpu = Context.Get<UPCGPUDataAsset>(PCTags::Component_GPU);
	const UPCCaseDataAsset* Case = Context.Get<UPCCaseDataAsset>(PCTags::Component_Case);
	if (!Gpu || !Case || Case->MaxGpuLengthMm <= 0 || Gpu->LengthMm <= Case->MaxGpuLengthMm)
	{
		return Pass(Out);
	}
	return Reject(Out, FText::Format(
		LOCTEXT("GpuLength", "{0} tem {1} mm, mas o gabinete {2} aceita até {3} mm."),
		Gpu->DisplayName, Gpu->LengthMm, Case->DisplayName, Case->MaxGpuLengthMm));
}

#undef LOCTEXT_NAMESPACE
