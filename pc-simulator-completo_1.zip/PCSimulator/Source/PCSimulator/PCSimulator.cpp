﻿#include "PCSimulator.h"

#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY(LogPCSimulator);

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, PCSimulator, "PCSimulator");
