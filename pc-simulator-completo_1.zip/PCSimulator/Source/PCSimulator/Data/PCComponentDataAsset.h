﻿#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "PCComponentDataAsset.generated.h"

class AComputerComponent;
class UStaticMesh;

/**
 * Definição de um componente de hardware. Abstrata: use uma subclasse tipada.
 * Identidade no AssetManager: ("PCComponent", ComponentId). ComponentId é globalmente único.
 */
UCLASS(Abstract, BlueprintType)
class PCSIMULATOR_API UPCComponentDataAsset : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	static const FPrimaryAssetType PrimaryAssetType;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
	FName ComponentId;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity", meta = (Categories = "Component"))
	FGameplayTag Type;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
	FText DisplayName;

	/** Preço de referência em USD na data do catálogo (0 = sem preço). Só informativo. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity", meta = (ClampMin = "0.0"))
	float ReferencePriceUsd = 0.f;

	/** Socket físico que o componente exige no slot (inválido = sem restrição). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Socket", meta = (Categories = "Socket"))
	FGameplayTag RequiredSocket;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Assets")
	TSoftClassPtr<AComputerComponent> ActorClass;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Assets")
	TSoftObjectPtr<UStaticMesh> Mesh;

	/** Consumo total do item (um kit de RAM = soma dos módulos). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Power", meta = (ClampMin = "0"))
	int32 PowerDrawWatts = 0;

	/** Fonte recomendada pelo fabricante (0 = sem recomendação). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Power", meta = (ClampMin = "0"))
	int32 RecommendedPsuWatts = 0;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effects")
	bool bHasRGB = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effects", meta = (EditCondition = "bHasRGB"))
	FLinearColor RGBColor = FLinearColor(0.2f, 0.5f, 1.f);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effects", meta = (EditCondition = "bHasRGB", ClampMin = "0.0"))
	float RGBIntensity = 20.f;

	/** Tipo que esta subclasse representa. */
	virtual FGameplayTag GetExpectedType() const PURE_VIRTUAL(UPCComponentDataAsset::GetExpectedType, return FGameplayTag(););

	virtual FPrimaryAssetId GetPrimaryAssetId() const override;

#if WITH_EDITOR
	virtual EDataValidationResult IsDataValid(class FDataValidationContext& Context) const override;
#endif
};

UCLASS()
class PCSIMULATOR_API UPCCPUDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "CPU", meta = (ClampMin = "1"))
	int32 Cores = 6;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "CPU", meta = (ClampMin = "1"))
	int32 Threads = 12;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCGPUDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GPU", meta = (ClampMin = "0"))
	int32 LengthMm = 0;

	/** Conectores de energia exigidos (Socket.Power.*). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "GPU", meta = (Categories = "Socket.Power"))
	FGameplayTagContainer PowerConnectors;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCMotherboardDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Motherboard", meta = (Categories = "Socket.CPU"))
	FGameplayTag CpuSocket;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Motherboard", meta = (Categories = "Socket.RAM"))
	FGameplayTag RamSocket;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Motherboard", meta = (ClampMin = "1"))
	int32 RamSlotCount = 2;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Motherboard", meta = (Categories = "FormFactor"))
	FGameplayTag FormFactor;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Motherboard", meta = (ClampMin = "0"))
	int32 PcieX16Slots = 1;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Motherboard", meta = (ClampMin = "0"))
	int32 M2Slots = 1;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCRAMDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	/** Kit de varejo: um ID = N módulos (decisão D4). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RAM", meta = (ClampMin = "1", ClampMax = "8"))
	int32 ModuleCount = 2;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RAM", meta = (ClampMin = "1"))
	int32 CapacityPerModuleGB = 8;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "RAM", meta = (ClampMin = "1"))
	int32 SpeedMTs = 3200;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCStorageDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Storage", meta = (ClampMin = "1"))
	int32 CapacityGB = 1000;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCPSUDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PSU", meta = (ClampMin = "1"))
	int32 CapacityWatts = 650;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PSU")
	FText Efficiency;

	/** Conectores disponíveis (Socket.PSU.ATX24, Socket.Power.*). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PSU", meta = (Categories = "Socket"))
	FGameplayTagContainer Connectors;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCCaseDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Case", meta = (Categories = "FormFactor"))
	FGameplayTagContainer SupportedFormFactors;

	/** 0 = sem limite. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Case", meta = (ClampMin = "0"))
	int32 MaxGpuLengthMm = 0;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Case", meta = (ClampMin = "0"))
	int32 FanSlots = 1;

	virtual FGameplayTag GetExpectedType() const override;
};

UCLASS()
class PCSIMULATOR_API UPCFanDataAsset : public UPCComponentDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Fan", meta = (ClampMin = "40"))
	int32 SizeMm = 120;

	virtual FGameplayTag GetExpectedType() const override;
};
