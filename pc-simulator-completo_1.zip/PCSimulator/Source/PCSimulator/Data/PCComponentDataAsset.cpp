﻿#include "Data/PCComponentDataAsset.h"

#include "Data/PCTypes.h"
#include "Utilities/PCGameplayTags.h"

#if WITH_EDITOR
#include "Misc/DataValidation.h"
#endif

#define LOCTEXT_NAMESPACE "PCComponentDataAsset"

const FPrimaryAssetType UPCComponentDataAsset::PrimaryAssetType(TEXT("PCComponent"));

FPrimaryAssetId UPCComponentDataAsset::GetPrimaryAssetId() const
{
	// CDO e assets sem ID não são primary assets válidos.
	if (HasAnyFlags(RF_ClassDefaultObject) || ComponentId.IsNone())
	{
		return FPrimaryAssetId();
	}
	return FPrimaryAssetId(PrimaryAssetType, ComponentId);
}

#if WITH_EDITOR
EDataValidationResult UPCComponentDataAsset::IsDataValid(FDataValidationContext& Context) const
{
	EDataValidationResult Result = Super::IsDataValid(Context);

	if (!PCIds::IsValidComponentId(ComponentId.ToString()))
	{
		Context.AddError(FText::Format(
			LOCTEXT("BadId", "ComponentId '{0}' inválido: use apenas a-z, 0-9 e _ (1 a 64 caracteres)."),
			FText::FromName(ComponentId)));
		Result = EDataValidationResult::Invalid;
	}
	if (!Type.MatchesTagExact(GetExpectedType()))
	{
		Context.AddError(FText::Format(
			LOCTEXT("BadType", "Type '{0}' não corresponde à classe (esperado '{1}')."),
			FText::FromName(Type.GetTagName()), FText::FromName(GetExpectedType().GetTagName())));
		Result = EDataValidationResult::Invalid;
	}
	if (ActorClass.IsNull())
	{
		Context.AddError(LOCTEXT("NoActorClass", "ActorClass não definido."));
		Result = EDataValidationResult::Invalid;
	}
	if (DisplayName.IsEmpty())
	{
		Context.AddWarning(LOCTEXT("NoName", "DisplayName vazio."));
	}
	return Result;
}
#endif

FGameplayTag UPCCPUDataAsset::GetExpectedType() const { return PCTags::Component_CPU; }
FGameplayTag UPCGPUDataAsset::GetExpectedType() const { return PCTags::Component_GPU; }
FGameplayTag UPCMotherboardDataAsset::GetExpectedType() const { return PCTags::Component_Motherboard; }
FGameplayTag UPCRAMDataAsset::GetExpectedType() const { return PCTags::Component_RAM; }
FGameplayTag UPCStorageDataAsset::GetExpectedType() const { return PCTags::Component_Storage; }
FGameplayTag UPCPSUDataAsset::GetExpectedType() const { return PCTags::Component_PSU; }
FGameplayTag UPCCaseDataAsset::GetExpectedType() const { return PCTags::Component_Case; }
FGameplayTag UPCFanDataAsset::GetExpectedType() const { return PCTags::Component_Fan; }

#undef LOCTEXT_NAMESPACE
