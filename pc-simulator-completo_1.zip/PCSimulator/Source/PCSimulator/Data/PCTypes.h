﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "UObject/PrimaryAssetId.h"
#include "PCTypes.generated.h"

class UPCComponentDataAsset;

/** Referência resolvida pelo catálogo. Não carrega nada por si só. */
USTRUCT(BlueprintType)
struct PCSIMULATOR_API FPCComponentRef
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PC")
	FGameplayTag Type;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PC")
	FName ComponentId;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PC")
	TSoftObjectPtr<UPCComponentDataAsset> DataAsset;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "PC")
	FPrimaryAssetId AssetId;
};

/** Resultado do parse de uma build (§6.2). Só valores; nunca instancia nada. */
USTRUCT(BlueprintType)
struct PCSIMULATOR_API FBuildConfiguration
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	int32 SchemaVersion = 1;

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FString BuildId;

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	TMap<FGameplayTag, FName> Components;

	/** true somente após catálogo + carga + compatibilidade. */
	UPROPERTY(BlueprintReadOnly, Category = "PC")
	bool bValidated = false;
};

USTRUCT(BlueprintType)
struct PCSIMULATOR_API FCompatibilityResult
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	bool bCompatible = false;

	/** Vazio quando compatível. */
	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FGameplayTag ErrorCode;

	/** Motivo localizável, exibido ao jogador. */
	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FText Reason;

	static FCompatibilityResult Pass()
	{
		FCompatibilityResult R;
		R.bCompatible = true;
		return R;
	}

	static FCompatibilityResult Fail(const FGameplayTag& Code, const FText& InReason)
	{
		FCompatibilityResult R;
		R.bCompatible = false;
		R.ErrorCode = Code;
		R.Reason = InReason;
		return R;
	}
};

/** Erro tipado usado por parser, catálogo e receiver. Code vazio = sem erro. */
USTRUCT(BlueprintType)
struct PCSIMULATOR_API FPCError
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FGameplayTag Code;

	/** Texto técnico (log / build.error.detail). Não localizado. */
	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FString Detail;

	/** Caminho do campo no JSON (ex.: "components.Component.GPU"). */
	UPROPERTY(BlueprintReadOnly, Category = "PC")
	FString Field;

	bool IsSet() const { return Code.IsValid(); }

	static FPCError Make(const FGameplayTag& InCode, const FString& InDetail, const FString& InField = FString())
	{
		FPCError E;
		E.Code = InCode;
		E.Detail = InDetail;
		E.Field = InField;
		return E;
	}
};

namespace PCIds
{
	/** ^[a-z0-9_]{1,64}$ (FName é case-insensitive; o contrato fixa minúsculas). */
	PCSIMULATOR_API bool IsValidComponentId(const FString& Id);

	/** UUID canônico minúsculo 8-4-4-4-12. */
	PCSIMULATOR_API bool IsCanonicalUuid(const FString& Value);
}
