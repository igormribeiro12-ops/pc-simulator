﻿#include "Data/PCTypes.h"

namespace PCIds
{
	bool IsValidComponentId(const FString& Id)
	{
		if (Id.Len() < 1 || Id.Len() > 64)
		{
			return false;
		}
		for (const TCHAR C : Id)
		{
			const bool bLower = C >= TEXT('a') && C <= TEXT('z');
			const bool bDigit = C >= TEXT('0') && C <= TEXT('9');
			if (!bLower && !bDigit && C != TEXT('_'))
			{
				return false;
			}
		}
		return true;
	}

	bool IsCanonicalUuid(const FString& Value)
	{
		if (Value.Len() != 36)
		{
			return false;
		}
		for (int32 i = 0; i < 36; ++i)
		{
			const TCHAR C = Value[i];
			if (i == 8 || i == 13 || i == 18 || i == 23)
			{
				if (C != TEXT('-'))
				{
					return false;
				}
				continue;
			}
			const bool bHex = (C >= TEXT('0') && C <= TEXT('9')) || (C >= TEXT('a') && C <= TEXT('f'));
			if (!bHex)
			{
				return false;
			}
		}
		return true;
	}
}
