﻿#pragma once

#include "Engine/EngineTypes.h"

/**
 * Canal de trace "PCInteraction" (DefaultEngine.ini → ECC_GameTraceChannel1, resposta padrão Ignore).
 * Só malhas de componentes e o painel do gabinete bloqueiam este canal.
 */
inline constexpr ECollisionChannel PCInteractionChannel = ECC_GameTraceChannel1;
