﻿#include "Interaction/PCInteractionComponent.h"

#include "Assembly/PCAssemblySlotComponent.h"
#include "Assembly/PCAssemblySystem.h"
#include "Camera/PCCameraComponent.h"
#include "Components/PCHardwareComponents.h"
#include "Core/PCPlayerController.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "Interaction/PCCollision.h"
#include "Utilities/PCSimulatorSettings.h"

UPCInteractionComponent::UPCInteractionComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UPCInteractionComponent::BeginPlay()
{
	Super::BeginPlay();
	const float Rate = FMath::Max(1.f, UPCSimulatorSettings::Get().InteractionRateHz);
	GetWorld()->GetTimerManager().SetTimer(FocusTimer, this, &ThisClass::UpdateFocus, 1.f / Rate, /*bLoop*/ true);
}

void UPCInteractionComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(FocusTimer);
	}
	SetFocus(nullptr, nullptr);
	UnbindFromController();
	Super::EndPlay(EndPlayReason);
}

void UPCInteractionComponent::BindToController(APCPlayerController* Controller)
{
	UnbindFromController();
	if (!Controller)
	{
		return;
	}
	BoundController = Controller;
	Controller->OnInteractRequested.AddUniqueDynamic(this, &ThisClass::HandleInteract);
	Controller->OnDropRequested.AddUniqueDynamic(this, &ThisClass::HandleDrop);
	Controller->OnRotateRequested.AddUniqueDynamic(this, &ThisClass::HandleRotate);
	Controller->OnInspectToggled.AddUniqueDynamic(this, &ThisClass::HandleInspect);
}

void UPCInteractionComponent::UnbindFromController()
{
	if (APCPlayerController* Controller = BoundController.Get())
	{
		Controller->OnInteractRequested.RemoveDynamic(this, &ThisClass::HandleInteract);
		Controller->OnDropRequested.RemoveDynamic(this, &ThisClass::HandleDrop);
		Controller->OnRotateRequested.RemoveDynamic(this, &ThisClass::HandleRotate);
		Controller->OnInspectToggled.RemoveDynamic(this, &ThisClass::HandleInspect);
	}
	BoundController.Reset();
}

void UPCInteractionComponent::UpdateFocus()
{
	const APawn* Pawn = Cast<APawn>(GetOwner());
	const AController* Controller = Pawn ? Pawn->GetController() : nullptr;
	UWorld* World = GetWorld();
	if (!Controller || !World)
	{
		SetFocus(nullptr, nullptr);
		return;
	}

	FVector ViewLocation;
	FRotator ViewRotation;
	Controller->GetPlayerViewPoint(ViewLocation, ViewRotation);

	const UPCSimulatorSettings& Settings = UPCSimulatorSettings::Get();
	const FVector End = ViewLocation + ViewRotation.Vector() * Settings.InteractionRangeCm;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(PCInteraction), false, GetOwner());
	FHitResult Hit;
	if (!World->LineTraceSingleByChannel(Hit, ViewLocation, End, PCInteractionChannel, Params))
	{
		SetFocus(nullptr, nullptr);
		return;
	}

	AComputerComponent* Item = Cast<AComputerComponent>(Hit.GetActor());
	UPCAssemblySlotComponent* Connector = nullptr;
	if (Item)
	{
		double BestDistance = Settings.ConnectorPickRadiusCm;
		TArray<UPCAssemblySlotComponent*> Slots;
		Item->GetSlots(Slots);
		for (UPCAssemblySlotComponent* Slot : Slots)
		{
			if (!Slot->IsConnectorSlot() || !Slot->bEnabled)
			{
				continue;
			}
			const double Distance = FVector::Dist(Hit.ImpactPoint, Slot->GetComponentLocation());
			if (Distance <= BestDistance)
			{
				BestDistance = Distance;
				Connector = Slot;
			}
		}
	}
	SetFocus(Item, Connector);
}

void UPCInteractionComponent::SetFocus(AComputerComponent* Item, UPCAssemblySlotComponent* Connector)
{
	if (FocusedItem.Get() == Item && FocusedConnector.Get() == Connector)
	{
		return;
	}
	if (AComputerComponent* Previous = FocusedItem.Get(); Previous && Previous != Item)
	{
		Previous->SetHighlighted(false);
	}
	FocusedItem = Item;
	FocusedConnector = Connector;
	if (Item)
	{
		Item->SetHighlighted(true);
	}
	OnFocusChanged.Broadcast(Item, Connector);
}

void UPCInteractionComponent::HandleInteract()
{
	UPCAssemblySystem* Assembly = GetWorld() ? GetWorld()->GetSubsystem<UPCAssemblySystem>() : nullptr;
	if (!Assembly)
	{
		return;
	}

	// Prioridade: item na mão → conector mirado → painel do gabinete → pegar item.
	if (Assembly->GetHeldItem())
	{
		Assembly->TryInstallHeld();
		return;
	}
	if (UPCAssemblySlotComponent* Connector = FocusedConnector.Get(); Connector && !Connector->IsCableConnected())
	{
		Assembly->TryConnectCable(Connector);
		return;
	}
	if (ACaseComponent* Case = Cast<ACaseComponent>(FocusedItem.Get()))
	{
		Assembly->TrySetPanelClosed(Case, !Case->IsPanelClosed());
		return;
	}
	if (AComputerComponent* Item = FocusedItem.Get())
	{
		Assembly->TryPickUp(Item);
	}
}

void UPCInteractionComponent::HandleDrop()
{
	if (UPCAssemblySystem* Assembly = GetWorld() ? GetWorld()->GetSubsystem<UPCAssemblySystem>() : nullptr)
	{
		Assembly->DropHeld();
	}
}

void UPCInteractionComponent::HandleRotate(int32 Direction)
{
	if (UPCAssemblySystem* Assembly = GetWorld() ? GetWorld()->GetSubsystem<UPCAssemblySystem>() : nullptr)
	{
		Assembly->RotateHeld(Direction);
	}
}

void UPCInteractionComponent::HandleInspect()
{
	UPCCameraComponent* Camera = GetOwner() ? GetOwner()->FindComponentByClass<UPCCameraComponent>() : nullptr;
	if (!Camera)
	{
		return;
	}
	const UPCAssemblySystem* Assembly = GetWorld() ? GetWorld()->GetSubsystem<UPCAssemblySystem>() : nullptr;
	AActor* Target = (Assembly && Assembly->GetHeldItem()) ? static_cast<AActor*>(Assembly->GetHeldItem()) : FocusedItem.Get();
	Camera->ToggleInspect(Target);
}
