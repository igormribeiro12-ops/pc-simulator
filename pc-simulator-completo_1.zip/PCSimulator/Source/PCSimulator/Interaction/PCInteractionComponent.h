﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "TimerManager.h"
#include "PCInteractionComponent.generated.h"

class AComputerComponent;
class APCPlayerController;
class UPCAssemblySlotComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnFocusChanged, AComputerComponent*, Item, UPCAssemblySlotComponent*, Connector);

/**
 * Raycast de interação (canal PCInteraction, alcance em Settings) a 30 Hz via timer (decisão D8, sem Tick).
 * Mantém o foco (item e/ou conector), aplica highlight e traduz comandos do controller
 * em chamadas ao UPCAssemblySystem.
 */
UCLASS(ClassGroup = (PC), meta = (BlueprintSpawnableComponent))
class PCSIMULATOR_API UPCInteractionComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UPCInteractionComponent();

	void BindToController(APCPlayerController* Controller);
	void UnbindFromController();

	AComputerComponent* GetFocusedItem() const { return FocusedItem.Get(); }
	UPCAssemblySlotComponent* GetFocusedConnector() const { return FocusedConnector.Get(); }

	/** Um passo do trace (público para testes). */
	void UpdateFocus();

	UPROPERTY(BlueprintAssignable)
	FPCOnFocusChanged OnFocusChanged;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UFUNCTION() void HandleInteract();
	UFUNCTION() void HandleDrop();
	UFUNCTION() void HandleRotate(int32 Direction);
	UFUNCTION() void HandleInspect();

	void SetFocus(AComputerComponent* Item, UPCAssemblySlotComponent* Connector);

	FTimerHandle FocusTimer;
	TWeakObjectPtr<AComputerComponent> FocusedItem;
	TWeakObjectPtr<UPCAssemblySlotComponent> FocusedConnector;
	TWeakObjectPtr<APCPlayerController> BoundController;
};
