﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "PCGameState.generated.h"

UENUM(BlueprintType)
enum class EPCGameState : uint8
{
	WaitingForBuild,
	LoadingBuild,
	BuildReady,
	AssemblyInProgress,
	AssemblyCompleted,
	PowerSequence,
	ComputerRunning,
	Error
};

namespace PCFsm
{
	/**
	 * Tabela de transições (Architecture.md §9). Auto-transição nunca é válida.
	 * Qualquer estado → Error; qualquer estado → WaitingForBuild (ResetSession).
	 */
	PCSIMULATOR_API bool IsTransitionAllowed(EPCGameState From, EPCGameState To);
}

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnGameStateChanged, EPCGameState, OldState, EPCGameState, NewState);

/** Guarda o estado atual para observadores (UI). Só o APCGameMode escreve. */
UCLASS()
class PCSIMULATOR_API APCGameState : public AGameStateBase
{
	GENERATED_BODY()

public:
	EPCGameState GetPCState() const { return CurrentState; }

	UPROPERTY(BlueprintAssignable)
	FPCOnGameStateChanged OnPCStateChanged;

private:
	friend class APCGameMode;
	void SetPCState(EPCGameState NewState);

	EPCGameState CurrentState = EPCGameState::WaitingForBuild;
};
