﻿#pragma once

#include "CoreMinimal.h"
#include "Build/IPCBuildReceiver.h"
#include "Core/PCGameState.h"
#include "GameFramework/GameModeBase.h"
#include "PCGameMode.generated.h"

class AComputerComponent;
class APCGameState;

/**
 * Único dono da FSM EPCGameState (§10). Orquestra por delegates:
 * Receiver → Spawner → Assembly/Tracker → Power. Não contém regra de montagem.
 */
UCLASS()
class PCSIMULATOR_API APCGameMode : public AGameModeBase, public IPCBuildReceiver
{
	GENERATED_BODY()

public:
	APCGameMode();

	// IPCBuildReceiver
	virtual void OnBuildReceived(const FBuildConfiguration& Build) override;
	virtual void OnBuildRejected(FGameplayTag ErrorCode, const FString& Detail) override;

	EPCGameState GetCurrentState() const;

	/** Limpa atores/estado e volta a WaitingForBuild. */
	void ResetSession();

	/** Console: PCResetSession */
	UFUNCTION(Exec)
	void PCResetSession();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void PostLogin(APlayerController* NewPlayer) override;

private:
	bool TransitionTo(EPCGameState NewState);
	APCGameState* GetPCGameState() const;

	UFUNCTION() void HandleBuildSpawned(const TArray<AComputerComponent*>& Items);
	UFUNCTION() void HandleSpawnFailed(FGameplayTag Code, const FString& Detail);
	UFUNCTION() void HandlePickedUp(AComputerComponent* Item);
	UFUNCTION() void HandleAllRequirementsMet();
	UFUNCTION() void HandleRequirementsBroken();
	UFUNCTION() void HandlePowerRequested();
	UFUNCTION() void HandlePowerStarted();
	UFUNCTION() void HandleBootCompleted();
	UFUNCTION() void HandlePowerFailed(FGameplayTag Code, FText Reason);
};
