﻿#include "Core/PCGameMode.h"

#include "Assembly/PCAssemblyProgressTracker.h"
#include "Assembly/PCAssemblySystem.h"
#include "Build/PCBuildReceiver.h"
#include "Build/PCBuildSpawner.h"
#include "Components/ComputerComponent.h"
#include "Core/PCGameState.h"
#include "Core/PCPlayerController.h"
#include "Core/PCPlayerPawn.h"
#include "Effects/PCPowerSystem.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"
#include "UI/PCHUD.h"
#include "Utilities/PCLog.h"

APCGameMode::APCGameMode()
{
	DefaultPawnClass = APCPlayerPawn::StaticClass();
	PlayerControllerClass = APCPlayerController::StaticClass();
	GameStateClass = APCGameState::StaticClass();
	HUDClass = APCHUD::StaticClass();
}

void APCGameMode::BeginPlay()
{
	Super::BeginPlay();
	UWorld* World = GetWorld();

	if (UPCBuildSpawner* Spawner = World->GetSubsystem<UPCBuildSpawner>())
	{
		Spawner->OnBuildSpawned.AddUniqueDynamic(this, &ThisClass::HandleBuildSpawned);
		Spawner->OnSpawnFailed.AddUniqueDynamic(this, &ThisClass::HandleSpawnFailed);
	}
	if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
	{
		Assembly->OnPickedUp.AddUniqueDynamic(this, &ThisClass::HandlePickedUp);
	}
	if (UPCAssemblyProgressTracker* Tracker = World->GetSubsystem<UPCAssemblyProgressTracker>())
	{
		Tracker->OnAllRequirementsMet.AddUniqueDynamic(this, &ThisClass::HandleAllRequirementsMet);
		Tracker->OnRequirementsBroken.AddUniqueDynamic(this, &ThisClass::HandleRequirementsBroken);
	}
	if (UPCPowerSystem* Power = World->GetSubsystem<UPCPowerSystem>())
	{
		Power->OnPowerSequenceStarted.AddUniqueDynamic(this, &ThisClass::HandlePowerStarted);
		Power->OnBootCompleted.AddUniqueDynamic(this, &ThisClass::HandleBootCompleted);
		Power->OnPowerFailed.AddUniqueDynamic(this, &ThisClass::HandlePowerFailed);
	}
	if (UPCBuildReceiver* Receiver = GetGameInstance()->GetSubsystem<UPCBuildReceiver>())
	{
		Receiver->RegisterSink(this);
		Receiver->SetAcceptingBuilds(GetCurrentState() == EPCGameState::WaitingForBuild);
	}
}

void APCGameMode::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UPCBuildReceiver* Receiver = GetGameInstance() ? GetGameInstance()->GetSubsystem<UPCBuildReceiver>() : nullptr)
	{
		Receiver->UnregisterSink(this);
		Receiver->SetAcceptingBuilds(false);
	}
	Super::EndPlay(EndPlayReason);
}

void APCGameMode::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	if (APCPlayerController* Controller = Cast<APCPlayerController>(NewPlayer))
	{
		Controller->OnPowerRequested.AddUniqueDynamic(this, &ThisClass::HandlePowerRequested);
	}
}

APCGameState* APCGameMode::GetPCGameState() const
{
	return GetGameState<APCGameState>();
}

EPCGameState APCGameMode::GetCurrentState() const
{
	const APCGameState* State = GetPCGameState();
	return State ? State->GetPCState() : EPCGameState::WaitingForBuild;
}

bool APCGameMode::TransitionTo(EPCGameState NewState)
{
	APCGameState* State = GetPCGameState();
	if (!State)
	{
		return false;
	}
	const EPCGameState Current = State->GetPCState();
	if (Current == NewState)
	{
		return true;
	}

	if (!PCFsm::IsTransitionAllowed(Current, NewState))
	{
		const FString From = StaticEnum<EPCGameState>()->GetNameStringByValue(static_cast<int64>(Current));
		const FString To = StaticEnum<EPCGameState>()->GetNameStringByValue(static_cast<int64>(NewState));
		ensureMsgf(false, TEXT("Transição inválida %s → %s"), *From, *To);
		UE_LOG(LogPCBuild, Error, TEXT("Transição inválida %s → %s; indo para Error."), *From, *To);
		State->SetPCState(EPCGameState::Error);
		return false;
	}

	State->SetPCState(NewState);
	if (UPCBuildReceiver* Receiver = GetGameInstance()->GetSubsystem<UPCBuildReceiver>())
	{
		Receiver->SetAcceptingBuilds(NewState == EPCGameState::WaitingForBuild);
	}
	return true;
}

void APCGameMode::ResetSession()
{
	UWorld* World = GetWorld();
	if (UPCPowerSystem* Power = World->GetSubsystem<UPCPowerSystem>())
	{
		Power->ResetPower();
	}
	if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
	{
		Assembly->ResetState();
	}
	if (UPCAssemblyProgressTracker* Tracker = World->GetSubsystem<UPCAssemblyProgressTracker>())
	{
		Tracker->ClearTrackedItems();
	}
	if (UPCBuildSpawner* Spawner = World->GetSubsystem<UPCBuildSpawner>())
	{
		Spawner->DespawnAll();
	}
	if (UPCBuildReceiver* Receiver = GetGameInstance()->GetSubsystem<UPCBuildReceiver>())
	{
		Receiver->ClearCurrentBuild();
	}
	TransitionTo(EPCGameState::WaitingForBuild);
}

void APCGameMode::PCResetSession()
{
	ResetSession();
}

// ---------------------------------------------------------------- Eventos

void APCGameMode::OnBuildReceived(const FBuildConfiguration& /*Build*/)
{
	if (!TransitionTo(EPCGameState::LoadingBuild))
	{
		return;
	}
	UPCBuildReceiver* Receiver = GetGameInstance()->GetSubsystem<UPCBuildReceiver>();
	UPCBuildSpawner* Spawner = GetWorld()->GetSubsystem<UPCBuildSpawner>();
	if (Receiver && Spawner)
	{
		Spawner->SpawnFromRefs(Receiver->GetCurrentRefs()); // resultado chega por OnBuildSpawned/OnSpawnFailed
	}
	else
	{
		TransitionTo(EPCGameState::Error);
	}
}

void APCGameMode::OnBuildRejected(FGameplayTag ErrorCode, const FString& Detail)
{
	// Rejeição não muda o estado: o jogo segue aguardando uma build válida. A UI assina o receiver.
	UE_LOG(LogPCBuild, Log, TEXT("GameMode ciente da rejeição %s: %s"), *ErrorCode.ToString(), *Detail);
}

void APCGameMode::HandleBuildSpawned(const TArray<AComputerComponent*>& Items)
{
	if (UPCAssemblyProgressTracker* Tracker = GetWorld()->GetSubsystem<UPCAssemblyProgressTracker>())
	{
		Tracker->SetTrackedItems(Items);
	}
	TransitionTo(EPCGameState::BuildReady);
}

void APCGameMode::HandleSpawnFailed(FGameplayTag /*Code*/, const FString& /*Detail*/)
{
	TransitionTo(EPCGameState::Error);
}

void APCGameMode::HandlePickedUp(AComputerComponent* /*Item*/)
{
	if (GetCurrentState() == EPCGameState::BuildReady)
	{
		TransitionTo(EPCGameState::AssemblyInProgress);
	}
}

void APCGameMode::HandleAllRequirementsMet()
{
	if (GetCurrentState() == EPCGameState::AssemblyInProgress)
	{
		TransitionTo(EPCGameState::AssemblyCompleted);
	}
}

void APCGameMode::HandleRequirementsBroken()
{
	if (GetCurrentState() == EPCGameState::AssemblyCompleted)
	{
		TransitionTo(EPCGameState::AssemblyInProgress);
	}
}

void APCGameMode::HandlePowerRequested()
{
	if (UPCPowerSystem* Power = GetWorld()->GetSubsystem<UPCPowerSystem>())
	{
		// O PowerSystem valida os pré-requisitos e responde com OnPowerFailed se faltar algo.
		Power->RequestPowerOn();
	}
}

void APCGameMode::HandlePowerStarted()
{
	TransitionTo(EPCGameState::PowerSequence);
}

void APCGameMode::HandleBootCompleted()
{
	TransitionTo(EPCGameState::ComputerRunning);
}

void APCGameMode::HandlePowerFailed(FGameplayTag /*Code*/, FText /*Reason*/)
{
	if (GetCurrentState() == EPCGameState::PowerSequence)
	{
		TransitionTo(EPCGameState::AssemblyCompleted);
	}
}
