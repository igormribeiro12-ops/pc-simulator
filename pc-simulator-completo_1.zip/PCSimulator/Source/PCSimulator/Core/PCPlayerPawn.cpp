﻿#include "Core/PCPlayerPawn.h"

#include "Camera/PCCameraComponent.h"
#include "Components/SceneComponent.h"
#include "Core/PCOrbitMath.h"
#include "Core/PCPlayerController.h"
#include "Engine/World.h"
#include "GameFramework/SpringArmComponent.h"
#include "Interaction/PCInteractionComponent.h"

APCPlayerPawn::APCPlayerPawn()
{
	PrimaryActorTick.bCanEverTick = false;

	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	Pivot = CreateDefaultSubobject<USceneComponent>(TEXT("Pivot"));
	SetRootComponent(Pivot);

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(Pivot);
	SpringArm->bUsePawnControlRotation = false;
	// Bancada fechada: o teste de colisão faria a câmera "saltar" ao orbitar perto do gabinete.
	SpringArm->bDoCollisionTest = false;

	Camera = CreateDefaultSubobject<UPCCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);

	Interaction = CreateDefaultSubobject<UPCInteractionComponent>(TEXT("Interaction"));
}

void APCPlayerPawn::BeginPlay()
{
	Super::BeginPlay();
	const FVector Origin = GetActorLocation();
	PanBounds = FBox(Origin - PanHalfExtent, Origin + PanHalfExtent);
}

void APCPlayerPawn::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);
	Interaction->BindToController(Cast<APCPlayerController>(NewController));
}

void APCPlayerPawn::UnPossessed()
{
	Interaction->UnbindFromController();
	Super::UnPossessed();
}

void APCPlayerPawn::AddPanInput(const FVector2D& Input)
{
	const UWorld* World = GetWorld();
	if (!World || Input.IsNearlyZero() || Camera->IsInspecting())
	{
		return;
	}

	const double Distance = static_cast<double>(PanSpeed) * World->GetDeltaSeconds();
	const double Yaw = SpringArm->GetComponentRotation().Yaw;
	const FVector Delta = PCOrbitMath::ComputePanDelta(Input, Yaw, Distance);

	SetActorLocation(PCOrbitMath::ClampToBounds(GetActorLocation() + Delta, PanBounds));
}

void APCPlayerPawn::AddOrbitInput(const FVector2D& Input)
{
	Camera->AddOrbitInput(Input);
}

void APCPlayerPawn::AddZoomInput(float Input)
{
	Camera->AddZoomInput(Input);
}
