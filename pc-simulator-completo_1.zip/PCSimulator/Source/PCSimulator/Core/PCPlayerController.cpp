﻿#include "Core/PCPlayerController.h"

#include "Core/PCPlayerPawn.h"
#include "Engine/LocalPlayer.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputAction.h"
#include "InputActionValue.h"
#include "InputMappingContext.h"
#include "PCSimulator.h"

bool APCPlayerController::HasCompleteInputConfig(TArray<FString>& OutMissing) const
{
	OutMissing.Reset();

	struct FInputAssetEntry
	{
		const TCHAR* Name;
		const UObject* Asset;
	};

	const FInputAssetEntry Entries[] =
	{
		{ TEXT("DefaultMappingContext"), DefaultMappingContext.Get() },
		{ TEXT("MoveAction"),            MoveAction.Get() },
		{ TEXT("LookAction"),            LookAction.Get() },
		{ TEXT("ZoomAction"),            ZoomAction.Get() },
		{ TEXT("InteractAction"),        InteractAction.Get() },
		{ TEXT("RotateAction"),          RotateAction.Get() },
		{ TEXT("DropAction"),            DropAction.Get() },
		{ TEXT("InspectAction"),         InspectAction.Get() },
		{ TEXT("PowerAction"),           PowerAction.Get() },
	};

	for (const FInputAssetEntry& Entry : Entries)
	{
		if (Entry.Asset == nullptr)
		{
			OutMissing.Add(Entry.Name);
		}
	}
	return OutMissing.IsEmpty();
}

void APCPlayerController::BeginPlay()
{
	Super::BeginPlay();

	TArray<FString> Missing;
	if (!HasCompleteInputConfig(Missing))
	{
		// Recuperável (o jogo roda, só sem esses inputs), mas é erro de configuração.
		UE_LOG(LogPCSimulator, Error,
			TEXT("%s: assets de input não atribuídos: %s. Atribua-os em BP_PCPlayerController."),
			*GetName(), *FString::Join(Missing, TEXT(", ")));
	}

	if (IsLocalController() && DefaultMappingContext)
	{
		if (UEnhancedInputLocalPlayerSubsystem* InputSubsystem =
			ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer()))
		{
			InputSubsystem->AddMappingContext(DefaultMappingContext, MappingPriority);
		}
	}

	SetInputMode(FInputModeGameOnly());
	SetShowMouseCursor(false);
}

void APCPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	UEnhancedInputComponent* EnhancedInput = Cast<UEnhancedInputComponent>(InputComponent);
	if (!EnhancedInput)
	{
		UE_LOG(LogPCSimulator, Error,
			TEXT("%s: InputComponent não é UEnhancedInputComponent. Verifique DefaultInputComponentClass em DefaultInput.ini."),
			*GetName());
		return;
	}

	// Contínuos: Triggered (a cada frame enquanto ativo).
	if (MoveAction)
	{
		EnhancedInput->BindAction(MoveAction, ETriggerEvent::Triggered, this, &ThisClass::HandleMove);
	}
	if (LookAction)
	{
		EnhancedInput->BindAction(LookAction, ETriggerEvent::Triggered, this, &ThisClass::HandleLook);
	}
	if (ZoomAction)
	{
		EnhancedInput->BindAction(ZoomAction, ETriggerEvent::Triggered, this, &ThisClass::HandleZoom);
	}

	// Discretos: Started (uma vez por pressionamento).
	if (RotateAction)
	{
		EnhancedInput->BindAction(RotateAction, ETriggerEvent::Started, this, &ThisClass::HandleRotate);
	}
	if (InteractAction)
	{
		EnhancedInput->BindAction(InteractAction, ETriggerEvent::Started, this, &ThisClass::HandleInteract);
	}
	if (DropAction)
	{
		EnhancedInput->BindAction(DropAction, ETriggerEvent::Started, this, &ThisClass::HandleDrop);
	}
	if (InspectAction)
	{
		EnhancedInput->BindAction(InspectAction, ETriggerEvent::Started, this, &ThisClass::HandleInspect);
	}
	if (PowerAction)
	{
		EnhancedInput->BindAction(PowerAction, ETriggerEvent::Started, this, &ThisClass::HandlePower);
	}
}

void APCPlayerController::HandleMove(const FInputActionValue& Value)
{
	if (APCPlayerPawn* PCPawn = GetPawn<APCPlayerPawn>())
	{
		PCPawn->AddPanInput(Value.Get<FVector2D>());
	}
}

void APCPlayerController::HandleLook(const FInputActionValue& Value)
{
	if (APCPlayerPawn* PCPawn = GetPawn<APCPlayerPawn>())
	{
		PCPawn->AddOrbitInput(Value.Get<FVector2D>());
	}
}

void APCPlayerController::HandleZoom(const FInputActionValue& Value)
{
	if (APCPlayerPawn* PCPawn = GetPawn<APCPlayerPawn>())
	{
		PCPawn->AddZoomInput(Value.Get<float>());
	}
}

void APCPlayerController::HandleRotate(const FInputActionValue& Value)
{
	const float Axis = Value.Get<float>();
	const int32 Direction = Axis > 0.f ? 1 : (Axis < 0.f ? -1 : 0);
	if (Direction != 0)
	{
		OnRotateRequested.Broadcast(Direction);
	}
}

void APCPlayerController::HandleInteract()
{
	OnInteractRequested.Broadcast();
}

void APCPlayerController::HandleDrop()
{
	OnDropRequested.Broadcast();
}

void APCPlayerController::HandleInspect()
{
	OnInspectToggled.Broadcast();
}

void APCPlayerController::HandlePower()
{
	OnPowerRequested.Broadcast();
}
