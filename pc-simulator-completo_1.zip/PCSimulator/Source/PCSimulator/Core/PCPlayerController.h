﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "PCPlayerController.generated.h"

class UInputAction;
class UInputMappingContext;
struct FInputActionValue;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FPCOnInputCommand);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FPCOnRotateCommand, int32, Direction);

/**
 * Ponte entre o Enhanced Input e o jogo.
 *
 * - Câmera (Move/Look/Zoom): encaminhada direto ao APCPlayerPawn.
 * - Comandos de gameplay (Interact/Rotate/Drop/Inspect/Power): publicados como delegates.
 *   Os sistemas das fases seguintes (Interaction, Assembly, Power) assinam os delegates.
 *   O controller nunca conhece esses sistemas, e a dependência aponta de lá para cá.
 *
 * Os assets de input são atribuídos em BP_PCPlayerController (binding de asset, permitido pelo §1).
 * Obs.: APlayerController precisa de Tick (processamento de input da engine). É uma exceção
 * da engine, não da lógica do projeto.
 */
UCLASS()
class PCSIMULATOR_API APCPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintAssignable, Category = "PC|Input")
	FPCOnInputCommand OnInteractRequested;

	UPROPERTY(BlueprintAssignable, Category = "PC|Input")
	FPCOnInputCommand OnDropRequested;

	UPROPERTY(BlueprintAssignable, Category = "PC|Input")
	FPCOnInputCommand OnInspectToggled;

	UPROPERTY(BlueprintAssignable, Category = "PC|Input")
	FPCOnInputCommand OnPowerRequested;

	/** Direction = +1 ou -1 (um passo de snap; o tamanho do passo é do AssemblySystem). */
	UPROPERTY(BlueprintAssignable, Category = "PC|Input")
	FPCOnRotateCommand OnRotateRequested;

	/** true se todos os assets de input estão atribuídos. OutMissing recebe os nomes ausentes. */
	bool HasCompleteInputConfig(TArray<FString>& OutMissing) const;

protected:
	virtual void BeginPlay() override;
	virtual void SetupInputComponent() override;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputMappingContext> DefaultMappingContext;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	int32 MappingPriority = 0;

	/** Axis2D */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> MoveAction;

	/** Axis2D */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> LookAction;

	/** Axis1D */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> ZoomAction;

	/** Digital (bool) */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> InteractAction;

	/** Axis1D: o sinal define a direção */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> RotateAction;

	/** Digital (bool) */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> DropAction;

	/** Digital (bool) */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> InspectAction;

	/** Digital (bool) */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Input")
	TObjectPtr<UInputAction> PowerAction;

private:
	void HandleMove(const FInputActionValue& Value);
	void HandleLook(const FInputActionValue& Value);
	void HandleZoom(const FInputActionValue& Value);
	void HandleRotate(const FInputActionValue& Value);
	void HandleInteract();
	void HandleDrop();
	void HandleInspect();
	void HandlePower();
};
