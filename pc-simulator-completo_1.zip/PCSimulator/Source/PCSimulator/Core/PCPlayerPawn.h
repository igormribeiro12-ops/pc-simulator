﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "PCPlayerPawn.generated.h"

class UPCCameraComponent;
class UPCInteractionComponent;
class USceneComponent;
class USpringArmComponent;

/**
 * Pawn orbital da bancada (decisão D9: APawn, sem locomoção).
 *  Move → pan do pivô no plano XY, limitado a PanHalfExtent em torno do spawn (bloqueado em inspeção).
 *  Look/Zoom → UPCCameraComponent (suavizado).
 * O Pawn não tem Tick; a câmera tem Tick só enquanto interpola.
 */
UCLASS()
class PCSIMULATOR_API APCPlayerPawn : public APawn
{
	GENERATED_BODY()

public:
	APCPlayerPawn();

	void AddPanInput(const FVector2D& Input);
	void AddOrbitInput(const FVector2D& Input);
	void AddZoomInput(float Input);

	const FBox& GetPanBounds() const { return PanBounds; }
	USpringArmComponent* GetSpringArm() const { return SpringArm; }
	UPCCameraComponent* GetCamera() const { return Camera; }
	UPCInteractionComponent* GetInteraction() const { return Interaction; }

protected:
	virtual void BeginPlay() override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC|Camera")
	TObjectPtr<USceneComponent> Pivot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC|Camera")
	TObjectPtr<USpringArmComponent> SpringArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC|Camera")
	TObjectPtr<UPCCameraComponent> Camera;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC|Interaction")
	TObjectPtr<UPCInteractionComponent> Interaction;

	/** Velocidade de pan em cm/s para input de magnitude 1. */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "0.0"))
	float PanSpeed = 100.f;

	/** Meia-extensão do volume de pan em torno do ponto de spawn (cm). */
	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera")
	FVector PanHalfExtent = FVector(100.0, 100.0, 0.0);

private:
	FBox PanBounds = FBox(ForceInit);
};
