﻿#pragma once

#include "CoreMinimal.h"

/**
 * Funções puras da câmera orbital.
 * Separadas do Pawn para serem testáveis sem World (PCSimulator.Unit.Camera.OrbitMath).
 * Todos os ângulos em graus; todas as distâncias em cm.
 * Parâmetros em double para casar com FRotator/FVector (LWC da UE5) sem ambiguidade de template.
 */
namespace PCOrbitMath
{
	/** Aplica delta de órbita. Yaw é normalizado para (-180, 180]; pitch é limitado; roll zerado. */
	inline FRotator ApplyOrbit(const FRotator& Current, double DeltaYawDeg, double DeltaPitchDeg,
		double MinPitchDeg, double MaxPitchDeg)
	{
		FRotator Result;
		Result.Yaw = FRotator::NormalizeAxis(Current.Yaw + DeltaYawDeg);
		Result.Pitch = FMath::Clamp(Current.Pitch + DeltaPitchDeg, MinPitchDeg, MaxPitchDeg);
		Result.Roll = 0.0;
		return Result;
	}

	/** Novo comprimento do braço, limitado a [Min, Max]. */
	inline float ApplyZoom(float CurrentLength, float Delta, float MinLength, float MaxLength)
	{
		return FMath::Clamp(CurrentLength + Delta, MinLength, MaxLength);
	}

	/**
	 * Converte input 2D de pan (X = direita, Y = frente) num deslocamento no plano XY
	 * alinhado ao yaw da câmera. Distance = quanto andar para input de magnitude 1.
	 */
	inline FVector ComputePanDelta(const FVector2D& Input, double YawDeg, double Distance)
	{
		const FRotator YawOnly(0.0, YawDeg, 0.0);
		const FVector Forward = YawOnly.RotateVector(FVector::ForwardVector);
		const FVector Right = YawOnly.RotateVector(FVector::RightVector);
		return (Forward * Input.Y + Right * Input.X) * Distance;
	}

	/** Limita a posição ao volume. Volume inválido (ainda não inicializado) não limita. */
	inline FVector ClampToBounds(const FVector& Location, const FBox& Bounds)
	{
		if (!Bounds.IsValid)
		{
			return Location;
		}
		return FVector(
			FMath::Clamp(Location.X, Bounds.Min.X, Bounds.Max.X),
			FMath::Clamp(Location.Y, Bounds.Min.Y, Bounds.Max.Y),
			FMath::Clamp(Location.Z, Bounds.Min.Z, Bounds.Max.Z));
	}
}
