﻿#include "Core/PCGameState.h"

namespace PCFsm
{
	bool IsTransitionAllowed(EPCGameState From, EPCGameState To)
	{
		if (From == To)
		{
			return false;
		}
		if (To == EPCGameState::Error || To == EPCGameState::WaitingForBuild)
		{
			return true;
		}

		struct FEdge
		{
			EPCGameState From;
			EPCGameState To;
		};
		static constexpr FEdge Allowed[] =
		{
			{ EPCGameState::WaitingForBuild,    EPCGameState::LoadingBuild },
			{ EPCGameState::LoadingBuild,       EPCGameState::BuildReady },
			{ EPCGameState::BuildReady,         EPCGameState::AssemblyInProgress },
			{ EPCGameState::AssemblyInProgress, EPCGameState::AssemblyCompleted },
			{ EPCGameState::AssemblyCompleted,  EPCGameState::AssemblyInProgress },
			{ EPCGameState::AssemblyCompleted,  EPCGameState::PowerSequence },
			{ EPCGameState::PowerSequence,      EPCGameState::ComputerRunning },
			{ EPCGameState::PowerSequence,      EPCGameState::AssemblyCompleted },
		};

		for (const FEdge& Edge : Allowed)
		{
			if (Edge.From == From && Edge.To == To)
			{
				return true;
			}
		}
		return false;
	}
}

void APCGameState::SetPCState(EPCGameState NewState)
{
	const EPCGameState OldState = CurrentState;
	CurrentState = NewState;
	OnPCStateChanged.Broadcast(OldState, NewState);
}
