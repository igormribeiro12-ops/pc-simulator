﻿#include "UI/PCAssemblyHUDWidget.h"

#include "Assembly/PCAssemblyProgressTracker.h"
#include "Assembly/PCAssemblySystem.h"
#include "Blueprint/WidgetTree.h"
#include "Build/PCBuildReceiver.h"
#include "Components/ProgressBar.h"
#include "Components/TextBlock.h"
#include "Components/VerticalBox.h"
#include "Effects/PCPowerSystem.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"
#include "TimerManager.h"
#include "Utilities/PCMessages.h"

#define LOCTEXT_NAMESPACE "PCHUD"

void UPCAssemblyHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	if (UPCAssemblyProgressTracker* Tracker = World->GetSubsystem<UPCAssemblyProgressTracker>())
	{
		Tracker->OnProgressChanged.AddUniqueDynamic(this, &ThisClass::HandleProgress);
		HandleProgress(Tracker->GetDoneCount(), Tracker->GetTotalCount());
	}
	if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
	{
		Assembly->OnInstallFailed.AddUniqueDynamic(this, &ThisClass::HandleInstallFailed);
	}
	if (UPCPowerSystem* Power = World->GetSubsystem<UPCPowerSystem>())
	{
		Power->OnPowerFailed.AddUniqueDynamic(this, &ThisClass::HandlePowerFailed);
	}
	if (UPCBuildReceiver* Receiver = World->GetGameInstance() ? World->GetGameInstance()->GetSubsystem<UPCBuildReceiver>() : nullptr)
	{
		Receiver->OnBuildRejected.AddUniqueDynamic(this, &ThisClass::HandleBuildRejected);
	}
	if (APCGameState* GameState = World->GetGameState<APCGameState>())
	{
		GameState->OnPCStateChanged.AddUniqueDynamic(this, &ThisClass::HandleStateChanged);
		HandleStateChanged(GameState->GetPCState(), GameState->GetPCState());
	}
	ClearError();
}

void UPCAssemblyHUDWidget::NativeDestruct()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(ErrorTimer);
		if (UPCAssemblyProgressTracker* Tracker = World->GetSubsystem<UPCAssemblyProgressTracker>())
		{
			Tracker->OnProgressChanged.RemoveAll(this);
		}
		if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
		{
			Assembly->OnInstallFailed.RemoveAll(this);
		}
		if (UPCPowerSystem* Power = World->GetSubsystem<UPCPowerSystem>())
		{
			Power->OnPowerFailed.RemoveAll(this);
		}
		if (UPCBuildReceiver* Receiver = World->GetGameInstance() ? World->GetGameInstance()->GetSubsystem<UPCBuildReceiver>() : nullptr)
		{
			Receiver->OnBuildRejected.RemoveAll(this);
		}
		if (APCGameState* GameState = World->GetGameState<APCGameState>())
		{
			GameState->OnPCStateChanged.RemoveAll(this);
		}
	}
	Super::NativeDestruct();
}

void UPCAssemblyHUDWidget::HandleProgress(int32 Done, int32 Total)
{
	const float Progress = Total > 0 ? static_cast<float>(Done) / Total : 0.f;
	ProgressBar->SetPercent(Progress);
	ProgressText->SetText(FText::Format(LOCTEXT("Progress", "{0}% ({1}/{2})"),
		FMath::RoundToInt(Progress * 100.f), Done, Total));
	RebuildRequirements();
}

void UPCAssemblyHUDWidget::RebuildRequirements()
{
	RequirementList->ClearChildren();

	const UPCAssemblyProgressTracker* Tracker = GetWorld() ? GetWorld()->GetSubsystem<UPCAssemblyProgressTracker>() : nullptr;
	if (!Tracker)
	{
		return;
	}

	TArray<FPCRequirementStatus> Rows;
	Tracker->GetRequirementStatus(Rows);
	for (const FPCRequirementStatus& Row : Rows)
	{
		UTextBlock* Line = WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
		const FText Mark = FText::FromString(Row.bDone ? TEXT("✓") : TEXT("✗"));
		Line->SetText(FText::Format(LOCTEXT("Row", "{0}  {1}"), Mark, Row.Label));
		Line->SetColorAndOpacity(FSlateColor(Row.bDone ? FLinearColor(0.3f, 0.9f, 0.4f) : FLinearColor(0.85f, 0.85f, 0.85f)));
		RequirementList->AddChildToVerticalBox(Line);
	}
}

void UPCAssemblyHUDWidget::HandleStateChanged(EPCGameState /*OldState*/, EPCGameState NewState)
{
	StateText->SetText(StaticEnum<EPCGameState>()->GetDisplayNameTextByValue(static_cast<int64>(NewState)));
	RebuildRequirements();
}

void UPCAssemblyHUDWidget::HandleInstallFailed(AComputerComponent* /*Item*/, FGameplayTag /*Code*/, FText Reason)
{
	ShowError(Reason);
}

void UPCAssemblyHUDWidget::HandleBuildRejected(FGameplayTag Code, const FString& /*Detail*/)
{
	ShowError(PCMessages::Get(Code));
}

void UPCAssemblyHUDWidget::HandlePowerFailed(FGameplayTag /*Code*/, FText Reason)
{
	ShowError(Reason);
}

void UPCAssemblyHUDWidget::ShowError(const FText& Message)
{
	ErrorText->SetText(Message);
	ErrorText->SetVisibility(ESlateVisibility::HitTestInvisible);
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimer(ErrorTimer, this, &ThisClass::ClearError, ErrorDisplaySeconds, false);
	}
}

void UPCAssemblyHUDWidget::ClearError()
{
	ErrorText->SetText(FText::GetEmpty());
	ErrorText->SetVisibility(ESlateVisibility::Collapsed);
}

#undef LOCTEXT_NAMESPACE
