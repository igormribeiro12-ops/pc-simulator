﻿#include "UI/PCHUD.h"

#include "Blueprint/UserWidget.h"
#include "UI/PCAssemblyHUDWidget.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCMessages.h"

void APCHUD::BeginPlay()
{
	Super::BeginPlay();
	PCMessages::PreloadAsync();

	if (!WidgetClass)
	{
		UE_LOG(LogPCPresentation, Warning, TEXT("APCHUD sem WidgetClass; atribua WBP_AssemblyHUD em BP_PCHUD."));
		return;
	}
	Widget = CreateWidget<UPCAssemblyHUDWidget>(GetOwningPlayerController(), WidgetClass);
	if (Widget)
	{
		Widget->AddToViewport();
	}
}
