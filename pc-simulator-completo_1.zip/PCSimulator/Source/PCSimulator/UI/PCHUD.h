﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "PCHUD.generated.h"

class UPCAssemblyHUDWidget;

/** Cria o widget de montagem. A classe do widget (WBP) é atribuída no BP_PCHUD. */
UCLASS()
class PCSIMULATOR_API APCHUD : public AHUD
{
	GENERATED_BODY()

protected:
	virtual void BeginPlay() override;

	/** [ASSET PENDENTE] WBP_AssemblyHUD (filho de UPCAssemblyHUDWidget). */
	UPROPERTY(EditDefaultsOnly, Category = "PC|UI")
	TSubclassOf<UPCAssemblyHUDWidget> WidgetClass;

private:
	UPROPERTY(Transient)
	TObjectPtr<UPCAssemblyHUDWidget> Widget;
};
