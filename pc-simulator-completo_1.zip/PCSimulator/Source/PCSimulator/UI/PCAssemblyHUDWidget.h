﻿#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/PCGameState.h"
#include "GameplayTagContainer.h"
#include "PCAssemblyHUDWidget.generated.h"

class AComputerComponent;
class UPCAssemblySlotComponent;
class UProgressBar;
class UTextBlock;
class UVerticalBox;

/**
 * HUD C++-first (§17): lista de requisitos com ✓/✗, progresso percentual, estado e erro atual.
 * O WBP só define o layout; os nomes abaixo precisam existir no WBP (BindWidget).
 */
UCLASS(Abstract)
class PCSIMULATOR_API UPCAssemblyHUDWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UVerticalBox> RequirementList;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UProgressBar> ProgressBar;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> ProgressText;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> StateText;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> ErrorText;

	UPROPERTY(EditDefaultsOnly, Category = "PC|UI", meta = (ClampMin = "0.5"))
	float ErrorDisplaySeconds = 4.f;

private:
	UFUNCTION() void HandleProgress(int32 Done, int32 Total);
	UFUNCTION() void HandleInstallFailed(AComputerComponent* Item, FGameplayTag Code, FText Reason);
	UFUNCTION() void HandleBuildRejected(FGameplayTag Code, const FString& Detail);
	UFUNCTION() void HandlePowerFailed(FGameplayTag Code, FText Reason);
	UFUNCTION() void HandleStateChanged(EPCGameState OldState, EPCGameState NewState);

	void RebuildRequirements();
	void ShowError(const FText& Message);
	void ClearError();

	FTimerHandle ErrorTimer;
};
