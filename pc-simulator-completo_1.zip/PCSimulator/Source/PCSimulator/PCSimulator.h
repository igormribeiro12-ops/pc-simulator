﻿#pragma once

#include "CoreMinimal.h"

// Categoria geral do módulo (bootstrap). As categorias por domínio
// (LogPCNetwork, LogPCBuild, ...) entram na Fase 2 em Utilities/PCLog.h.
DECLARE_LOG_CATEGORY_EXTERN(LogPCSimulator, Log, All);
