﻿#include "Animation/PCInstallAnimationComponent.h"

#include "GameFramework/Actor.h"

UPCInstallAnimationComponent::UPCInstallAnimationComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}

void UPCInstallAnimationComponent::Play(const FTransform& InTarget, float Duration, FSimpleDelegate OnFinished)
{
	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return;
	}

	StartTransform = Owner->GetActorTransform();
	TargetTransform = InTarget;
	TotalDuration = Duration;
	Elapsed = 0.f;
	Finished = MoveTemp(OnFinished);
	bPlaying = true;

	if (Duration <= 0.f)
	{
		CompleteNow();
		return;
	}
	SetComponentTickEnabled(true);
}

void UPCInstallAnimationComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!bPlaying)
	{
		SetComponentTickEnabled(false);
		return;
	}

	Elapsed += DeltaTime;
	const float Alpha = FMath::Clamp(Elapsed / TotalDuration, 0.f, 1.f);
	if (Alpha >= 1.f)
	{
		CompleteNow();
		return;
	}

	FTransform Blended;
	Blended.Blend(StartTransform, TargetTransform, FMath::SmoothStep(0.f, 1.f, Alpha));
	GetOwner()->SetActorTransform(Blended);
}

void UPCInstallAnimationComponent::CompleteNow()
{
	if (!bPlaying)
	{
		return;
	}
	bPlaying = false;
	SetComponentTickEnabled(false);

	if (AActor* Owner = GetOwner())
	{
		Owner->SetActorTransform(TargetTransform);
	}

	// Copia antes de executar: o callback pode reiniciar a animação.
	const FSimpleDelegate Callback = MoveTemp(Finished);
	Finished.Unbind();
	Callback.ExecuteIfBound();
}
