﻿#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "PCAnimNotify_InstallationCompleted.generated.h"

/**
 * Colocado no frame de "encaixe" de uma montage (modelos esqueléticos).
 * Conclui o UPCInstallAnimationComponent do dono, que dispara o delegate de instalação.
 */
UCLASS(meta = (DisplayName = "PC Installation Completed"))
class PCSIMULATOR_API UPCAnimNotify_InstallationCompleted : public UAnimNotify
{
	GENERATED_BODY()

public:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
		const FAnimNotifyEventReference& EventReference) override;

	virtual FString GetNotifyName_Implementation() const override;
};
