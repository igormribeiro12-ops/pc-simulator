﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "PCInstallAnimationComponent.generated.h"

/**
 * Animação de encaixe do ator (interpolação do transform até o slot).
 * [DECISÃO] Interpolação C++ em vez de AnimInstance: os componentes são Static Meshes; AnimInstance
 * exige Skeletal Mesh. Para modelos esqueléticos futuros, UPCAnimNotify_InstallationCompleted
 * finaliza este componente a partir de uma montage.
 * Tick permitido (pasta Animation) e ligado só durante a animação.
 */
UCLASS(ClassGroup = (PC), meta = (BlueprintSpawnableComponent))
class PCSIMULATOR_API UPCInstallAnimationComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UPCInstallAnimationComponent();

	/** Duration <= 0 conclui imediatamente (síncrono). */
	void Play(const FTransform& TargetTransform, float Duration, FSimpleDelegate OnFinished);

	/** Conclui agora (também chamado pelo AnimNotify). */
	void CompleteNow();

	bool IsPlaying() const { return bPlaying; }

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	FTransform StartTransform;
	FTransform TargetTransform;
	float TotalDuration = 0.f;
	float Elapsed = 0.f;
	bool bPlaying = false;
	FSimpleDelegate Finished;
};
