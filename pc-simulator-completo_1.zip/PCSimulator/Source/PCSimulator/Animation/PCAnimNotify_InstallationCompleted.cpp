﻿#include "Animation/PCAnimNotify_InstallationCompleted.h"

#include "Animation/PCInstallAnimationComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Actor.h"

void UPCAnimNotify_InstallationCompleted::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	const FAnimNotifyEventReference& EventReference)
{
	Super::Notify(MeshComp, Animation, EventReference);

	AActor* Owner = MeshComp ? MeshComp->GetOwner() : nullptr;
	if (UPCInstallAnimationComponent* InstallAnimation = Owner ? Owner->FindComponentByClass<UPCInstallAnimationComponent>() : nullptr)
	{
		InstallAnimation->CompleteNow();
	}
}

FString UPCAnimNotify_InstallationCompleted::GetNotifyName_Implementation() const
{
	return TEXT("PC Installation Completed");
}
