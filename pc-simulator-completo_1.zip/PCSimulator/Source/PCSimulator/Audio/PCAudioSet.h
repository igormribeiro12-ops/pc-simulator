﻿#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "PCAudioSet.generated.h"

class USoundBase;

/** Os 7 sons mínimos (§15). [ASSET PENDENTE] todos os SoundBase; FanLoop deve ser um som em loop. */
UCLASS(BlueprintType)
class PCSIMULATOR_API UPCAudioSet : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> Click;
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> Snap;
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> Screw;
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> Connect;
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> Error;
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> PowerOn;
	UPROPERTY(EditAnywhere, Category = "Sounds") TSoftObjectPtr<USoundBase> FanLoop;

	/** Tipos que tocam "parafuso" além do encaixe ao serem instalados. */
	UPROPERTY(EditAnywhere, Category = "Rules", meta = (Categories = "Component"))
	FGameplayTagContainer ScrewedTypes;

	void GetAllSounds(TArray<FSoftObjectPath>& OutPaths) const;
};
