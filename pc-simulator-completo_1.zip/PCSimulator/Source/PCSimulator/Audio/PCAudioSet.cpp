﻿#include "Audio/PCAudioSet.h"

#include "Sound/SoundBase.h"

void UPCAudioSet::GetAllSounds(TArray<FSoftObjectPath>& OutPaths) const
{
	OutPaths.Reset();
	for (const TSoftObjectPtr<USoundBase>* Sound : { &Click, &Snap, &Screw, &Connect, &Error, &PowerOn, &FanLoop })
	{
		if (!Sound->IsNull())
		{
			OutPaths.AddUnique(Sound->ToSoftObjectPath());
		}
	}
}
