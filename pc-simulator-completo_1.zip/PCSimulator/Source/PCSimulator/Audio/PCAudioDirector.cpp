﻿#include "Audio/PCAudioDirector.h"

#include "Assembly/PCAssemblySystem.h"
#include "Audio/PCAudioSet.h"
#include "Build/PCBuildReceiver.h"
#include "Components/AudioComponent.h"
#include "Components/ComputerComponent.h"
#include "Effects/PCPowerSystem.h"
#include "Engine/AssetManager.h"
#include "Engine/GameInstance.h"
#include "Engine/StreamableManager.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCSimulatorSettings.h"

void UPCAudioDirector::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	if (UPCAssemblySystem* Assembly = Collection.InitializeDependency<UPCAssemblySystem>())
	{
		Assembly->OnPickedUp.AddDynamic(this, &ThisClass::HandleItem);
		Assembly->OnDropped.AddDynamic(this, &ThisClass::HandleItem);
		Assembly->OnHeldRotated.AddDynamic(this, &ThisClass::HandleItem);
		Assembly->OnInstalled.AddDynamic(this, &ThisClass::HandleInstalled);
		Assembly->OnInstallFailed.AddDynamic(this, &ThisClass::HandleInstallFailed);
		Assembly->OnCableConnected.AddDynamic(this, &ThisClass::HandleCable);
	}
	if (UPCPowerSystem* Power = Collection.InitializeDependency<UPCPowerSystem>())
	{
		Power->OnPowerSequenceStarted.AddDynamic(this, &ThisClass::HandlePowerStarted);
		Power->OnFansStarted.AddDynamic(this, &ThisClass::HandleFansStarted);
		Power->OnPoweredOff.AddDynamic(this, &ThisClass::HandlePoweredOff);
		Power->OnPowerFailed.AddDynamic(this, &ThisClass::HandlePowerFailed);
	}
}

void UPCAudioDirector::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		if (UPCBuildReceiver* Receiver = World->GetGameInstance() ? World->GetGameInstance()->GetSubsystem<UPCBuildReceiver>() : nullptr)
		{
			Receiver->OnBuildRejected.RemoveAll(this);
		}
	}
	if (SetHandle.IsValid()) { SetHandle->ReleaseHandle(); SetHandle.Reset(); }
	if (SoundsHandle.IsValid()) { SoundsHandle->ReleaseHandle(); SoundsHandle.Reset(); }
	Super::Deinitialize();
}

void UPCAudioDirector::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);

	if (UPCBuildReceiver* Receiver = InWorld.GetGameInstance() ? InWorld.GetGameInstance()->GetSubsystem<UPCBuildReceiver>() : nullptr)
	{
		Receiver->OnBuildRejected.AddUniqueDynamic(this, &ThisClass::HandleBuildRejected);
	}

	const TSoftObjectPtr<UPCAudioSet>& Configured = UPCSimulatorSettings::Get().AudioSet;
	if (Configured.IsNull() || !UAssetManager::IsInitialized())
	{
		UE_LOG(LogPCPresentation, Warning, TEXT("AudioSet não configurado; jogo seguirá sem som."));
		return;
	}
	SetHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Configured.ToSoftObjectPath(),
		FStreamableDelegate::CreateUObject(this, &ThisClass::HandleSetLoaded));
}

void UPCAudioDirector::HandleSetLoaded()
{
	AudioSet = UPCSimulatorSettings::Get().AudioSet.Get();
	if (!AudioSet)
	{
		return;
	}
	TArray<FSoftObjectPath> Paths;
	AudioSet->GetAllSounds(Paths);
	if (!Paths.IsEmpty())
	{
		SoundsHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Paths,
			FStreamableDelegate::CreateUObject(this, &ThisClass::HandleSoundsLoaded));
	}
}

void UPCAudioDirector::HandleSoundsLoaded()
{
	UE_LOG(LogPCPresentation, Log, TEXT("Sons carregados."));
}

void UPCAudioDirector::Play(const TSoftObjectPtr<USoundBase>& Sound, const AActor* At) const
{
	USoundBase* Loaded = Sound.Get(); // nunca carrega aqui; se não carregou ainda, silêncio
	if (!Loaded || !GetWorld())
	{
		return;
	}
	if (At)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), Loaded, At->GetActorLocation());
	}
	else
	{
		UGameplayStatics::PlaySound2D(GetWorld(), Loaded);
	}
}

void UPCAudioDirector::HandleItem(AComputerComponent* Item)
{
	if (AudioSet) { Play(AudioSet->Click, Item); }
}

void UPCAudioDirector::HandleInstalled(AComputerComponent* Item, UPCAssemblySlotComponent* /*Slot*/)
{
	if (!AudioSet)
	{
		return;
	}
	Play(AudioSet->Snap, Item);
	if (Item && AudioSet->ScrewedTypes.HasTagExact(Item->GetComponentType()))
	{
		Play(AudioSet->Screw, Item);
	}
}

void UPCAudioDirector::HandleInstallFailed(AComputerComponent* /*Item*/, FGameplayTag /*Code*/, FText /*Reason*/)
{
	if (AudioSet) { Play(AudioSet->Error); }
}

void UPCAudioDirector::HandleCable(UPCAssemblySlotComponent* /*Slot*/)
{
	if (AudioSet) { Play(AudioSet->Connect); }
}

void UPCAudioDirector::HandlePowerStarted()
{
	if (AudioSet) { Play(AudioSet->PowerOn); }
}

void UPCAudioDirector::HandleFansStarted()
{
	USoundBase* Loop = AudioSet ? AudioSet->FanLoop.Get() : nullptr;
	if (Loop && !FanLoopComponent)
	{
		FanLoopComponent = UGameplayStatics::SpawnSound2D(GetWorld(), Loop);
	}
}

void UPCAudioDirector::HandlePoweredOff()
{
	if (FanLoopComponent)
	{
		FanLoopComponent->Stop();
		FanLoopComponent = nullptr;
	}
}

void UPCAudioDirector::HandlePowerFailed(FGameplayTag /*Code*/, FText /*Reason*/)
{
	if (AudioSet) { Play(AudioSet->Error); }
}

void UPCAudioDirector::HandleBuildRejected(FGameplayTag /*Code*/, const FString& /*Detail*/)
{
	if (AudioSet) { Play(AudioSet->Error); }
}
