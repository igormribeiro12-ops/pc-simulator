﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Subsystems/WorldSubsystem.h"
#include "PCAudioDirector.generated.h"

class AComputerComponent;
class UAudioComponent;
class UPCAssemblySlotComponent;
class UPCAudioSet;
class USoundBase;
struct FStreamableHandle;

/**
 * Observador puro: toca sons em resposta a eventos de montagem/energia/build. Nunca altera estado.
 * O AudioSet e os sons são carregados de forma assíncrona no início da partida.
 */
UCLASS()
class PCSIMULATOR_API UPCAudioDirector : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void OnWorldBeginPlay(UWorld& InWorld) override;

private:
	UFUNCTION() void HandleItem(AComputerComponent* Item);
	UFUNCTION() void HandleInstalled(AComputerComponent* Item, UPCAssemblySlotComponent* Slot);
	UFUNCTION() void HandleInstallFailed(AComputerComponent* Item, FGameplayTag Code, FText Reason);
	UFUNCTION() void HandleCable(UPCAssemblySlotComponent* Slot);
	UFUNCTION() void HandlePowerStarted();
	UFUNCTION() void HandleFansStarted();
	UFUNCTION() void HandlePoweredOff();
	UFUNCTION() void HandlePowerFailed(FGameplayTag Code, FText Reason);
	UFUNCTION() void HandleBuildRejected(FGameplayTag Code, const FString& Detail);

	void HandleSetLoaded();
	void HandleSoundsLoaded();
	void Play(const TSoftObjectPtr<USoundBase>& Sound, const AActor* At = nullptr) const;

	UPROPERTY(Transient) TObjectPtr<UPCAudioSet> AudioSet;
	UPROPERTY(Transient) TObjectPtr<UAudioComponent> FanLoopComponent;

	TSharedPtr<FStreamableHandle> SetHandle;
	TSharedPtr<FStreamableHandle> SoundsHandle;
};
