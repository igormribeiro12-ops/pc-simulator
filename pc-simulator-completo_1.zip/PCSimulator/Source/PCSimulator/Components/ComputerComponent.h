﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameplayTagContainer.h"
#include "ComputerComponent.generated.h"

class UPCAssemblySlotComponent;
class UPCComponentDataAsset;
class UPCInstallAnimationComponent;
class UPCRGBController;
class UStaticMeshComponent;

/**
 * Ator base de todo hardware no mundo. Nasce apenas via UPCBuildSpawner:
 * SpawnActorDeferred → InitializeFromData(DataAsset já carregado) → FinishSpawning.
 * Slots (UPCAssemblySlotComponent) são posicionados no Blueprint filho.
 */
UCLASS(Abstract)
class PCSIMULATOR_API AComputerComponent : public AActor
{
	GENERATED_BODY()

public:
	AComputerComponent();

	/** Valida a classe do DataAsset e aplica mesh/configuração. false = tipo incompatível. */
	bool InitializeFromData(UPCComponentDataAsset* InData);

	UPCComponentDataAsset* GetData() const { return Data; }
	FGameplayTag GetComponentType() const;
	FText GetDisplayName() const;

	UStaticMeshComponent* GetMesh() const { return Mesh; }
	UPCInstallAnimationComponent* GetInstallAnimation() const { return InstallAnimation; }

	void SetHighlighted(bool bHighlighted);

	bool IsInstalled() const { return InstalledSlot.IsValid(); }
	UPCAssemblySlotComponent* GetInstalledSlot() const { return InstalledSlot.Get(); }
	void SetInstalledSlot(UPCAssemblySlotComponent* Slot) { InstalledSlot = Slot; }

	/** Slots próprios deste ator (não inclui os de atores anexados). */
	void GetSlots(TArray<UPCAssemblySlotComponent*>& OutSlots) const;

	/** Liga/desliga colisão deste ator e de tudo anexado a ele (item segurado). */
	void SetCollisionEnabledRecursive(bool bEnabled);

protected:
	/** Os componentes do Blueprint (slots) só existem após o construction script: OnDataAssigned roda aqui. */
	virtual void PostInitializeComponents() override;

	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const
		PURE_VIRTUAL(AComputerComponent::GetExpectedDataClass, return nullptr;);

	/** Gancho para subclasses configurarem slots etc. a partir do DataAsset (após FinishSpawning). */
	virtual void OnDataAssigned() {}

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC")
	TObjectPtr<UStaticMeshComponent> Mesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC")
	TObjectPtr<UPCInstallAnimationComponent> InstallAnimation;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC")
	TObjectPtr<UPCRGBController> RGBController;

	UPROPERTY(VisibleInstanceOnly, Transient, BlueprintReadOnly, Category = "PC")
	TObjectPtr<UPCComponentDataAsset> Data;

private:
	TWeakObjectPtr<UPCAssemblySlotComponent> InstalledSlot;
};
