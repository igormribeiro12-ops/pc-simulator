﻿#include "Components/ComputerComponent.h"

#include "Animation/PCInstallAnimationComponent.h"
#include "Assembly/PCAssemblySlotComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Data/PCComponentDataAsset.h"
#include "Effects/PCRGBController.h"
#include "Engine/StaticMesh.h"
#include "Interaction/PCCollision.h"
#include "Utilities/PCLog.h"

AComputerComponent::AComputerComponent()
{
	PrimaryActorTick.bCanEverTick = false;

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	SetRootComponent(Mesh);
	Mesh->SetMobility(EComponentMobility::Movable);
	Mesh->SetSimulatePhysics(false);
	Mesh->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	Mesh->SetCollisionResponseToAllChannels(ECR_Ignore);
	Mesh->SetCollisionResponseToChannel(PCInteractionChannel, ECR_Block);
	Mesh->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);
	Mesh->SetCustomDepthStencilValue(1);

	InstallAnimation = CreateDefaultSubobject<UPCInstallAnimationComponent>(TEXT("InstallAnimation"));
	RGBController = CreateDefaultSubobject<UPCRGBController>(TEXT("RGBController"));
}

bool AComputerComponent::InitializeFromData(UPCComponentDataAsset* InData)
{
	const TSubclassOf<UPCComponentDataAsset> Expected = GetExpectedDataClass();
	if (!InData || !Expected || !InData->IsA(Expected) || !InData->Type.MatchesTagExact(InData->GetExpectedType()))
	{
		UE_LOG(LogPCAssembly, Error, TEXT("%s: DataAsset %s incompatível com a classe do ator."),
			*GetName(), InData ? *InData->GetName() : TEXT("<null>"));
		return false;
	}

	Data = InData;
	if (UStaticMesh* LoadedMesh = Data->Mesh.Get())
	{
		Mesh->SetStaticMesh(LoadedMesh);
	}
	// Sem mesh no DataAsset: mantém o placeholder definido no Blueprint (fase de placeholders).
	// OnDataAssigned() roda em PostInitializeComponents, quando os slots do Blueprint já existem.
	return true;
}

void AComputerComponent::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	if (Data)
	{
		OnDataAssigned();
	}
}

FGameplayTag AComputerComponent::GetComponentType() const
{
	return Data ? Data->Type : FGameplayTag();
}

FText AComputerComponent::GetDisplayName() const
{
	return Data ? Data->DisplayName : FText::FromString(GetName());
}

void AComputerComponent::SetHighlighted(bool bHighlighted)
{
	// Outline via pós-processo que lê Custom Depth/Stencil. [ASSET PENDENTE] M_PP_Outline no PostProcessVolume.
	Mesh->SetRenderCustomDepth(bHighlighted);
}

void AComputerComponent::GetSlots(TArray<UPCAssemblySlotComponent*>& OutSlots) const
{
	GetComponents<UPCAssemblySlotComponent>(OutSlots);
}

void AComputerComponent::SetCollisionEnabledRecursive(bool bEnabled)
{
	SetActorEnableCollision(bEnabled);

	TArray<AActor*> Attached;
	GetAttachedActors(Attached, /*bResetArray*/ true, /*bRecursivelyIncludeAttachedActors*/ true);
	for (AActor* Child : Attached)
	{
		if (Child)
		{
			Child->SetActorEnableCollision(bEnabled);
		}
	}
}
