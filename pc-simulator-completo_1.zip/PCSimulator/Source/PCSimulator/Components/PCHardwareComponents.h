﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ComputerComponent.h"
#include "PCHardwareComponents.generated.h"

class UPCCPUDataAsset;
class UPCGPUDataAsset;
class UPCMotherboardDataAsset;
class UPCRAMDataAsset;
class UPCStorageDataAsset;
class UPCPSUDataAsset;
class UPCCaseDataAsset;
class UPCFanDataAsset;

/*
 * Os 8 tipos concretos. Cada um existe para:
 *  (1) travar o tipo de DataAsset aceito no spawn (GetExpectedDataClass);
 *  (2) expor o DataAsset tipado sem Cast espalhado;
 *  (3) comportamento próprio quando houver (placa-mãe configura slots; gabinete tem painel).
 */

UCLASS()
class PCSIMULATOR_API ACPUComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCCPUDataAsset* GetCPUData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
};

UCLASS()
class PCSIMULATOR_API AGPUComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCGPUDataAsset* GetGPUData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
};

/** Ajusta o socket dos slots de CPU/RAM e desativa slots de RAM excedentes, a partir do DataAsset. */
UCLASS()
class PCSIMULATOR_API AMotherboardComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCMotherboardDataAsset* GetMotherboardData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
	virtual void OnDataAssigned() override;
};

/** Um ator por módulo (o spawner cria ModuleCount atores por kit). */
UCLASS()
class PCSIMULATOR_API ARAMComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCRAMDataAsset* GetRAMData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
};

UCLASS()
class PCSIMULATOR_API ASSDComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCStorageDataAsset* GetStorageData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
};

UCLASS()
class PCSIMULATOR_API APSUComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCPSUDataAsset* GetPSUData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
};

/** Raiz da montagem. O painel lateral fechado bloqueia o trace de interação para o interior. */
UCLASS()
class PCSIMULATOR_API ACaseComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	ACaseComponent();

	const UPCCaseDataAsset* GetCaseData() const;

	bool IsPanelClosed() const { return bPanelClosed; }

	/** Só o UPCAssemblySystem deve chamar (ele valida os pré-requisitos). */
	void SetPanelClosed(bool bClosed);

protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;

	/** [ASSET PENDENTE] Mesh do painel lateral, atribuída no BP. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "PC")
	TObjectPtr<UStaticMeshComponent> SidePanel;

private:
	bool bPanelClosed = false;
};

UCLASS()
class PCSIMULATOR_API AFanComponent : public AComputerComponent
{
	GENERATED_BODY()
public:
	const UPCFanDataAsset* GetFanData() const;
protected:
	virtual TSubclassOf<UPCComponentDataAsset> GetExpectedDataClass() const override;
};
