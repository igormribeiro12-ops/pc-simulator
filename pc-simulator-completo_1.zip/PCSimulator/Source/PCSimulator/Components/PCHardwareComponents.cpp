﻿#include "Components/PCHardwareComponents.h"

#include "Assembly/PCAssemblySlotComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Data/PCComponentDataAsset.h"
#include "Interaction/PCCollision.h"
#include "Utilities/PCGameplayTags.h"

// ---------------- CPU ----------------
const UPCCPUDataAsset* ACPUComponent::GetCPUData() const { return Cast<UPCCPUDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> ACPUComponent::GetExpectedDataClass() const { return UPCCPUDataAsset::StaticClass(); }

// ---------------- GPU ----------------
const UPCGPUDataAsset* AGPUComponent::GetGPUData() const { return Cast<UPCGPUDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> AGPUComponent::GetExpectedDataClass() const { return UPCGPUDataAsset::StaticClass(); }

// ---------------- Motherboard ----------------
const UPCMotherboardDataAsset* AMotherboardComponent::GetMotherboardData() const { return Cast<UPCMotherboardDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> AMotherboardComponent::GetExpectedDataClass() const { return UPCMotherboardDataAsset::StaticClass(); }

void AMotherboardComponent::OnDataAssigned()
{
	const UPCMotherboardDataAsset* Board = GetMotherboardData();
	if (!Board)
	{
		return;
	}

	TArray<UPCAssemblySlotComponent*> Slots;
	GetSlots(Slots);
	// Ordem estável (Slot.RAM.1, Slot.RAM.2, ...) para desativar sempre os últimos.
	Slots.Sort([](const UPCAssemblySlotComponent& A, const UPCAssemblySlotComponent& B)
	{
		return A.SlotTag.ToString() < B.SlotTag.ToString();
	});

	int32 RamIndex = 0;
	for (UPCAssemblySlotComponent* Slot : Slots)
	{
		if (Slot->AllowedTypes.HasTagExact(PCTags::Component_CPU))
		{
			Slot->RequiredSocket = Board->CpuSocket;
		}
		else if (Slot->AllowedTypes.HasTagExact(PCTags::Component_RAM))
		{
			Slot->RequiredSocket = Board->RamSocket;
			Slot->bEnabled = RamIndex < Board->RamSlotCount;
			++RamIndex;
		}
	}
}

// ---------------- RAM ----------------
const UPCRAMDataAsset* ARAMComponent::GetRAMData() const { return Cast<UPCRAMDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> ARAMComponent::GetExpectedDataClass() const { return UPCRAMDataAsset::StaticClass(); }

// ---------------- Storage ----------------
const UPCStorageDataAsset* ASSDComponent::GetStorageData() const { return Cast<UPCStorageDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> ASSDComponent::GetExpectedDataClass() const { return UPCStorageDataAsset::StaticClass(); }

// ---------------- PSU ----------------
const UPCPSUDataAsset* APSUComponent::GetPSUData() const { return Cast<UPCPSUDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> APSUComponent::GetExpectedDataClass() const { return UPCPSUDataAsset::StaticClass(); }

// ---------------- Case ----------------
ACaseComponent::ACaseComponent()
{
	SidePanel = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("SidePanel"));
	SidePanel->SetupAttachment(Mesh);
	SidePanel->SetMobility(EComponentMobility::Movable);
	SidePanel->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	SidePanel->SetCollisionResponseToAllChannels(ECR_Ignore);
	SidePanel->SetVisibility(false);
}

const UPCCaseDataAsset* ACaseComponent::GetCaseData() const { return Cast<UPCCaseDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> ACaseComponent::GetExpectedDataClass() const { return UPCCaseDataAsset::StaticClass(); }

void ACaseComponent::SetPanelClosed(bool bClosed)
{
	bPanelClosed = bClosed;
	SidePanel->SetVisibility(bClosed);
	// Fechado: o painel bloqueia o trace (interior inacessível; mirar o painel = interagir com o gabinete).
	SidePanel->SetCollisionResponseToChannel(PCInteractionChannel, bClosed ? ECR_Block : ECR_Ignore);
}

// ---------------- Fan ----------------
const UPCFanDataAsset* AFanComponent::GetFanData() const { return Cast<UPCFanDataAsset>(Data); }
TSubclassOf<UPCComponentDataAsset> AFanComponent::GetExpectedDataClass() const { return UPCFanDataAsset::StaticClass(); }
