﻿#pragma once

#include "CoreMinimal.h"

// Categorias obrigatórias (§5 do prompt mestre).
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCNetwork, Log, All);
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCBuild, Log, All);
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCAssembly, Log, All);
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCCompatibility, Log, All);
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCCatalog, Log, All);
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCPower, Log, All);

// Adicional: camada de apresentação (UI, áudio, RGB). Separada para filtrar ruído.
PCSIMULATOR_API DECLARE_LOG_CATEGORY_EXTERN(LogPCPresentation, Log, All);
