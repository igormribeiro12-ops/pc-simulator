﻿#include "Utilities/PCGameplayTags.h"

namespace PCTags
{
	UE_DEFINE_GAMEPLAY_TAG(Component, "Component");
	UE_DEFINE_GAMEPLAY_TAG(Component_CPU, "Component.CPU");
	UE_DEFINE_GAMEPLAY_TAG(Component_GPU, "Component.GPU");
	UE_DEFINE_GAMEPLAY_TAG(Component_Motherboard, "Component.Motherboard");
	UE_DEFINE_GAMEPLAY_TAG(Component_RAM, "Component.RAM");
	UE_DEFINE_GAMEPLAY_TAG(Component_Storage, "Component.Storage");
	UE_DEFINE_GAMEPLAY_TAG(Component_PSU, "Component.PSU");
	UE_DEFINE_GAMEPLAY_TAG(Component_Case, "Component.Case");
	UE_DEFINE_GAMEPLAY_TAG(Component_Fan, "Component.Fan");
	UE_DEFINE_GAMEPLAY_TAG(Component_Cable, "Component.Cable");

	UE_DEFINE_GAMEPLAY_TAG(Socket_PCIe_x16, "Socket.PCIe.x16");

	UE_DEFINE_GAMEPLAY_TAG(BuildError, "BuildError");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_SchemaVersionUnsupported, "BuildError.SchemaVersionUnsupported");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_MalformedJson, "BuildError.MalformedJson");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_MissingField, "BuildError.MissingField");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_InvalidFieldValue, "BuildError.InvalidFieldValue");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_UnknownComponentTag, "BuildError.UnknownComponentTag");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_DuplicateComponentTag, "BuildError.DuplicateComponentTag");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_MissingRequiredComponent, "BuildError.MissingRequiredComponent");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_UnknownComponentId, "BuildError.UnknownComponentId");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_ComponentTypeMismatch, "BuildError.ComponentTypeMismatch");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_AssetNotFound, "BuildError.AssetNotFound");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_IncompatibleBuild, "BuildError.IncompatibleBuild");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_DuplicateBuild, "BuildError.DuplicateBuild");
	UE_DEFINE_GAMEPLAY_TAG(BuildError_InvalidState, "BuildError.InvalidState");

	UE_DEFINE_GAMEPLAY_TAG(AssemblyError, "AssemblyError");
	UE_DEFINE_GAMEPLAY_TAG(AssemblyError_SlotOccupied, "AssemblyError.SlotOccupied");
	UE_DEFINE_GAMEPLAY_TAG(AssemblyError_SlotMismatch, "AssemblyError.SlotMismatch");
	UE_DEFINE_GAMEPLAY_TAG(AssemblyError_Incompatible, "AssemblyError.Incompatible");
	UE_DEFINE_GAMEPLAY_TAG(AssemblyError_WrongOrientation, "AssemblyError.WrongOrientation");
	UE_DEFINE_GAMEPLAY_TAG(AssemblyError_OutOfRange, "AssemblyError.OutOfRange");
	UE_DEFINE_GAMEPLAY_TAG(AssemblyError_MissingPrerequisite, "AssemblyError.MissingPrerequisite");

	UE_DEFINE_GAMEPLAY_TAG(NetworkError, "NetworkError");
	UE_DEFINE_GAMEPLAY_TAG(NetworkError_Timeout, "NetworkError.Timeout");
	UE_DEFINE_GAMEPLAY_TAG(NetworkError_Disconnected, "NetworkError.Disconnected");
	UE_DEFINE_GAMEPLAY_TAG(NetworkError_ProtocolViolation, "NetworkError.ProtocolViolation");

	const TArray<FGameplayTag>& GetRequiredBuildTypes()
	{
		static const TArray<FGameplayTag> Required = []()
		{
			TArray<FGameplayTag> Tags;
			Tags.Add(Component_CPU);
			Tags.Add(Component_GPU);
			Tags.Add(Component_Motherboard);
			Tags.Add(Component_RAM);
			Tags.Add(Component_Storage);
			Tags.Add(Component_PSU);
			Tags.Add(Component_Case);
			return Tags;
		}();
		return Required;
	}

	TArray<FGameplayTag> GetAllNativeTags()
	{
		TArray<FGameplayTag> Tags;
		Tags.Add(Component); Tags.Add(Component_CPU); Tags.Add(Component_GPU); Tags.Add(Component_Motherboard);
		Tags.Add(Component_RAM); Tags.Add(Component_Storage); Tags.Add(Component_PSU); Tags.Add(Component_Case);
		Tags.Add(Component_Fan); Tags.Add(Component_Cable);
		Tags.Add(Socket_PCIe_x16);
		Tags.Add(BuildError); Tags.Add(BuildError_SchemaVersionUnsupported); Tags.Add(BuildError_MalformedJson);
		Tags.Add(BuildError_MissingField); Tags.Add(BuildError_InvalidFieldValue); Tags.Add(BuildError_UnknownComponentTag);
		Tags.Add(BuildError_DuplicateComponentTag); Tags.Add(BuildError_MissingRequiredComponent);
		Tags.Add(BuildError_UnknownComponentId); Tags.Add(BuildError_ComponentTypeMismatch); Tags.Add(BuildError_AssetNotFound);
		Tags.Add(BuildError_IncompatibleBuild); Tags.Add(BuildError_DuplicateBuild); Tags.Add(BuildError_InvalidState);
		Tags.Add(AssemblyError); Tags.Add(AssemblyError_SlotOccupied); Tags.Add(AssemblyError_SlotMismatch);
		Tags.Add(AssemblyError_Incompatible); Tags.Add(AssemblyError_WrongOrientation); Tags.Add(AssemblyError_OutOfRange);
		Tags.Add(AssemblyError_MissingPrerequisite);
		Tags.Add(NetworkError); Tags.Add(NetworkError_Timeout); Tags.Add(NetworkError_Disconnected);
		Tags.Add(NetworkError_ProtocolViolation);
		return Tags;
	}

	FString ToWire(const FGameplayTag& Tag)
	{
		return Tag.IsValid() ? Tag.ToString() : FString(TEXT("BuildError.None"));
	}
}
