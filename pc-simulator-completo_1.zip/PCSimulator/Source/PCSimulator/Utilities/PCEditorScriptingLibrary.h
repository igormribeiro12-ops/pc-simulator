﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "PCEditorScriptingLibrary.generated.h"

/**
 * Ponte mínima para o importador de catálogo em Python (Tools/Editor/import_catalog.py):
 * o Python do editor não tem uma forma estável de criar FGameplayTag a partir de texto.
 */
UCLASS()
class PCSIMULATOR_API UPCEditorScriptingLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** Tag registrada com esse nome, ou vazia se não existir (loga aviso). */
	UFUNCTION(BlueprintCallable, Category = "PC|Scripting")
	static FGameplayTag MakeTag(const FString& TagName);

	UFUNCTION(BlueprintCallable, Category = "PC|Scripting")
	static FGameplayTagContainer MakeTagContainer(const TArray<FString>& TagNames);
};
