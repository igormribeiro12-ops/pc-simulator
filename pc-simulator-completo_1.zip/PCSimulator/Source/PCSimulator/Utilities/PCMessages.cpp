﻿#include "Utilities/PCMessages.h"

#include "Engine/AssetManager.h"
#include "Engine/StreamableManager.h"
#include "Internationalization/StringTable.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCSimulatorSettings.h"

namespace PCMessages
{
	static TSharedPtr<FStreamableHandle> GTableHandle;

	void PreloadAsync()
	{
		const TSoftObjectPtr<UStringTable>& Table = UPCSimulatorSettings::Get().PlayerMessagesTable;
		if (Table.IsNull() || Table.Get() != nullptr || GTableHandle.IsValid() || !UAssetManager::IsInitialized())
		{
			return;
		}
		GTableHandle = UAssetManager::GetStreamableManager().RequestAsyncLoad(Table.ToSoftObjectPath());
	}

	FText Get(const FGameplayTag& Code)
	{
		const FString Key = Code.ToString();
		if (const UStringTable* Table = UPCSimulatorSettings::Get().PlayerMessagesTable.Get())
		{
			return FText::FromStringTable(Table->GetStringTableId(), Key, EStringTableLoadingPolicy::Find);
		}

		UE_LOG(LogPCPresentation, Verbose, TEXT("ST_PlayerMessages não carregada; exibindo código %s."), *Key);
		return FText::FromString(Key);
	}
}
