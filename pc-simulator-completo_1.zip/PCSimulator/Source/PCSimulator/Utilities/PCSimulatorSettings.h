﻿#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "PCSimulatorSettings.generated.h"

class UPCAudioSet;
class UPCCompatibilityRuleSet;
class UStringTable;

/**
 * Configuração central (Project Settings > Game > PC Simulator), salva em DefaultGame.ini.
 * Todos os números "mágicos" do jogo vivem aqui e são ajustáveis sem recompilar.
 */
UCLASS(Config = Game, DefaultConfig, meta = (DisplayName = "PC Simulator"))
class PCSIMULATOR_API UPCSimulatorSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UPCSimulatorSettings();

	static const UPCSimulatorSettings& Get() { return *GetDefault<UPCSimulatorSettings>(); }

	// ---------------- Network ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Network")
	FString ServerUrl = TEXT("ws://127.0.0.1:8765");

	UPROPERTY(Config, EditAnywhere, Category = "Network")
	bool bAutoConnect = true;

	/** Ping após N segundos sem mensagens. */
	UPROPERTY(Config, EditAnywhere, Category = "Network", meta = (ClampMin = "1.0"))
	float HeartbeatIntervalSeconds = 15.f;

	/** Prazo para pong / connection.hello. */
	UPROPERTY(Config, EditAnywhere, Category = "Network", meta = (ClampMin = "1.0"))
	float ResponseTimeoutSeconds = 10.f;

	UPROPERTY(Config, EditAnywhere, Category = "Network", meta = (ClampMin = "0.1"))
	float InitialBackoffSeconds = 1.f;

	UPROPERTY(Config, EditAnywhere, Category = "Network", meta = (ClampMin = "1.0"))
	float MaxBackoffSeconds = 30.f;

	UPROPERTY(Config, EditAnywhere, Category = "Network", meta = (ClampMin = "1024"))
	int32 MaxMessageBytes = 65536;

	// ---------------- Build ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Build", meta = (ClampMin = "1"))
	int32 MaxComponentsPerBuild = 32;

	/** Atores com esta tag definem a origem do spawn (ex.: a bancada). */
	UPROPERTY(Config, EditAnywhere, Category = "Build")
	FName BuildOriginActorTag = TEXT("PCBuildOrigin");

	UPROPERTY(Config, EditAnywhere, Category = "Build", meta = (ClampMin = "1.0"))
	float ItemSpacingCm = 35.f;

	// ---------------- Compatibility ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Compatibility")
	TSoftObjectPtr<UPCCompatibilityRuleSet> RuleSet;

	// ---------------- Assembly ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Assembly", meta = (ClampMin = "1.0", ClampMax = "90.0"))
	float RotationSnapDegrees = 15.f;

	UPROPERTY(Config, EditAnywhere, Category = "Assembly", meta = (ClampMin = "0.0", ClampMax = "45.0"))
	float OrientationToleranceDegrees = 5.f;

	/** Raio de busca do slot mais próximo ao soltar/instalar o item segurado. */
	UPROPERTY(Config, EditAnywhere, Category = "Assembly", meta = (ClampMin = "1.0"))
	float SlotSearchRadiusCm = 30.f;

	UPROPERTY(Config, EditAnywhere, Category = "Assembly", meta = (ClampMin = "0.0"))
	float InstallAnimationSeconds = 0.25f;

	// ---------------- Interaction ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Interaction", meta = (ClampMin = "10.0"))
	float InteractionRangeCm = 300.f;

	UPROPERTY(Config, EditAnywhere, Category = "Interaction", meta = (ClampMin = "1.0", ClampMax = "120.0"))
	float InteractionRateHz = 30.f;

	UPROPERTY(Config, EditAnywhere, Category = "Interaction", meta = (ClampMin = "5.0"))
	float HoldDistanceCm = 45.f;

	/** Distância máxima entre o ponto mirado e um conector para focá-lo. */
	UPROPERTY(Config, EditAnywhere, Category = "Interaction", meta = (ClampMin = "0.5"))
	float ConnectorPickRadiusCm = 6.f;

	// ---------------- Power ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Power", meta = (ClampMin = "0.0"))
	float FanSpinUpDelaySeconds = 0.5f;

	UPROPERTY(Config, EditAnywhere, Category = "Power", meta = (ClampMin = "0.0"))
	float BootDurationSeconds = 3.f;

	// ---------------- Presentation ----------------
	UPROPERTY(Config, EditAnywhere, Category = "Presentation")
	TSoftObjectPtr<UPCAudioSet> AudioSet;

	/** Chave = nome da tag de erro (ex.: "AssemblyError.SlotOccupied"). */
	UPROPERTY(Config, EditAnywhere, Category = "Presentation")
	TSoftObjectPtr<UStringTable> PlayerMessagesTable;
};
