﻿#pragma once

#include "CoreMinimal.h"
#include "NativeGameplayTags.h"

/**
 * Tags referenciadas pelo código. Fonte da verdade: Config/DefaultGameplayTags.ini.
 * PCSimulator.Unit.Tags.NativeTagsExistInIni garante a paridade.
 */
namespace PCTags
{
	// Tipos de componente
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_CPU);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_GPU);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_Motherboard);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_RAM);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_Storage);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_PSU);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_Case);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_Fan);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Component_Cable);

	// Sockets usados por regras
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(Socket_PCIe_x16);

	// Erros de build
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_SchemaVersionUnsupported);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_MalformedJson);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_MissingField);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_InvalidFieldValue);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_UnknownComponentTag);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_DuplicateComponentTag);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_MissingRequiredComponent);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_UnknownComponentId);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_ComponentTypeMismatch);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_AssetNotFound);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_IncompatibleBuild);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_DuplicateBuild);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BuildError_InvalidState);

	// Erros de montagem
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError_SlotOccupied);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError_SlotMismatch);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError_Incompatible);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError_WrongOrientation);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError_OutOfRange);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(AssemblyError_MissingPrerequisite);

	// Erros de rede
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(NetworkError);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(NetworkError_Timeout);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(NetworkError_Disconnected);
	PCSIMULATOR_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(NetworkError_ProtocolViolation);

	/** Tipos obrigatórios em uma build schemaVersion 1. */
	PCSIMULATOR_API const TArray<FGameplayTag>& GetRequiredBuildTypes();

	/** Todas as tags nativas (teste de paridade com o .ini). */
	PCSIMULATOR_API TArray<FGameplayTag> GetAllNativeTags();

	/** Representação no fio (string idêntica ao nome da tag). */
	PCSIMULATOR_API FString ToWire(const FGameplayTag& Tag);
}
