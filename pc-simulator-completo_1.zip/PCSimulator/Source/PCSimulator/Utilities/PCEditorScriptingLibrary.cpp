﻿#include "Utilities/PCEditorScriptingLibrary.h"

#include "Utilities/PCLog.h"

FGameplayTag UPCEditorScriptingLibrary::MakeTag(const FString& TagName)
{
	const FGameplayTag Tag = FGameplayTag::RequestGameplayTag(FName(*TagName), /*ErrorIfNotFound*/ false);
	if (!Tag.IsValid() && !TagName.IsEmpty())
	{
		UE_LOG(LogPCCatalog, Warning, TEXT("Tag não registrada: %s (adicione em DefaultGameplayTags.ini)."), *TagName);
	}
	return Tag;
}

FGameplayTagContainer UPCEditorScriptingLibrary::MakeTagContainer(const TArray<FString>& TagNames)
{
	FGameplayTagContainer Container;
	for (const FString& Name : TagNames)
	{
		const FGameplayTag Tag = MakeTag(Name);
		if (Tag.IsValid())
		{
			Container.AddTag(Tag);
		}
	}
	return Container;
}
