﻿#include "Utilities/PCSimulatorSettings.h"

UPCSimulatorSettings::UPCSimulatorSettings()
{
	CategoryName = TEXT("Game");
}
