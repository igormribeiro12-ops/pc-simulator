﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"

/**
 * Mensagens ao jogador a partir da String Table ST_PlayerMessages (§16).
 * Chave = nome da tag de erro. Sem tabela carregada, devolve o próprio código (nunca vazio).
 */
namespace PCMessages
{
	/** Inicia a carga assíncrona da String Table configurada. Idempotente. */
	PCSIMULATOR_API void PreloadAsync();

	PCSIMULATOR_API FText Get(const FGameplayTag& Code);
}
