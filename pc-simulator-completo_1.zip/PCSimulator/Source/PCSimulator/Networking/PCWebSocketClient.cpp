﻿#include "Networking/PCWebSocketClient.h"

#include "Async/Async.h"
#include "IWebSocket.h"
#include "Modules/ModuleManager.h"
#include "Utilities/PCLog.h"
#include "WebSocketsModule.h"

FPCWebSocketClient::~FPCWebSocketClient()
{
	Close();
}

bool FPCWebSocketClient::Connect(const FString& Url)
{
	Close();

	if (!Url.StartsWith(TEXT("ws://")) && !Url.StartsWith(TEXT("wss://")))
	{
		UE_LOG(LogPCNetwork, Error, TEXT("URL inválida: %s"), *Url);
		return false;
	}

	FWebSocketsModule& Module = FModuleManager::LoadModuleChecked<FWebSocketsModule>(TEXT("WebSockets"));
	Socket = Module.CreateWebSocket(Url, FString());
	if (!Socket.IsValid())
	{
		return false;
	}

	Socket->OnConnected().AddSP(AsShared(), &FPCWebSocketClient::HandleConnected);
	Socket->OnConnectionError().AddSP(AsShared(), &FPCWebSocketClient::HandleConnectionError);
	Socket->OnClosed().AddSP(AsShared(), &FPCWebSocketClient::HandleClosed);
	Socket->OnMessage().AddSP(AsShared(), &FPCWebSocketClient::HandleMessage);
	Socket->Connect();
	return true;
}

void FPCWebSocketClient::Close(int32 Code, const FString& Reason)
{
	if (!Socket.IsValid())
	{
		return;
	}
	Unbind();
	if (Socket->IsConnected())
	{
		Socket->Close(Code, Reason);
	}
	Socket.Reset();
}

bool FPCWebSocketClient::Send(const FString& Message)
{
	if (!IsConnected())
	{
		return false;
	}
	Socket->Send(Message);
	return true;
}

bool FPCWebSocketClient::IsConnected() const
{
	return Socket.IsValid() && Socket->IsConnected();
}

void FPCWebSocketClient::Unbind()
{
	if (Socket.IsValid())
	{
		Socket->OnConnected().RemoveAll(this);
		Socket->OnConnectionError().RemoveAll(this);
		Socket->OnClosed().RemoveAll(this);
		Socket->OnMessage().RemoveAll(this);
	}
}

void FPCWebSocketClient::RunOnGameThread(TFunction<void()> Work)
{
	if (IsInGameThread())
	{
		Work();
		return;
	}
	TWeakPtr<FPCWebSocketClient> WeakThis = AsShared();
	AsyncTask(ENamedThreads::GameThread, [WeakThis, Work = MoveTemp(Work)]()
	{
		// Pin mantém o cliente vivo durante o callback.
		if (const TSharedPtr<FPCWebSocketClient> Pinned = WeakThis.Pin())
		{
			Work();
		}
	});
}

void FPCWebSocketClient::HandleConnected()
{
	RunOnGameThread([this]() { OnConnected.ExecuteIfBound(); });
}

void FPCWebSocketClient::HandleConnectionError(const FString& Error)
{
	RunOnGameThread([this, Error]() { OnConnectionError.ExecuteIfBound(Error); });
}

void FPCWebSocketClient::HandleClosed(int32 StatusCode, const FString& Reason, bool bWasClean)
{
	RunOnGameThread([this, StatusCode, Reason, bWasClean]() { OnClosed.ExecuteIfBound(StatusCode, Reason, bWasClean); });
}

void FPCWebSocketClient::HandleMessage(const FString& Message)
{
	RunOnGameThread([this, Message]() { OnMessage.ExecuteIfBound(Message); });
}
