﻿#include "Networking/PCEnvelope.h"

#include "Data/PCTypes.h"
#include "Dom/JsonObject.h"
#include "Misc/DateTime.h"
#include "Misc/Guid.h"
#include "Policies/CondensedJsonPrintPolicy.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

bool FPCEnvelope::Parse(const FString& Raw, int32 MaxBytes, FPCEnvelope& Out, FString& OutError, bool& bOutTooLarge)
{
	Out = FPCEnvelope();
	bOutTooLarge = false;

	const FTCHARToUTF8 Utf8(*Raw);
	if (Utf8.Length() > MaxBytes)
	{
		bOutTooLarge = true;
		OutError = FString::Printf(TEXT("Mensagem com %d bytes excede o limite de %d."), Utf8.Length(), MaxBytes);
		return false;
	}

	TSharedPtr<FJsonObject> Root;
	const TSharedRef<TJsonReader<TCHAR>> Reader = TJsonReaderFactory<TCHAR>::Create(Raw);
	if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid())
	{
		OutError = TEXT("JSON inválido no envelope.");
		return false;
	}

	if (!Root->TryGetStringField(TEXT("type"), Out.Type) || Out.Type.IsEmpty())
	{
		OutError = TEXT("Envelope sem 'type'.");
		return false;
	}

	double Version = 0.0;
	if (!Root->TryGetNumberField(TEXT("version"), Version) || Version != static_cast<double>(ProtocolVersion))
	{
		OutError = TEXT("Versão de protocolo ausente ou não suportada.");
		return false;
	}
	Out.Version = ProtocolVersion;

	if (!Root->TryGetStringField(TEXT("requestId"), Out.RequestId) || !PCIds::IsCanonicalUuid(Out.RequestId))
	{
		OutError = TEXT("requestId ausente ou não é UUID canônico minúsculo.");
		return false;
	}

	double Timestamp = 0.0;
	if (!Root->TryGetNumberField(TEXT("timestamp"), Timestamp))
	{
		OutError = TEXT("Envelope sem 'timestamp'.");
		return false;
	}
	Out.Timestamp = static_cast<int64>(Timestamp);

	const TSharedPtr<FJsonValue>* Payload = Root->Values.Find(TEXT("payload"));
	if (!Payload || !Payload->IsValid() || (*Payload)->Type != EJson::Object)
	{
		OutError = TEXT("Envelope sem 'payload' objeto.");
		return false;
	}
	Out.Payload = (*Payload)->AsObject();
	return true;
}

FString FPCEnvelope::Serialize(const FString& Type, const FString& RequestId, const TSharedRef<FJsonObject>& Payload)
{
	const TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
	Root->SetStringField(TEXT("type"), Type);
	Root->SetNumberField(TEXT("version"), ProtocolVersion);
	Root->SetStringField(TEXT("requestId"), RequestId);
	Root->SetNumberField(TEXT("timestamp"), static_cast<double>(FDateTime::UtcNow().ToUnixTimestamp()));
	Root->SetObjectField(TEXT("payload"), Payload);

	FString Output;
	const TSharedRef<TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>> Writer =
		TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&Output);
	FJsonSerializer::Serialize(Root, Writer);
	return Output;
}

FString FPCEnvelope::NewRequestId()
{
	return FGuid::NewGuid().ToString(EGuidFormats::DigitsWithHyphens).ToLower();
}

bool FPCEnvelope::IsKnownIncomingType(const FString& Type)
{
	return Type == TEXT("connection.hello")
		|| Type == TEXT("build.deliver")
		|| Type == TEXT("ping")
		|| Type == TEXT("pong");
}
