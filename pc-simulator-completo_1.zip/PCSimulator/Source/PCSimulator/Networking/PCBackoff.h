﻿#pragma once

#include "CoreMinimal.h"

namespace PCBackoff
{
	/** Atraso da tentativa N (0-based): Initial * 2^N, limitado a Max. Padrão: 1, 2, 4, 8, 16, 30, 30... */
	inline float GetDelaySeconds(int32 Attempt, float InitialSeconds, float MaxSeconds)
	{
		const int32 Exponent = FMath::Clamp(Attempt, 0, 30);
		const double Delay = static_cast<double>(InitialSeconds) * FMath::Pow(2.0, static_cast<double>(Exponent));
		return static_cast<float>(FMath::Min(Delay, static_cast<double>(MaxSeconds)));
	}
}
