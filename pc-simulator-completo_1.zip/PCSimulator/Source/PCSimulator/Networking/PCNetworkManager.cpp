﻿#include "Networking/PCNetworkManager.h"

#include "Dom/JsonObject.h"
#include "Engine/GameInstance.h"
#include "Networking/PCBackoff.h"
#include "Networking/PCEnvelope.h"
#include "Networking/PCWebSocketClient.h"
#include "Utilities/PCGameplayTags.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCSimulatorSettings.h"

void UPCNetworkManager::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	if (UPCSimulatorSettings::Get().bAutoConnect)
	{
		Connect();
	}
}

void UPCNetworkManager::Deinitialize()
{
	Disconnect();
	Super::Deinitialize();
}

FTimerManager* UPCNetworkManager::GetTimers() const
{
	const UGameInstance* GameInstance = GetGameInstance();
	return GameInstance ? &GameInstance->GetTimerManager() : nullptr;
}

void UPCNetworkManager::Connect()
{
	bWantsConnection = true;
	ReconnectAttempt = 0;
	OpenSocket();
}

void UPCNetworkManager::Disconnect()
{
	bWantsConnection = false;
	if (FTimerManager* Timers = GetTimers())
	{
		Timers->ClearTimer(ReconnectTimer);
	}
	Teardown();
	SetState(EPCConnectionState::Disconnected);
}

void UPCNetworkManager::OpenSocket()
{
	Teardown();

	const FString& Url = UPCSimulatorSettings::Get().ServerUrl;
	Client = MakeShared<FPCWebSocketClient>();
	Client->OnConnected.BindUObject(this, &ThisClass::HandleConnected);
	Client->OnConnectionError.BindUObject(this, &ThisClass::HandleConnectionError);
	Client->OnClosed.BindUObject(this, &ThisClass::HandleClosed);
	Client->OnMessage.BindUObject(this, &ThisClass::HandleMessage);

	SetState(EPCConnectionState::Connecting);
	UE_LOG(LogPCNetwork, Log, TEXT("Conectando a %s (tentativa %d)."), *Url, ReconnectAttempt + 1);

	if (!Client->Connect(Url))
	{
		HandleConnectionError(TEXT("Não foi possível criar o socket."));
	}
}

void UPCNetworkManager::Teardown()
{
	if (FTimerManager* Timers = GetTimers())
	{
		Timers->ClearTimer(HeartbeatTimer);
		Timers->ClearTimer(ResponseTimer);
	}
	PendingPingId.Reset();

	if (Client.IsValid())
	{
		Client->OnConnected.Unbind();
		Client->OnConnectionError.Unbind();
		Client->OnClosed.Unbind();
		Client->OnMessage.Unbind();
		Client->Close();
		Client.Reset();
	}
}

void UPCNetworkManager::SetState(EPCConnectionState NewState)
{
	if (State == NewState)
	{
		return;
	}
	const EPCConnectionState OldState = State;
	State = NewState;
	OnConnectionStateChanged.Broadcast(OldState, NewState);
}

void UPCNetworkManager::ScheduleReconnect()
{
	FTimerManager* Timers = GetTimers();
	if (!bWantsConnection || !Timers)
	{
		return;
	}
	const UPCSimulatorSettings& Settings = UPCSimulatorSettings::Get();
	const float Delay = PCBackoff::GetDelaySeconds(ReconnectAttempt, Settings.InitialBackoffSeconds, Settings.MaxBackoffSeconds);
	++ReconnectAttempt;

	UE_LOG(LogPCNetwork, Log, TEXT("Reconectando em %.0f s."), Delay);
	Timers->SetTimer(ReconnectTimer, this, &ThisClass::OpenSocket, Delay, false);
}

void UPCNetworkManager::ReportError(const FGameplayTag& Code, const FString& Detail)
{
	UE_LOG(LogPCNetwork, Warning, TEXT("%s: %s"), *Code.ToString(), *Detail);
	OnNetworkError.Broadcast(Code, Detail);
}

void UPCNetworkManager::DropConnection(const FGameplayTag& Code, const FString& Detail, int32 CloseCode)
{
	ReportError(Code, Detail);
	if (Client.IsValid())
	{
		Client->Close(CloseCode, Detail);
	}
	Teardown();
	SetState(EPCConnectionState::Disconnected);
	ScheduleReconnect();
}

bool UPCNetworkManager::Send(const FString& Type, const FString& RequestId, const TSharedRef<FJsonObject>& Payload)
{
	const bool bHandshake = Type == TEXT("connection.hello") && State == EPCConnectionState::Handshaking;
	if (!Client.IsValid() || (State != EPCConnectionState::Ready && !bHandshake))
	{
		UE_LOG(LogPCNetwork, Verbose, TEXT("Envio de %s descartado: conexão não pronta."), *Type);
		return false;
	}
	return Client->Send(FPCEnvelope::Serialize(Type, RequestId, Payload));
}

// ---------------------------------------------------------------- Callbacks

void UPCNetworkManager::HandleConnected()
{
	SetState(EPCConnectionState::Handshaking);
	SendHello();

	if (FTimerManager* Timers = GetTimers())
	{
		Timers->SetTimer(ResponseTimer, this, &ThisClass::HandleResponseTimeout,
			UPCSimulatorSettings::Get().ResponseTimeoutSeconds, false);
	}
}

void UPCNetworkManager::HandleConnectionError(const FString& Error)
{
	ReportError(PCTags::NetworkError_Disconnected, Error);
	Teardown();
	SetState(EPCConnectionState::Disconnected);
	ScheduleReconnect();
}

void UPCNetworkManager::HandleClosed(int32 StatusCode, const FString& Reason, bool bWasClean)
{
	ReportError(PCTags::NetworkError_Disconnected,
		FString::Printf(TEXT("Fechado (%d, %s): %s"), StatusCode, bWasClean ? TEXT("limpo") : TEXT("abrupto"), *Reason));
	Teardown();
	SetState(EPCConnectionState::Disconnected);
	ScheduleReconnect();
}

void UPCNetworkManager::HandleMessage(const FString& Raw)
{
	FPCEnvelope Envelope;
	FString Error;
	bool bTooLarge = false;
	if (!FPCEnvelope::Parse(Raw, UPCSimulatorSettings::Get().MaxMessageBytes, Envelope, Error, bTooLarge))
	{
		if (bTooLarge)
		{
			DropConnection(PCTags::NetworkError_ProtocolViolation, Error, 1009);
		}
		else
		{
			ReportError(PCTags::NetworkError_ProtocolViolation, Error);
		}
		return;
	}
	if (!FPCEnvelope::IsKnownIncomingType(Envelope.Type))
	{
		ReportError(PCTags::NetworkError_ProtocolViolation, FString::Printf(TEXT("Tipo desconhecido: %s"), *Envelope.Type));
		return;
	}

	if (Envelope.Type == TEXT("connection.hello"))
	{
		if (State == EPCConnectionState::Handshaking)
		{
			if (FTimerManager* Timers = GetTimers())
			{
				Timers->ClearTimer(ResponseTimer);
			}
			ReconnectAttempt = 0;
			SetState(EPCConnectionState::Ready);
			RestartHeartbeat();
			UE_LOG(LogPCNetwork, Log, TEXT("Conexão pronta."));
		}
		return;
	}

	if (State != EPCConnectionState::Ready)
	{
		ReportError(PCTags::NetworkError_ProtocolViolation, FString::Printf(TEXT("%s antes do handshake."), *Envelope.Type));
		return;
	}
	RestartHeartbeat(); // heartbeat = silêncio; qualquer mensagem válida reinicia a contagem

	if (Envelope.Type == TEXT("ping"))
	{
		Send(TEXT("pong"), Envelope.RequestId, MakeShared<FJsonObject>());
		return;
	}
	if (Envelope.Type == TEXT("pong"))
	{
		if (!PendingPingId.IsEmpty() && Envelope.RequestId == PendingPingId)
		{
			PendingPingId.Reset();
			if (FTimerManager* Timers = GetTimers())
			{
				Timers->ClearTimer(ResponseTimer);
			}
		}
		return;
	}

	OnMessageReceived.Broadcast(Envelope.Type, Envelope.RequestId, Envelope.Payload.ToSharedRef(), Raw);
}

// ---------------------------------------------------------------- Heartbeat

void UPCNetworkManager::SendHello()
{
	const TSharedRef<FJsonObject> Payload = MakeShared<FJsonObject>();
	Payload->SetStringField(TEXT("clientVersion"), TEXT("0.1.0"));
	Payload->SetNumberField(TEXT("protocolVersion"), FPCEnvelope::ProtocolVersion);
	TArray<TSharedPtr<FJsonValue>> Versions;
	Versions.Add(MakeShared<FJsonValueNumber>(1));
	Payload->SetArrayField(TEXT("supportedSchemaVersions"), Versions);
	Send(TEXT("connection.hello"), FPCEnvelope::NewRequestId(), Payload);
}

void UPCNetworkManager::RestartHeartbeat()
{
	if (FTimerManager* Timers = GetTimers())
	{
		Timers->SetTimer(HeartbeatTimer, this, &ThisClass::SendPing,
			UPCSimulatorSettings::Get().HeartbeatIntervalSeconds, false);
	}
}

void UPCNetworkManager::SendPing()
{
	if (State != EPCConnectionState::Ready || !PendingPingId.IsEmpty())
	{
		return;
	}
	PendingPingId = FPCEnvelope::NewRequestId();
	Send(TEXT("ping"), PendingPingId, MakeShared<FJsonObject>());

	if (FTimerManager* Timers = GetTimers())
	{
		Timers->SetTimer(ResponseTimer, this, &ThisClass::HandleResponseTimeout,
			UPCSimulatorSettings::Get().ResponseTimeoutSeconds, false);
	}
}

void UPCNetworkManager::HandleResponseTimeout()
{
	DropConnection(PCTags::NetworkError_Timeout,
		State == EPCConnectionState::Handshaking ? TEXT("Sem connection.hello do servidor.") : TEXT("Sem pong do servidor."),
		1000);
}
