﻿#pragma once

#include "CoreMinimal.h"

class FJsonObject;

/** Envelope do protocolo v1 (§6.1). Parse e serialização puros (testáveis sem socket). */
struct PCSIMULATOR_API FPCEnvelope
{
	static constexpr int32 ProtocolVersion = 1;

	FString Type;
	int32 Version = 0;
	FString RequestId;
	int64 Timestamp = 0;
	TSharedPtr<FJsonObject> Payload;

	/**
	 * @param bOutTooLarge true se a mensagem exceder MaxBytes (UTF-8); o chamador deve fechar com 1009.
	 * @return false em qualquer violação de protocolo (OutError descreve).
	 */
	static bool Parse(const FString& Raw, int32 MaxBytes, FPCEnvelope& Out, FString& OutError, bool& bOutTooLarge);

	static FString Serialize(const FString& Type, const FString& RequestId, const TSharedRef<FJsonObject>& Payload);

	/** UUID v4 canônico minúsculo. */
	static FString NewRequestId();

	/** Tipos que o cliente aceita receber. */
	static bool IsKnownIncomingType(const FString& Type);
};
