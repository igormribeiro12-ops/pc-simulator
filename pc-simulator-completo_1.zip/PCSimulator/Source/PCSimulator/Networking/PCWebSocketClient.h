﻿#pragma once

#include "CoreMinimal.h"

class IWebSocket;

/**
 * Invólucro fino sobre IWebSocket (módulo WebSockets da engine).
 * Isola a API da engine e garante que todo callback chegue na game thread.
 * Não conhece o protocolo; só transporta texto.
 */
class PCSIMULATOR_API FPCWebSocketClient : public TSharedFromThis<FPCWebSocketClient>
{
public:
	DECLARE_DELEGATE(FOnConnected);
	DECLARE_DELEGATE_OneParam(FOnConnectionError, const FString& /*Error*/);
	DECLARE_DELEGATE_ThreeParams(FOnClosed, int32 /*StatusCode*/, const FString& /*Reason*/, bool /*bWasClean*/);
	DECLARE_DELEGATE_OneParam(FOnMessage, const FString& /*Message*/);

	~FPCWebSocketClient();

	/** Cria e abre o socket. false se a URL for inválida ou o módulo indisponível. */
	bool Connect(const FString& Url);

	/** Fecha sem disparar mais callbacks. */
	void Close(int32 Code = 1000, const FString& Reason = FString());

	bool Send(const FString& Message);
	bool IsConnected() const;

	FOnConnected OnConnected;
	FOnConnectionError OnConnectionError;
	FOnClosed OnClosed;
	FOnMessage OnMessage;

private:
	void Unbind();

	void HandleConnected();
	void HandleConnectionError(const FString& Error);
	void HandleClosed(int32 StatusCode, const FString& Reason, bool bWasClean);
	void HandleMessage(const FString& Message);

	/** Executa na game thread (direto se já estiver nela). */
	void RunOnGameThread(TFunction<void()> Work);

	TSharedPtr<IWebSocket> Socket;
};
