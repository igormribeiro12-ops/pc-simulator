﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "TimerManager.h"
#include "PCNetworkManager.generated.h"

class FJsonObject;
class FPCWebSocketClient;

UENUM(BlueprintType)
enum class EPCConnectionState : uint8
{
	Disconnected,
	Connecting,
	Handshaking,
	Ready
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnConnectionStateChanged, EPCConnectionState, OldState, EPCConnectionState, NewState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnNetworkError, FGameplayTag, Code, const FString&, Detail);

/** Nativo (não dynamic): TSharedRef<FJsonObject> não é tipo refletível. Exceção justificada ao §3. */
DECLARE_MULTICAST_DELEGATE_FourParams(FPCOnMessageReceived,
	const FString& /*Type*/, const FString& /*RequestId*/, const TSharedRef<FJsonObject>& /*Payload*/, const FString& /*RawMessage*/);

/**
 * Protocolo v1 (§6.1): handshake, heartbeat, reconexão com backoff e tradução de erros para NetworkError.*.
 * Não conhece builds: repassa mensagens de aplicação (build.deliver) por OnMessageReceived.
 * Erros nunca propagam para o gameplay: viram eventos tipados.
 */
UCLASS()
class PCSIMULATOR_API UPCNetworkManager : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	void Connect();
	void Disconnect();

	/** false se não estiver Ready (ou Handshaking para connection.hello). */
	bool Send(const FString& Type, const FString& RequestId, const TSharedRef<FJsonObject>& Payload);

	EPCConnectionState GetState() const { return State; }

	FPCOnMessageReceived OnMessageReceived;

	UPROPERTY(BlueprintAssignable)
	FPCOnConnectionStateChanged OnConnectionStateChanged;

	UPROPERTY(BlueprintAssignable)
	FPCOnNetworkError OnNetworkError;

private:
	void OpenSocket();
	void Teardown();
	void SetState(EPCConnectionState NewState);
	void ScheduleReconnect();
	void DropConnection(const FGameplayTag& Code, const FString& Detail, int32 CloseCode);
	void ReportError(const FGameplayTag& Code, const FString& Detail);

	void HandleConnected();
	void HandleConnectionError(const FString& Error);
	void HandleClosed(int32 StatusCode, const FString& Reason, bool bWasClean);
	void HandleMessage(const FString& Raw);

	void SendHello();
	void SendPing();
	void RestartHeartbeat();
	void HandleResponseTimeout();

	FTimerManager* GetTimers() const;

	TSharedPtr<FPCWebSocketClient> Client;
	EPCConnectionState State = EPCConnectionState::Disconnected;
	int32 ReconnectAttempt = 0;
	bool bWantsConnection = false;
	FString PendingPingId;

	FTimerHandle ReconnectTimer;
	FTimerHandle HeartbeatTimer;
	FTimerHandle ResponseTimer;
};
