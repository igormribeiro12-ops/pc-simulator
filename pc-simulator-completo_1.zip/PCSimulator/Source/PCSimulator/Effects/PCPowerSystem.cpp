﻿#include "Effects/PCPowerSystem.h"

#include "Assembly/PCAssemblyProgressTracker.h"
#include "Assembly/PCAssemblySystem.h"
#include "Engine/World.h"
#include "Utilities/PCGameplayTags.h"
#include "Utilities/PCLog.h"
#include "Utilities/PCMessages.h"
#include "Utilities/PCSimulatorSettings.h"

void UPCPowerSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	Tracker = Collection.InitializeDependency<UPCAssemblyProgressTracker>();
}

void UPCPowerSystem::Deinitialize()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(FanTimer);
		World->GetTimerManager().ClearTimer(BootTimer);
	}
	Super::Deinitialize();
}

bool UPCPowerSystem::RequestPowerOn()
{
	if (PowerState != EPCPowerState::Off)
	{
		return false;
	}

	const UPCAssemblyProgressTracker* ProgressTracker = Tracker.Get();
	if (!ProgressTracker || !ProgressTracker->IsComplete())
	{
		UE_LOG(LogPCPower, Log, TEXT("Power negado: montagem incompleta."));
		OnPowerFailed.Broadcast(PCTags::AssemblyError_MissingPrerequisite, PCMessages::Get(PCTags::AssemblyError_MissingPrerequisite));
		return false;
	}

	PowerState = EPCPowerState::Starting;
	if (UPCAssemblySystem* Assembly = GetWorld()->GetSubsystem<UPCAssemblySystem>())
	{
		Assembly->SetLocked(true);
	}
	UE_LOG(LogPCPower, Log, TEXT("Sequência de energia iniciada."));
	OnPowerSequenceStarted.Broadcast();

	const UPCSimulatorSettings& Settings = UPCSimulatorSettings::Get();
	FTimerManager& Timers = GetWorld()->GetTimerManager();

	if (Settings.FanSpinUpDelaySeconds > 0.f)
	{
		Timers.SetTimer(FanTimer, this, &ThisClass::HandleFansStarted, Settings.FanSpinUpDelaySeconds, false);
	}
	else
	{
		HandleFansStarted();
	}

	if (Settings.BootDurationSeconds > 0.f)
	{
		Timers.SetTimer(BootTimer, this, &ThisClass::HandleBootCompleted, Settings.BootDurationSeconds, false);
	}
	else
	{
		HandleBootCompleted();
	}
	return true;
}

void UPCPowerSystem::HandleFansStarted()
{
	if (PowerState == EPCPowerState::Starting)
	{
		OnFansStarted.Broadcast();
	}
}

void UPCPowerSystem::HandleBootCompleted()
{
	if (PowerState != EPCPowerState::Starting)
	{
		return;
	}
	PowerState = EPCPowerState::Running;
	UE_LOG(LogPCPower, Log, TEXT("Boot concluído."));
	OnBootCompleted.Broadcast();
}

void UPCPowerSystem::ResetPower()
{
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(FanTimer);
		World->GetTimerManager().ClearTimer(BootTimer);
		if (UPCAssemblySystem* Assembly = World->GetSubsystem<UPCAssemblySystem>())
		{
			Assembly->SetLocked(false);
		}
	}
	if (PowerState != EPCPowerState::Off)
	{
		PowerState = EPCPowerState::Off;
		OnPoweredOff.Broadcast();
	}
}
