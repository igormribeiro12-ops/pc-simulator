﻿#include "Effects/PCRGBController.h"

#include "Components/ComputerComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Data/PCComponentDataAsset.h"
#include "Effects/PCPowerSystem.h"
#include "Engine/World.h"
#include "Materials/MaterialInstanceDynamic.h"

UPCRGBController::UPCRGBController()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UPCRGBController::BeginPlay()
{
	Super::BeginPlay();
	if (UPCPowerSystem* Power = GetWorld() ? GetWorld()->GetSubsystem<UPCPowerSystem>() : nullptr)
	{
		Power->OnPowerSequenceStarted.AddUniqueDynamic(this, &ThisClass::HandlePowerStarted);
		Power->OnPoweredOff.AddUniqueDynamic(this, &ThisClass::HandlePoweredOff);
	}
}

void UPCRGBController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UPCPowerSystem* Power = GetWorld() ? GetWorld()->GetSubsystem<UPCPowerSystem>() : nullptr)
	{
		Power->OnPowerSequenceStarted.RemoveDynamic(this, &ThisClass::HandlePowerStarted);
		Power->OnPoweredOff.RemoveDynamic(this, &ThisClass::HandlePoweredOff);
	}
	Super::EndPlay(EndPlayReason);
}

void UPCRGBController::HandlePowerStarted()
{
	const AComputerComponent* Owner = Cast<AComputerComponent>(GetOwner());
	const UPCComponentDataAsset* Data = Owner ? Owner->GetData() : nullptr;
	if (!Data || !Data->bHasRGB || !Owner->IsInstalled())
	{
		return;
	}
	ApplyColor(Data->RGBColor * Data->RGBIntensity);
	bLit = true;
}

void UPCRGBController::HandlePoweredOff()
{
	if (bLit)
	{
		ApplyColor(FLinearColor::Black);
		bLit = false;
	}
}

void UPCRGBController::ApplyColor(const FLinearColor& Color)
{
	const AComputerComponent* Owner = Cast<AComputerComponent>(GetOwner());
	UStaticMeshComponent* Mesh = Owner ? Owner->GetMesh() : nullptr;
	if (!Mesh || MaterialIndex >= Mesh->GetNumMaterials())
	{
		return;
	}
	if (!DynamicMaterial)
	{
		DynamicMaterial = Mesh->CreateDynamicMaterialInstance(MaterialIndex);
	}
	if (DynamicMaterial)
	{
		DynamicMaterial->SetVectorParameterValue(EmissiveParameterName, Color);
	}
}
