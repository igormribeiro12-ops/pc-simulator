﻿#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Subsystems/WorldSubsystem.h"
#include "TimerManager.h"
#include "PCPowerSystem.generated.h"

class UPCAssemblyProgressTracker;

UENUM(BlueprintType)
enum class EPCPowerState : uint8
{
	Off,
	Starting,
	Running
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FPCOnPowerEvent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FPCOnPowerFailed, FGameplayTag, Code, FText, Reason);

/**
 * Sequência de energia: pré-requisitos (tudo instalado, cabos, painel fechado) → start → ventoinhas → boot.
 * Temporizada por timers; sem Tick. Trava a montagem enquanto ligado.
 */
UCLASS()
class PCSIMULATOR_API UPCPowerSystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	/** false se já ligado ou pré-requisitos faltando (dispara OnPowerFailed). */
	bool RequestPowerOn();
	void ResetPower();

	EPCPowerState GetPowerState() const { return PowerState; }

	UPROPERTY(BlueprintAssignable) FPCOnPowerEvent OnPowerSequenceStarted;
	UPROPERTY(BlueprintAssignable) FPCOnPowerEvent OnFansStarted;
	UPROPERTY(BlueprintAssignable) FPCOnPowerEvent OnBootCompleted;
	UPROPERTY(BlueprintAssignable) FPCOnPowerEvent OnPoweredOff;
	UPROPERTY(BlueprintAssignable) FPCOnPowerFailed OnPowerFailed;

private:
	void HandleFansStarted();
	void HandleBootCompleted();

	TWeakObjectPtr<UPCAssemblyProgressTracker> Tracker;
	EPCPowerState PowerState = EPCPowerState::Off;
	FTimerHandle FanTimer;
	FTimerHandle BootTimer;
};
