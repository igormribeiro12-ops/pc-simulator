﻿#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "PCRGBController.generated.h"

class UMaterialInstanceDynamic;

/**
 * Acende o emissivo do componente quando o PC liga (cor/intensidade do DataAsset: bHasRGB, RGBColor, RGBIntensity).
 * Reage a eventos do UPCPowerSystem; sem Tick.
 * [ASSET PENDENTE] Material M_PC_Emissive com parâmetro vetorial "EmissiveColor" no slot MaterialIndex.
 */
UCLASS(ClassGroup = (PC), meta = (BlueprintSpawnableComponent))
class PCSIMULATOR_API UPCRGBController : public UActorComponent
{
	GENERATED_BODY()

public:
	UPCRGBController();

	UPROPERTY(EditDefaultsOnly, Category = "RGB")
	FName EmissiveParameterName = TEXT("EmissiveColor");

	UPROPERTY(EditDefaultsOnly, Category = "RGB", meta = (ClampMin = "0"))
	int32 MaterialIndex = 0;

	bool IsLit() const { return bLit; }

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UFUNCTION()
	void HandlePowerStarted();

	UFUNCTION()
	void HandlePoweredOff();

	void ApplyColor(const FLinearColor& Color);

	UPROPERTY(Transient)
	TObjectPtr<UMaterialInstanceDynamic> DynamicMaterial;

	bool bLit = false;
};
