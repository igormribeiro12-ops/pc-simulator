// Módulo de runtime. Dependências conforme PROMPT_MESTRE_v2 §4.
// WebSockets, GameplayTags e Json são MÓDULOS da engine (entram aqui, não no .uproject).
using UnrealBuildTool;

public class PCSimulator : ModuleRules
{
	public PCSimulator(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		// Permite includes por camada: #include "Core/PCGameMode.h", "Data/PCTypes.h", ...
		PublicIncludePaths.Add(ModuleDirectory);

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine", "InputCore",
			"EnhancedInput",
			"GameplayTags",
			"Json", "JsonUtilities",
			"WebSockets",
			"UMG",
			"DeveloperSettings"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Slate", "SlateCore", "AssetRegistry"
		});
	}
}
