﻿#pragma once

#include "CoreMinimal.h"
#include "Camera/CameraComponent.h"
#include "PCCameraComponent.generated.h"

class AComputerComponent;
class UPCAssemblySystem;
class USpringArmComponent;

/**
 * Câmera orbital com zoom suavizado, modo inspeção e posicionamento do item segurado.
 * Filha de um USpringArmComponent. Tick permitido (§3), ligado só enquanto
 * há interpolação pendente ou item na mão.
 */
UCLASS(ClassGroup = (PC), meta = (BlueprintSpawnableComponent))
class PCSIMULATOR_API UPCCameraComponent : public UCameraComponent
{
	GENERATED_BODY()

public:
	UPCCameraComponent();

	void AddOrbitInput(const FVector2D& Input);
	void AddZoomInput(float Input);

	/** Entra em inspeção focando Target; chamado de novo, sai e restaura a posição. */
	void ToggleInspect(AActor* Target);
	bool IsInspecting() const { return bInspecting; }

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "0.0"))
	float OrbitSensitivity = 1.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "-89.0", ClampMax = "0.0"))
	float MinPitchDeg = -80.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "-89.0", ClampMax = "0.0"))
	float MaxPitchDeg = -5.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "-89.0", ClampMax = "0.0"))
	float DefaultPitchDeg = -30.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "0.0"))
	float ZoomStep = 10.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "1.0"))
	float MinArmLength = 30.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "1.0"))
	float MaxArmLength = 250.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "1.0"))
	float DefaultArmLength = 120.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "1.0"))
	float InspectArmLength = 35.f;

	UPROPERTY(EditDefaultsOnly, Category = "PC|Camera", meta = (ClampMin = "0.1"))
	float InterpSpeed = 12.f;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UFUNCTION()
	void HandleHeldChanged(AComputerComponent* Item);

	USpringArmComponent* GetArm() const;
	UPCAssemblySystem* GetAssembly() const;
	void WakeUp();

	float TargetArmLength = 120.f;
	FRotator TargetArmRotation = FRotator::ZeroRotator;
	TOptional<FVector> TargetOwnerLocation;
	FVector SavedOwnerLocation = FVector::ZeroVector;
	float SavedArmLength = 120.f;
	bool bInspecting = false;
};
