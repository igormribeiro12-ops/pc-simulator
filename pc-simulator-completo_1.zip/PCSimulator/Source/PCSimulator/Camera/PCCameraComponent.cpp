﻿#include "Camera/PCCameraComponent.h"

#include "Assembly/PCAssemblySystem.h"
#include "Components/ComputerComponent.h"
#include "Core/PCOrbitMath.h"
#include "Engine/World.h"
#include "GameFramework/SpringArmComponent.h"
#include "Utilities/PCSimulatorSettings.h"

UPCCameraComponent::UPCCameraComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	bUsePawnControlRotation = false;
}

void UPCCameraComponent::BeginPlay()
{
	Super::BeginPlay();

	TargetArmLength = FMath::Clamp(DefaultArmLength, MinArmLength, MaxArmLength);
	TargetArmRotation = FRotator(FMath::Clamp(DefaultPitchDeg, MinPitchDeg, MaxPitchDeg), 0.f, 0.f);
	if (USpringArmComponent* Arm = GetArm())
	{
		Arm->TargetArmLength = TargetArmLength;
		Arm->SetRelativeRotation(TargetArmRotation);
	}

	if (UPCAssemblySystem* Assembly = GetAssembly())
	{
		Assembly->OnPickedUp.AddUniqueDynamic(this, &ThisClass::HandleHeldChanged);
	}
}

void UPCCameraComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UPCAssemblySystem* Assembly = GetAssembly())
	{
		Assembly->OnPickedUp.RemoveDynamic(this, &ThisClass::HandleHeldChanged);
	}
	Super::EndPlay(EndPlayReason);
}

USpringArmComponent* UPCCameraComponent::GetArm() const
{
	return Cast<USpringArmComponent>(GetAttachParent());
}

UPCAssemblySystem* UPCCameraComponent::GetAssembly() const
{
	return GetWorld() ? GetWorld()->GetSubsystem<UPCAssemblySystem>() : nullptr;
}

void UPCCameraComponent::WakeUp()
{
	SetComponentTickEnabled(true);
}

void UPCCameraComponent::HandleHeldChanged(AComputerComponent* /*Item*/)
{
	WakeUp();
}

void UPCCameraComponent::AddOrbitInput(const FVector2D& Input)
{
	if (Input.IsNearlyZero())
	{
		return;
	}
	TargetArmRotation = PCOrbitMath::ApplyOrbit(TargetArmRotation,
		Input.X * OrbitSensitivity, Input.Y * OrbitSensitivity, MinPitchDeg, MaxPitchDeg);
	WakeUp();
}

void UPCCameraComponent::AddZoomInput(float Input)
{
	if (FMath::IsNearlyZero(Input))
	{
		return;
	}
	const float MinLength = bInspecting ? 10.f : MinArmLength;
	TargetArmLength = PCOrbitMath::ApplyZoom(TargetArmLength, -Input * ZoomStep, MinLength, MaxArmLength);
	WakeUp();
}

void UPCCameraComponent::ToggleInspect(AActor* Target)
{
	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return;
	}

	if (bInspecting)
	{
		bInspecting = false;
		TargetArmLength = SavedArmLength;
		TargetOwnerLocation = SavedOwnerLocation;
	}
	else if (Target)
	{
		bInspecting = true;
		SavedArmLength = TargetArmLength;
		SavedOwnerLocation = Owner->GetActorLocation();
		TargetOwnerLocation = Target->GetActorLocation();
		TargetArmLength = InspectArmLength;
	}
	WakeUp();
}

void UPCCameraComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	USpringArmComponent* Arm = GetArm();
	if (!Arm)
	{
		SetComponentTickEnabled(false);
		return;
	}

	Arm->TargetArmLength = FMath::FInterpTo(Arm->TargetArmLength, TargetArmLength, DeltaTime, InterpSpeed);
	Arm->SetRelativeRotation(FMath::RInterpTo(Arm->GetRelativeRotation(), TargetArmRotation, DeltaTime, InterpSpeed));

	if (TargetOwnerLocation.IsSet())
	{
		AActor* Owner = GetOwner();
		const FVector NewLocation = FMath::VInterpTo(Owner->GetActorLocation(), TargetOwnerLocation.GetValue(), DeltaTime, InterpSpeed);
		Owner->SetActorLocation(NewLocation);
		if (NewLocation.Equals(TargetOwnerLocation.GetValue(), 0.1))
		{
			TargetOwnerLocation.Reset();
		}
	}

	bool bHolding = false;
	if (UPCAssemblySystem* Assembly = GetAssembly(); Assembly && Assembly->GetHeldItem())
	{
		bHolding = true;
		Assembly->UpdateHeldLocation(GetComponentLocation() + GetForwardVector() * UPCSimulatorSettings::Get().HoldDistanceCm);
	}

	const bool bSettled = FMath::IsNearlyEqual(Arm->TargetArmLength, TargetArmLength, 0.1f)
		&& Arm->GetRelativeRotation().Equals(TargetArmRotation, 0.05)
		&& !TargetOwnerLocation.IsSet();

	if (bSettled && !bHolding)
	{
		SetComponentTickEnabled(false);
	}
}
