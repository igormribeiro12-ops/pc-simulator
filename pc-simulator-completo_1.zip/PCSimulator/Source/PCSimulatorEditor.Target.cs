// Target de editor. Inclui o módulo de testes (nunca presente no target Game/Shipping).
using UnrealBuildTool;

public class PCSimulatorEditorTarget : TargetRules
{
	public PCSimulatorEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
		ExtraModuleNames.AddRange(new string[] { "PCSimulator", "PCSimulatorTests" });
	}
}
