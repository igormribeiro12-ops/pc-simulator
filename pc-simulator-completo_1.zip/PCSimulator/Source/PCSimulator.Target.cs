// Target do jogo (Development / Shipping). Contém apenas o módulo de runtime.
using UnrealBuildTool;

public class PCSimulatorTarget : TargetRules
{
	public PCSimulatorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
		ExtraModuleNames.Add("PCSimulator");
	}
}
