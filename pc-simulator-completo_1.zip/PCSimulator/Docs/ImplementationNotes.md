# ImplementationNotes.md

Estado da implementação, desvios da especificação (com motivo) e o que depende de você no editor.

> **Importante:** nenhuma linha foi compilada. O código foi escrito e revisado sem acesso à Unreal Engine (ambiente Linux, sem UE 5.4). A primeira compilação no Visual Studio vai revelar erros; mande o log do compilador que eu corrijo.

## 1. Status por fase

| # | Fase | Código | Depende de você |
|---|---|---|---|
| 1 | Projeto e esqueleto | ✅ | Gerar o .sln, compilar, criar o mapa e os assets de input |
| 2 | Contratos e dados | ✅ `Utilities/`, `Data/`, `Contracts.md`, schema, `.ini` | Criar os 8 DataAssets (§3) |
| 3 | Catálogo | ✅ `Catalog/` | — |
| 4 | Parser JSON | ✅ `Build/PCBuildJsonParser`, `PCJsonUtils` | — |
| 5 | Compatibilidade | ✅ 7 regras + sistema | Criar `DA_CompatibilityRules_Default` com as 7 regras |
| 6 | Player, câmera, raycast | ✅ `Camera/`, `Interaction/`, Pawn | PostProcess de outline (Custom Stencil 1) |
| 7 | Componentes | ✅ base + 8 derivados | 8 BPs placeholder |
| 8 | Slots | ✅ | Posicionar os slots nos BPs (§4) |
| 9 | Montagem + progresso | ✅ | — |
| 10 | Rede + mock | ✅ C++; mock em Python | Rodar o mock (`pip install websockets`) |
| 11 | Receiver + spawner | ✅ + console `PC.LoadBuildFile` | Ator com tag `PCBuildOrigin` na bancada |
| 12 | Energia (FSM completa) | ✅ | — |
| 13 | HUD | ✅ C++ | `WBP_AssemblyHUD` e `BP_PCHUD` |
| 14 | Integração E2E | ✅ teste `PCSimulator.Integration.BuildToBoot` | **Gravar o playthrough** (DoD) |
| 15 | Modelos finais | — (só assets) | **Meshes reais** (1 por tipo) |
| 16 | Animações | ✅ interpolação + AnimNotify | Montages, só se usar Skeletal Mesh |
| 17 | Áudio | ✅ | **7 sons** + `DA_AudioSet_Default` |
| 18 | VFX/RGB | ✅ | Material `M_PC_Emissive` com parâmetro `EmissiveColor` |
| 19 | Testes | ✅ 9 specs | Rodar a suíte |
| 20 | Otimização | Instrumentação no código (tempos de parse e spawn no log) | **Sessão no Unreal Insights** |
| 21 | Build final | Configuração de empacotamento pronta | **Teste em máquina limpa** |

## 2. Desvios da especificação (todos reversíveis)

| Item | Especificado | Implementado | Motivo |
|---|---|---|---|
| Índice do catálogo | Asset Registry tags / "1 linha no catálogo" | `FPrimaryAssetId` do AssetManager; tipo verificado após a carga (`ComponentTypeMismatch`) | O ID primário já é o ComponentId. Evita depender da assinatura de `GetAssetRegistryTags`, que mudou na 5.4 |
| Detecção de proximidade do slot | `USphereComponent` + overlap | Distância geométrica em `CheckPhysicalFit` / `FindNearestPhysicalSlot` | Sem física nem canal extra, testável sem colisão e com o mesmo efeito |
| Orientação | Rotação completa | Só o yaw relativo ao slot; pitch/roll vêm do slot no encaixe | Encaixe assistido: o jogador escolhe a direção, o slot define a inclinação |
| Rotação do item | Snap de 15° no grid do mundo | Passos de 15° relativos ao yaw de spawn | Com a bancada girada num ângulo qualquer, o grid do mundo tornaria alguns slots impossíveis |
| Animação | `UPCInstallAnimInstance` | `UPCInstallAnimationComponent` (interpolação) + `UPCAnimNotify_InstallationCompleted` | Os componentes são Static Mesh; AnimInstance exige Skeletal Mesh |
| Testes funcionais | `AFunctionalTest` em `L_Tests` | Specs com mundo criado em código (`PCSimulator.Functional.*`) | Rodam headless, sem mapa como asset |
| Integração com rede | Teste automatizado contra o mock | E2E automatizado sem rede + procedimento manual com o mock (§5) | Um PIE com socket real dentro de automation é frágil |
| FSM → WaitingForBuild | Só de Error/ComputerRunning | De qualquer estado (`ResetSession`) | Permite reiniciar a sessão pelo console em qualquer ponto |
| Motivos das regras | String Table | `LOCTEXT` (localizável via Localization Dashboard) | Os motivos têm números formatados (watts, mm); os códigos de erro simples usam `ST_PlayerMessages` |
| `Save/` | Pasta prevista | Não criada | Nenhuma fase v1 exige salvar; seria classe sem uso |

## 3. Assets a criar no editor

**DataAssets** em `/Game/PC/Components/<Tipo>/`. Use os valores de `Architecture.md` §8.2 e confira cada um com a ficha do fabricante.

| Asset | Classe | ActorClass | Campos-chave |
|---|---|---|---|
| `DA_CPU_Ryzen5_5600` | PCCPUDataAsset | `BP_CPU` | Socket.CPU.AM4, 65 W |
| `DA_GPU_RX7600` | PCGPUDataAsset | `BP_GPU` | Socket.PCIe.x16, 165 W, recomendada 550 W, PowerConnectors = Socket.Power.PCIe8 |
| `DA_MB_B550M` | PCMotherboardDataAsset | `BP_Motherboard` | CpuSocket AM4, RamSocket DDR4, 2 slots, FormFactor.MicroATX, ~50 W |
| `DA_RAM_16GB_DDR4_3200` | PCRAMDataAsset | `BP_RAM` | Socket.RAM.DDR4, ModuleCount 2 |
| `DA_SSD_NVMe_1TB` | PCStorageDataAsset | `BP_SSD` | Socket.M2.NVMe |
| `DA_PSU_650W_80Plus` | PCPSUDataAsset | `BP_PSU` | 650 W, Connectors = ATX24 + EPS8 + PCIe8 |
| `DA_Case_MidTower_ATX` | PCCaseDataAsset | `BP_Case` | ATX/MicroATX/MiniITX, GPU máx. 330 mm |
| `DA_Fan_120mm` | PCFanDataAsset | `BP_Fan` | bHasRGB opcional |

Fixtures de teste negativo em `/Game/PC/Components/_Test/` (nunca empacotadas): `psu_300w`, `i5_13600k` etc.

**Demais assets:**

| Asset | Caminho | Nota |
|---|---|---|
| `DA_CompatibilityRules_Default` | `/Game/PC/Data` | `PCCompatibilityRuleSet`; adicione as 7 regras na lista Rules |
| `DA_AudioSet_Default` | `/Game/PC/Audio` | 7 sons; `ScrewedTypes` = Motherboard, PSU |
| `ST_PlayerMessages` | `/Game/PC/UI` | Uma linha por código de erro (§6 abaixo) |
| `WBP_AssemblyHUD` | `/Game/PC/UI` | Pai `PCAssemblyHUDWidget`; widgets **RequirementList** (VerticalBox), **ProgressBar**, **ProgressText**, **StateText**, **ErrorText**, mais uma mira central |
| `BP_PCHUD` | `/Game/PC/Core` | Pai `PCHUD`; `WidgetClass = WBP_AssemblyHUD`. No `BP_PCGameMode`: HUD Class = `BP_PCHUD` |
| `M_PP_Outline` | `/Game/PC/FX` | Pós-processo de contorno para Custom Stencil = 1, dentro de um PostProcessVolume unbound no mapa |
| `M_PC_Emissive` | `/Game/PC/FX` | Parâmetro vetorial `EmissiveColor` ligado ao Emissive |

## 4. Slots nos Blueprints

Adicione componentes **PCAssemblySlot** e preencha `SlotTag`, `AllowedTypes`, `Prerequisites`, `AllowedYawOffsets` e `SnapRadius`:

| BP | Slot | AllowedTypes | RequiredSocket | Prerequisites |
|---|---|---|---|---|
| BP_Case | Slot.Case.Motherboard | Component.Motherboard | — | — |
| BP_Case | Slot.PSU | Component.PSU | — | — |
| BP_Case | Slot.Case.Fan.1 | Component.Fan | — | — |
| BP_Motherboard | Slot.CPU | Component.CPU | (automático pelo DA) | — |
| BP_Motherboard | Slot.RAM.1 / Slot.RAM.2 | Component.RAM | (automático) | — |
| BP_Motherboard | Slot.M2.1 | Component.Storage | Socket.M2.NVMe | — |
| BP_Motherboard | Slot.PCIe.1 | Component.GPU | Socket.PCIe.x16 | Slot.Case.Motherboard |
| BP_Motherboard | Slot.Cable.ATX24 | Component.Cable | Socket.PSU.ATX24 | Slot.PSU |
| BP_Motherboard | Slot.Cable.EPS8 | Component.Cable | Socket.Power.EPS8 | Slot.PSU |
| BP_GPU | Slot.Cable.PCIe8 | Component.Cable | Socket.Power.PCIe8 | Slot.PSU |

`BP_Case` também precisa de uma mesh no componente **SidePanel**.

## 5. Teste manual com a rede (Fase 10/11/14)

1. `pip install -r Tools/MockServer/requirements.txt` (Python 3.10+).
2. `python Tools/MockServer/mock_server.py`.
3. Dê Play no `L_Sandbox`. O log deve mostrar: `Conectando…` → `Conexão pronta.` → `Build … aceita` → `Spawn de 8 atores em X ms`. O mock deve imprimir `<- build.ack`.
4. Cenários de erro (um de cada vez; reinicie o mock entre eles):

| Comando | Resultado esperado |
|---|---|
| `--build builds/unknown_id.json` | `build.error` com `BuildError.UnknownComponentId` |
| `--build builds/incompatible_psu.json` | `UnknownComponentId` (sem a fixture psu_300w) ou `IncompatibleBuild` (com ela) |
| `--build builds/future_schema.json` | `BuildError.SchemaVersionUnsupported` |
| `--scenario malformed` | `BuildError.MalformedJson` |
| `--scenario duplicate` | 1º `build.ack`; 2º `BuildError.InvalidState` (a build já está montando) |
| `--scenario oversize` | Cliente fecha com 1009 e reconecta com backoff |
| `--scenario silent` | Depois de cerca de 25 s: `NetworkError.Timeout` e reconexão |
| `--scenario no-hello` | Depois de 10 s: `NetworkError.Timeout` |
| Derrubar o mock | Reconexões em 1, 2, 4, 8, 16, 30, 30 s |

Sem rede, use no console: `PC.LoadBuildFile C:/caminho/reference.json`. Para recomeçar a sessão: `PCResetSession`.

## 6. Entradas de `ST_PlayerMessages` (sugestão)

| Chave | Texto |
|---|---|
| AssemblyError.SlotOccupied | Este encaixe já está ocupado. |
| AssemblyError.SlotMismatch | Esta peça não encaixa aqui. |
| AssemblyError.WrongOrientation | Gire a peça para a orientação correta (Q/E). |
| AssemblyError.OutOfRange | Aproxime a peça do encaixe. |
| AssemblyError.MissingPrerequisite | Falta uma etapa anterior. |
| AssemblyError.Incompatible | Peça incompatível com esta montagem. |
| BuildError.MalformedJson | A build recebida está corrompida. |
| BuildError.MissingField | A build recebida está incompleta. |
| BuildError.InvalidFieldValue | A build recebida tem dados inválidos. |
| BuildError.SchemaVersionUnsupported | Versão de build não suportada. Atualize o jogo. |
| BuildError.UnknownComponentTag | A build contém um tipo de peça desconhecido. |
| BuildError.DuplicateComponentTag | A build repete um tipo de peça. |
| BuildError.MissingRequiredComponent | A build não tem todas as peças obrigatórias. |
| BuildError.UnknownComponentId | A build contém uma peça fora do catálogo. |
| BuildError.ComponentTypeMismatch | Uma peça da build está no lugar errado. |
| BuildError.AssetNotFound | Não foi possível carregar uma peça. |
| BuildError.IncompatibleBuild | As peças desta build não são compatíveis. |
| BuildError.DuplicateBuild | Esta build já foi recebida. |
| BuildError.InvalidState | Termine ou reinicie a montagem atual primeiro. |
| NetworkError.Timeout | O servidor não respondeu. Reconectando… |
| NetworkError.Disconnected | Conexão perdida. Reconectando… |
| NetworkError.ProtocolViolation | Mensagem inválida do servidor. |

## 7. Checklists das fases que exigem ação sua

**Fase 15, modelos:** importar 1 mesh por tipo (pivô na base, escala em cm, colisão simples) e preencher `Mesh` no DA. Remover o cubo placeholder dos BPs. Reposicionar os slots. Rodar a suíte e regravar o E2E.

**Fase 20, otimização:**
1. `-trace=default,cpu,gpu,frame` e abrir no Unreal Insights.
2. Montar a build inteira. Critério: nenhum frame acima de 16 ms.
3. `stat game` durante a montagem.
4. Confirmar que os únicos ticks ativos são o do `UPCCameraComponent` (só com interpolação ou item na mão) e o da `UPCInstallAnimationComponent` (só durante o encaixe).
5. O log `Spawn de N atores em X ms` deve ficar abaixo de 200.

**Fase 21, build final:**
1. `RunUAT BuildCookRun … -clientconfig=Shipping` (ver README).
2. Copiar `Dist/` para uma máquina **sem** a UE instalada.
3. Rodar o instalador de pré-requisitos (`Engine/Extras/Redist/en-us/UEPrereqSetup_x64.exe`, empacotado por `IncludePrerequisites=True`).
4. Com o mock rodando, montar e ligar.
