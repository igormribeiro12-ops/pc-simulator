# Architecture.md: Simulador 3D de Montagem de PC

| Campo | Valor |
|---|---|
| Status | **IMPLEMENTADA (código das fases 1–14, 16–19)**: não compilada ainda; ver `ImplementationNotes.md` |
| Versão do documento | 0.2 · 2026-09-24. As 20 correções da auditoria estão aplicadas, as decisões D1–D14 assumidas no padrão recomendado e 8 erros da própria v0.1 foram corrigidos (§3.1) |
| Prompt de referência | `/Docs/PROMPT_MESTRE_v2.md` (versão corrigida do prompt original) |
| Engine | Unreal Engine **5.4.x** (fixar o hotfix exato no README ao criar o projeto; 5.4.4 é o último hotfix conhecido da linha) |
| Linguagem | C++20 (padrão do UBT desde a 5.3; `CppStandard` não precisa ser forçado) |
| Target | Win64, standalone, single-player |
| Toolchain | Visual Studio 2022 com o toolset MSVC indicado nas release notes da 5.4 |

---

## 0. Sumário executivo

- **Um módulo de runtime** (`PCSimulator`) em camadas por pasta, mais um **módulo de testes** só de editor (`PCSimulatorTests`). As camadas se comunicam por delegates e interfaces. Nenhuma camada inferior conhece uma superior.
- **Fluxo único:** WebSocket → envelope → parser → `FBuildConfiguration` → catálogo → carga assíncrona → spawn → montagem → compatibilidade → progresso → energia → `ComputerRunning`. O JSON nunca instancia um Actor.
- **Dados:** um `UPCComponentDataAsset` base com subclasses tipadas (CPU, GPU…) para dar às regras de compatibilidade os dados de que precisam (capacidade da PSU, form factor, comprimento da GPU, conectores).
- **A auditoria (§3) achou 20 inconsistências no prompt mestre, e todas foram corrigidas** neste documento e em `PROMPT_MESTRE_v2.md`. A revisão da v0.1 achou mais 8 erros próprios, também corrigidos (§3.1). **As decisões D1–D14 foram aplicadas no padrão recomendado** (§13). Qualquer uma pode ser revertida antes da Fase 1.

---

## 1. Não-objetivos v1 (vão para o README)

- Multiplayer, co-op e replicação.
- Editor de builds dentro do jogo.
- Modelos 3D finais antes da fase de modelos (placeholders obrigatórios até lá).
- VR, conquistas, loja, monetização.
- Física realista de encaixe (o encaixe é assistido por snap).
- **Adicionado:** cabos com física (spline/cable component). Em v1 os cabos são **conexões lógicas** (D10).
- **Adicionado:** builds com mais de uma unidade do mesmo tipo além de kits de RAM (ex.: 2 SSDs, 2 GPUs). Isso exige o `schemaVersion: 2` (D4).
- **Adicionado:** sincronização de relógio com o servidor. O `timestamp` do envelope é apenas informativo.

---

## 2. Princípios aplicados (resumo operacional)

| Princípio | Regra concreta verificável |
|---|---|
| Data-driven | Componente novo = 1 DataAsset + 1 mesh. Zero linhas de gameplay (teste `PCSimulator.Unit.Catalog.NewAssetDiscoveredWithoutCode`). |
| Event-driven | `Tick` desligado por padrão (`PrimaryActorTick.bCanEverTick = false`) em toda classe fora de `Camera/` e `Animation/`. Auditado por grep no CI. |
| Identidade | Tipos, sockets, slots, form factors e (D3) códigos de erro são `FGameplayTag`. Strings só existem na borda (JSON ↔ tag). |
| Carregamento | `TSoftObjectPtr`/`TSoftClassPtr` + `UAssetManager::LoadPrimaryAssets` / `FStreamableManager::RequestAsyncLoad`. **Nenhum `LoadSynchronous` em gameplay.** |
| Erros | Parse retorna `bool` + erro tipado. A rede nunca propaga exceção ou estado para o gameplay, só eventos tipados. |

---

## 3. Auditoria do prompt mestre (etapa VALIDAR)

Problemas encontrados antes de qualquer código. **Status: todas as correções estão APLICADAS** neste documento e em `PROMPT_MESTRE_v2.md`. Onde havia escolha de produto, o padrão recomendado de §13 foi aplicado e registrado.

| # | Problema | Impacto | Correção aplicada |
|---|---|---|---|
| A1 | `WebSockets` e `GameplayTags` são **módulos da engine**, não plugins. Listá-los em `Plugins` no `.uproject` gera o erro "plugin não encontrado" ao abrir o projeto. | Quebra a Fase 1 | O `.uproject` lista só o plugin real `EnhancedInput` (StateTree removido por D1). Os módulos entram via `Build.cs`. |
| A2 | `UDeveloperSettings` é obrigatório (§1), mas o módulo `DeveloperSettings` não está no `Build.cs`. | Erro de link | Adicionar `"DeveloperSettings"` às dependências públicas. |
| A3 | `StateTreeModule`/`GameplayStateTreeModule` são obrigatórios no `Build.cs`, mas a FSM de §10 é um `enum` controlado pelo GameMode. | Dependência morta, violando a regra suprema ("cada dependência é justificada") | D1: remover do v1 e reavaliar se a FSM crescer. |
| A4 | `ICompatibilityRule` é uma interface C++ pura (§6.4), mas §11 exige `TArray<TScriptInterface<ICompatibilityRule>>`. `TScriptInterface` exige `UINTERFACE`. | Não compila como descrito | D2: `UPCCompatibilityRule` vira um `UObject` abstrato `EditInlineNew`, instanciado dentro de um DataAsset de regras. |
| A5 | O exemplo "✅ Certo" de §11 usa `LoadSynchronous()` duas vezes, o que contradiz §3. | Hitch no spawn; viola a meta de 200 ms | O spawner usa carga assíncrona do bundle da build inteira antes de qualquer spawn (§5). |
| A6 | O schema `TMap<Tag, Id>` admite **1 item por tipo**, mas o gabinete tem `Slot.RAM.1` e `Slot.RAM.2`. | A build padrão não preenche os slots de RAM | D4: o ID de RAM referencia um **kit** (`ModuleCount = 2`), como no varejo. O schema v1 fica intacto. |
| A7 | A Fase 9 exige o teste "componente duplicado", mas `FJsonObject` **sobrescreve chaves duplicadas em silêncio** e não existe código de erro para esse caso. | Um teste impossível de passar | O parser detecta chaves duplicadas via `TJsonReader` (varredura de tokens). Novo código `BuildError.DuplicateComponentTag`. |
| A8 | `FName` é **case-insensitive**: `RX_7600 == rx_7600`. | Ambiguidade de IDs no contrato | Contrato: IDs devem casar `^[a-z0-9_]{1,64}$`. Fora do padrão → `BuildError.InvalidFieldValue`. |
| A9 | A **Fase 6** (Assembly) testa "socket errado", que depende da **Fase 7** (Compatibility). A **Fase 13** (E2E com boot) depende da **Fase 18** (Power) e da 17 (UI). | Os gates não podem ser aprovados na ordem dada | D7: reordenar (§10). |
| A10 | "Tick proibido", mas o highlight por raycast e o objeto segurado seguindo a mira exigem atualização contínua. | Contradição de regra | D8: a interação roda num timer de 30 Hz (sem Tick) e o objeto segurado é atualizado pelo `UPCCameraComponent` (exceção já permitida). |
| A11 | Não está definido o que acontece se chegar uma `build.deliver` **durante a montagem**. | Estado indefinido | D6: rejeitar com o novo `BuildError.InvalidState`. |
| A12 | As regras `UPSUWattageRule`, form factor e comprimento da GPU **não têm dados**: o DataAsset não tem capacidade da PSU, form factor nem medidas. | Regras não implementáveis | Subclasses tipadas de DataAsset (§8) e tags `FormFactor.*` e `Socket.Power.*` (§7). |
| A13 | O comando de testes `-ExecCmds="Automation RunTests PCSimulator;Quit"` tem uma corrida: `Quit` pode executar antes da fila de testes latentes terminar. | Falsos verdes no CI | `-ExecCmds="Automation RunTests PCSimulator" -TestExit="Automation Test Queue Empty" -unattended -nopause -NullRHI -ReportExportPath=...` (os funcionais podem exigir RHI; isso será validado na Fase 19). |
| A14 | Os testes funcionais exigem o módulo `FunctionalTesting` (editor/dev), que não deve ir para o runtime. | Poluição do módulo de jogo | Novo módulo `PCSimulatorTests` (Type `Editor`). As specs unitárias ficam sob `WITH_DEV_AUTOMATION_TESTS`. |
| A15 | A Fase 1 exige build Shipping, mas não lista `PCSimulator.Target.cs` nem `PCSimulatorEditor.Target.cs`. | A build Shipping não existe sem eles | Incluídos na Fase 1 (`BuildSettingsVersion.V5`, `EngineIncludeOrderVersion.Unreal5_4`). |
| A16 | Os códigos de erro são `FName` (§6.4), mas a regra é "identificar por GameplayTag, nunca string solta". | Inconsistência de princípio | D3: os códigos de erro viram tags `BuildError.*`, `AssemblyError.*` e `NetworkError.*`, o que dá consulta hierárquica (`MatchesTag(BuildError)`). No fio continuam strings idênticas. |
| A17 | §16 pede "FText localizável em DataTable". O mecanismo nativo de texto localizável por chave é a **String Table**. | Reinventar localização | String Table `ST_PlayerMessages` com chave = nome da tag de erro. |
| A18 | Os nomes de arquivo com prefixo (`UPCComponentDataAsset.h`, `AComputerComponent.h`) fogem da convenção UE (arquivo sem prefixo, classe com prefixo). | Atrito com ferramentas e revisão | D14: `PCComponentDataAsset.h` → `UPCComponentDataAsset`. |
| A19 | `GetPrimaryAssetId` usa só `ComponentId`, então IDs precisam ser **globalmente únicos** entre tipos, e o AssetManager precisa de configuração em `DefaultGame.ini`. | Colisão silenciosa de IDs | Unicidade global validada em teste. Entrada `PrimaryAssetTypesToScan` documentada (§8.3). |
| A20 | A Fase 1 pede `APCPlayerCharacter` com Move, mas a Fase 3 pede câmera **orbital** com modo inspeção. São modelos de controle diferentes. | Retrabalho no Pawn | D9: `APCPlayerPawn : APawn` orbital. `Move` = pan do pivô sobre a bancada. |

### 3.1 Erros da v0.1 deste documento (corrigidos na revisão)

| # | Erro na v0.1 | Correção |
|---|---|---|
| E1 | `UPROPERTY() TObjectPtr<const UPCComponentDataAsset>`: o UHT não aceita ponteiro-para-const como UPROPERTY de objeto. | `TObjectPtr<UPCComponentDataAsset>` na struct. A imutabilidade fica garantida por acesso `const` nas regras (`Evaluate(const FPCBuildContext&)`). |
| E2 | A verificação de `DuplicateBuild` estava listada como passo do **parser**, que é puro e sem estado. | Passou a ser um passo do **receiver** (histórico de `buildId` vive em `UPCBuildReceiver`). |
| E3 | A contagem de códigos de erro dizia "22 folhas". | São **23**: 14 `BuildError` (incluindo `None`), 6 `AssemblyError` (incluindo o novo `MissingPrerequisite`) e 3 `NetworkError`. |
| E4 | `UPCCameraComponent` tinha base ambígua ("SpringArm/SceneComponent + Camera"). | `UPCCameraComponent : UCameraComponent`, filho de um `USpringArmComponent` do Pawn. A órbita e o zoom alteram rotação e `TargetArmLength` do braço. |
| E5 | `UPCCPUDataAsset` tinha o campo `Socket` duplicando `RequiredSocket` da base (duas fontes da verdade). | Campo removido. A CPU usa `RequiredSocket`. |
| E6 | As fixtures de teste ficavam fora do diretório escaneado, então o catálogo não conseguia resolvê-las nos testes. | As fixtures foram para `/Game/PC/Components/_Test/` (escaneado) e entram em `DirectoriesToNeverCook`: existem no editor e somem do Shipping (§8.2, §8.3). |
| E7 | O `Build.cs` tinha StateTree "condicional" e o `.uproject` também. | D1 aplicada: StateTree removido de ambos. |
| E8 | `BuildError.None` como tag de sucesso não estava definido. | Sucesso = `FGameplayTag` vazia em C++. No fio, `"BuildError.None"` só aparece em logs e nunca é enviado em `build.error`. |

**Pontos adicionais de contrato preenchidos** (lacunas, não erros): `FBuildContext` não estava definido. Faltava o payload de `build.ack`/`build.error`, a semântica de ping/pong, o limite de tamanho de mensagem, a idempotência por `buildId` e a política para builds incompatíveis (D5).

---

## 4. Módulos, camadas e dependências

### 4.1 Diagrama de camadas

```mermaid
flowchart TB
    subgraph L0["L0 · Fundação (sem dependências internas)"]
        UT[Utilities<br/>PCLog, PCGameplayTags, PCSettings]
        DA[Data<br/>PCTypes, DataAssets]
    end
    subgraph L1["L1 · Domínio puro (testável sem World)"]
        CAT[Catalog<br/>UPCComponentCatalog]
        BLD[Build/Parser<br/>FPCBuildJsonParser]
        CMP[Compatibility<br/>UPCCompatibilitySystem + Rules]
        NET[Networking<br/>UPCNetworkManager, FPCWebSocketClient]
    end
    subgraph L2["L2 · Mundo / Gameplay"]
        RCV[Build/Receiver<br/>UPCBuildReceiver]
        SPW[Build/Spawner<br/>UPCBuildSpawner]
        COMP[Components<br/>AComputerComponent + 8]
        ASM[Assembly<br/>UPCAssemblySystem, SlotComponent, ProgressTracker]
        INT[Interaction<br/>UPCInteractionComponent]
        CAM[Camera<br/>UPCCameraComponent]
        PWR[Effects/Power<br/>UPCPowerSystem]
    end
    subgraph L3["L3 · Apresentação (só observa eventos)"]
        UI[UI]
        AUD[Audio<br/>UPCAudioDirector]
        FX[Effects/RGB]
        ANI[Animation]
    end
    subgraph ORQ["Orquestração"]
        GM[Core<br/>APCGameMode · FSM]
    end

    DA --> UT
    CAT --> DA
    BLD --> DA
    CMP --> DA
    NET --> UT
    RCV --> BLD
    RCV --> CAT
    RCV --> CMP
    RCV -. escuta delegate .-> NET
    SPW --> CAT
    SPW --> COMP
    ASM --> COMP
    ASM --> CMP
    INT --> ASM
    PWR -. escuta delegate .-> ASM
    GM -. escuta delegates .-> RCV
    GM -. escuta delegates .-> SPW
    GM -. escuta delegates .-> ASM
    GM -. escuta delegates .-> PWR
    UI -. observa .-> GM
    UI -. observa .-> ASM
    AUD -. observa .-> ASM
    AUD -. observa .-> PWR
    FX -. observa .-> PWR
    ANI -. notifica .-> ASM
```

**Regras de dependência (verificadas na revisão de cada PR):**

1. Seta cheia = `#include` permitido. Seta tracejada = apenas `AddDynamic`/`AddUObject` em delegate público. Nenhum include no sentido inverso.
2. **`Networking` não conhece `Build`.** Ele entrega o `payload` bruto (`TSharedRef<FJsonObject>`) com `type` e `requestId`. Assim a rede é testável com qualquer tipo de mensagem.
3. **L3 nunca chama L2 para mudar estado.** A UI dispara comandos apenas via `APCPlayerController` → input actions.
4. `Core/APCGameMode` é o **único** que muda `EPCGameState`.

### 4.2 Módulos UBT

| Módulo | Type | Por quê |
|---|---|---|
| `PCSimulator` | Runtime | Todo o jogo. Um módulo só evita overhead de API macros (`PCSIMULATOR_API`) entre camadas. O isolamento é por pasta e regra de include. |
| `PCSimulatorTests` | Editor | Specs, testes funcionais (`FunctionalTesting`) e o harness do servidor mock. Nunca entra no Shipping. |

`Build.cs` corrigido (em relação ao prompt: `+DeveloperSettings`, `−StateTreeModule`, `−GameplayStateTreeModule`):

```text
Public:  Core, CoreUObject, Engine, InputCore, EnhancedInput, GameplayTags,
         Json, JsonUtilities, WebSockets, UMG, DeveloperSettings
Private: Slate, SlateCore, AssetRegistry
```

`PCSimulatorTests.Build.cs`: `PCSimulator`, `Core`, `CoreUObject`, `Engine`, `GameplayTags`, `Json`, `FunctionalTesting`, `UnrealEd`.

`.uproject → Plugins`: **somente** `EnhancedInput` (`Enabled: true`). `WebSockets`, `GameplayTags` e `Json` são módulos da engine e entram só via `Build.cs`. Os módulos do projeto são `PCSimulator` (Runtime, LoadingPhase Default) e `PCSimulatorTests` (Editor, LoadingPhase Default).

### 4.3 Tempo de vida (onde cada sistema mora)

| Classe | Base | Lifetime | Justificativa |
|---|---|---|---|
| `UPCNetworkManager` | `UGameInstanceSubsystem` | Processo | A conexão sobrevive a troca de mapa (`L_Sandbox` ↔ `L_Tests`). |
| `UPCComponentCatalog` | `UGameInstanceSubsystem` | Processo | O índice do AssetManager é global. Construído uma vez. |
| `UPCBuildReceiver` | `UGameInstanceSubsystem` | Processo | Mantém o histórico de `buildId` (idempotência) e depende da rede. |
| `UPCCompatibilitySystem` | `UGameInstanceSubsystem` | Processo | Stateless. Lê o `RuleSet` das settings. Precisa estar disponível para o receiver (validação pré-spawn). |
| `UPCBuildSpawner` | `UWorldSubsystem` | Mundo | Cria atores no mundo. |
| `UPCAssemblySystem` | `UWorldSubsystem` | Mundo | Estado de pick/install por mundo. |
| `UPCAssemblyProgressTracker` | `UWorldSubsystem` | Mundo | Conta requisitos; emite `OnAllComponentsInstalled`. (Arquivo em `Assembly/`, não listado no prompt.) |
| `UPCPowerSystem` | `UWorldSubsystem` | Mundo | Assina o tracker em `OnWorldBeginPlay`. |
| `UPCAudioDirector` | `UWorldSubsystem` | Mundo | Observador puro. |
| `UPCInteractionComponent` | `UActorComponent` no Pawn | Pawn | Depende do viewpoint do jogador. |
| `UPCCameraComponent` | `UCameraComponent`, filho de um `USpringArmComponent` do Pawn | Pawn | Tick permitido: suaviza órbita e zoom e atualiza o objeto segurado. |
| `UPCAssemblySlotComponent` | `USceneComponent` | Ator dono | §6.5. |
| `UPCSimulatorSettings` | `UDeveloperSettings` (`Config=Game`) | CDO | URL do servidor, timeouts, `RuleSet`, headroom da PSU, tolerância de orientação. |

---

## 5. Fluxo canônico (com as correções)

```mermaid
sequenceDiagram
    autonumber
    participant S as Servidor
    participant N as UPCNetworkManager
    participant R as UPCBuildReceiver
    participant P as FPCBuildJsonParser
    participant C as UPCComponentCatalog
    participant X as UPCCompatibilitySystem
    participant G as APCGameMode (FSM)
    participant W as UPCBuildSpawner
    participant A as UPCAssemblySystem
    participant T as ProgressTracker
    participant E as UPCPowerSystem

    S->>N: build.deliver (envelope §6.1)
    N->>R: OnMessage(type, requestId, payload)
    R->>G: CanAcceptBuild()? (estado == WaitingForBuild)
    alt estado inválido
        R-->>N: build.error BuildError.InvalidState
    end
    R->>P: Parse(payload) → FBuildConfiguration | erro
    R->>C: ResolveAll(config) → TArray<FPCComponentRef> | UnknownComponentId/TypeMismatch
    R->>C: LoadAsync(refs) → DataAssets carregados
    R->>X: ValidateBuild(FBuildContext) → IncompatibleBuild? (D5)
    R-->>N: build.ack {buildId, status: "accepted"}
    R->>G: OnBuildAccepted → LoadingBuild
    G->>W: SpawnAll(refs) (classes já em memória, spawn em lote)
    W->>G: OnBuildSpawned → BuildReady
    Note over A: jogador pega o 1º item → AssemblyInProgress
    A->>X: ValidateInstall(context + candidato + slot)
    A->>T: OnComponentInstalled
    T->>G: OnAllRequirementsMet → AssemblyCompleted
    G->>E: jogador aperta Power → PowerSequence
    E->>G: OnBootCompleted → ComputerRunning
```

**Invariante:** o JSON só produz `FBuildConfiguration` (valores). Atores nascem apenas de `TSoftClassPtr` vindo de DataAsset resolvido pelo catálogo.

**`build.ack` só é enviado depois da validação completa.** O servidor recebe `ack` ou `error` para cada `requestId`, nunca os dois.

---

## 6. Contratos (§6 do prompt, preenchidos)

> Estes contratos migram literalmente para `/Docs/Contracts.md` na Fase 2. Os schemas JSON formais vão para `/Docs/Schemas/`.

### 6.1 Envelope WebSocket, protocolo v1

```json
{
  "type": "build.deliver",
  "version": 1,
  "requestId": "3f1c2a9e-8d4b-4c7a-9e21-5b6d0f7a1c33",
  "timestamp": 1790000000,
  "payload": { }
}
```

| Campo | Tipo | Regra |
|---|---|---|
| `type` | string | Um dos tipos da tabela abaixo. Desconhecido → `NetworkError.ProtocolViolation` (log `Warning`, mensagem descartada, conexão mantida). |
| `version` | int | Versão do **protocolo** (envelope). ≠ 1 → `ProtocolViolation`. É independente do `schemaVersion` da build. |
| `requestId` | string | UUID em formato canônico lowercase `8-4-4-4-12`. Respostas ecoam o `requestId` da requisição. |
| `timestamp` | int64 | Unix epoch **segundos** UTC. Informativo, nunca usado para lógica. |
| `payload` | object | Obrigatório (pode ser `{}`). |

Limites: mensagem > **64 KiB** → `ProtocolViolation` e fechamento com código 1009. Codificação UTF-8.

| `type` | Direção | `payload` |
|---|---|---|
| `connection.hello` | C→S após conectar | `{ "clientVersion": "0.1.0", "protocolVersion": 1, "supportedSchemaVersions": [1] }` |
| `connection.hello` | S→C resposta | `{ "serverVersion": "x.y.z", "sessionId": "uuid" }`. Só depois dele a conexão é `Ready` e o backoff zera. |
| `build.deliver` | S→C | Build (§6.2) |
| `build.ack` | C→S | `{ "buildId": "uuid", "status": "accepted" }` |
| `build.error` | C→S | `{ "buildId": "uuid\|null", "code": "BuildError.UnknownComponentId", "detail": "texto técnico, não localizado", "field": "components.Component.GPU" }` |
| `ping` | ambos | `{}`. O cliente envia a cada **15 s** de silêncio. |
| `pong` | ambos | `{}`, ecoando o `requestId` do ping. Sem pong em **10 s** → `NetworkError.Timeout` → fecha e reconecta. |

**Reconexão:** 1 s → 2 s → 4 s → 8 s → 16 s → 30 s → 30 s… (teto 30 s, sem jitter: cliente único). Zera após `connection.hello` do servidor.

**Mapeamento de estados de conexão:** `Disconnected → Connecting → Handshaking → Ready`. Queda em qualquer estado → `NetworkError.Disconnected` → `Connecting` (com backoff).

### 6.2 Schema da Build, `schemaVersion: 1`

```json
{
  "schemaVersion": 1,
  "buildId": "a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d",
  "components": {
    "Component.CPU":         "ryzen_5_5600",
    "Component.GPU":         "rx_7600",
    "Component.Motherboard": "b550m",
    "Component.RAM":         "16gb_ddr4_3200",
    "Component.Storage":     "ssd_nvme_1tb",
    "Component.PSU":         "psu_650w_80plus",
    "Component.Case":        "case_midtower_atx"
  }
}
```

**Ordem de validação (determinística; o primeiro erro vence e é o que vai no `build.error`):**

| # | Verificação | Erro |
|---|---|---|
| 1 | JSON sintaticamente válido | `BuildError.MalformedJson` |
| 2 | `schemaVersion` presente e inteiro | `BuildError.MissingField` / `InvalidFieldValue` |
| 3 | `schemaVersion == 1` (valores maiores = schema futuro) | `BuildError.SchemaVersionUnsupported` |
| 4 | `buildId` presente, UUID válido | `MissingField` / `InvalidFieldValue` |
| 5 | *(receiver, antes do catálogo)* `buildId` já aceito nesta sessão | `BuildError.DuplicateBuild` |
| 6 | `components` presente, objeto não vazio, ≤ 32 entradas | `MissingField` / `InvalidFieldValue` |
| 7 | Nenhuma chave repetida em `components` (varredura de tokens) | `BuildError.DuplicateComponentTag` |
| 8 | Cada chave é uma tag registrada e filha de `Component` | `BuildError.UnknownComponentTag` |
| 9 | Cada valor é uma string que casa `^[a-z0-9_]{1,64}$` | `BuildError.InvalidFieldValue` |
| 10 | Tipos obrigatórios v1 presentes: CPU, GPU, Motherboard, RAM, Storage, PSU, Case | `BuildError.MissingRequiredComponent` |
| 11 | *(receiver)* O ID existe no catálogo | `BuildError.UnknownComponentId` |
| 12 | *(receiver)* O `Type` do DataAsset == chave | `BuildError.ComponentTypeMismatch` |
| 13 | *(receiver)* A carga assíncrona do asset teve sucesso | `BuildError.AssetNotFound` |
| 14 | *(receiver)* A compatibilidade de build passa (D5) | `BuildError.IncompatibleBuild` |

Campos extras desconhecidos no nível raiz são **ignorados com `Verbose`** (compatibilidade futura). `Component.Fan` e `Component.Cable` são opcionais: se ausentes, valem os padrões do gabinete.

O schema formal fica em `/Docs/Schemas/build.v1.schema.json` (JSON Schema 2020-12) para o time do servidor. O jogo **não** usa biblioteca de JSON Schema (terceiros proibidos): o validador C++ espelha o schema, e os testes garantem a paridade.

### 6.3 Taxonomia de erros (códigos estáveis)

Os códigos marcados **(novo)** vêm da auditoria. Todos são GameplayTags se D3 for aprovada. A mensagem ao jogador vem da String Table `ST_PlayerMessages[<código>]`.

| Código | Origem | Quando | Visível ao jogador |
|---|---|---|---|
| `BuildError.None` | — | Sucesso (em C++ = `FGameplayTag` vazia; nunca é enviado no fio) | — |
| `BuildError.SchemaVersionUnsupported` | Parser | `schemaVersion` ≠ 1 | Sim |
| `BuildError.MalformedJson` | Parser | Sintaxe inválida | Sim (genérico) |
| `BuildError.MissingField` | Parser | Campo raiz ausente | Sim (genérico) |
| `BuildError.InvalidFieldValue` **(novo)** | Parser | Tipo ou formato errado | Sim (genérico) |
| `BuildError.UnknownComponentTag` | Parser | Chave não é `Component.*` registrada | Sim |
| `BuildError.DuplicateComponentTag` **(novo)** | Parser | Chave repetida | Sim (genérico) |
| `BuildError.MissingRequiredComponent` **(novo)** | Parser | Falta um tipo obrigatório | Sim |
| `BuildError.UnknownComponentId` | Catálogo | ID fora do catálogo | Sim |
| `BuildError.ComponentTypeMismatch` **(novo)** | Catálogo | ID existe, mas é de outro tipo | Sim |
| `BuildError.AssetNotFound` | Catálogo/carga | Soft pointer quebrado | Sim (genérico) |
| `BuildError.IncompatibleBuild` **(novo)** | Compatibilidade | A build viola uma regra (D5) | Sim, com o motivo da regra |
| `BuildError.DuplicateBuild` | Receiver | `buildId` repetido | Não (só log) |
| `BuildError.InvalidState` **(novo)** | Receiver | Build chegou fora de `WaitingForBuild` | Não (só log) |
| `AssemblyError.SlotOccupied` | Slot | O slot já tem componente | Sim |
| `AssemblyError.SlotMismatch` | Slot | Tipo ou socket incompatível com o slot | Sim |
| `AssemblyError.Incompatible` | Regras | Regra cruzada falhou na instalação | Sim, com o motivo |
| `AssemblyError.WrongOrientation` | Slot | Rotação fora da tolerância (padrão 5°) | Sim |
| `AssemblyError.OutOfRange` | Slot | O componente está a mais de `SnapRadius` do slot | Sim |
| `AssemblyError.MissingPrerequisite` **(novo)** | Slot | Ex.: GPU antes da placa-mãe estar no gabinete, fechar o gabinete sem cabos | Sim |
| `NetworkError.Timeout` | Rede | Sem pong/hello no prazo | Indicador de conexão |
| `NetworkError.Disconnected` | Rede | Socket caiu | Indicador de conexão |
| `NetworkError.ProtocolViolation` | Rede | Envelope inválido ou muito grande | Não (só log) |

**Divisão de responsabilidade (sem duplicar a fonte da verdade):**
- **Slot** = verificação física e local (tipo, socket, ocupação, orientação, alcance, pré-requisito) → `AssemblyError.*` exceto `Incompatible`.
- **Regras** = relação entre componentes (TDP/watts, form factor, geração de RAM, comprimento da GPU) → `AssemblyError.Incompatible` na instalação, `BuildError.IncompatibleBuild` na entrega. As mesmas regras rodam nos dois portões.

### 6.4 Interfaces e tipos de contrato C++ (assinaturas, não implementação)

```cpp
// Build/IPCBuildReceiver.h — interface nativa pura (sem UINTERFACE): usada só para
// injetar dublês nos testes do GameMode; não precisa de reflexão.
class IPCBuildReceiver
{
public:
    virtual void OnBuildReceived(const FBuildConfiguration& Build) = 0;
    virtual void OnBuildRejected(FGameplayTag ErrorCode, const FString& Detail) = 0; // D3
    virtual ~IPCBuildReceiver() = default;
};

// Compatibility/PCBuildContext.h
USTRUCT()
struct FPCBuildContext
{
    GENERATED_BODY()
    // Componentes considerados (instalados + candidato), já carregados.
    // Ponteiros não-const: o UHT não aceita TObjectPtr<const T> em UPROPERTY.
    // A imutabilidade vem do acesso const em UPCCompatibilityRule::Evaluate.
    UPROPERTY() TMap<FGameplayTag, TObjectPtr<UPCComponentDataAsset>> Components;
    // Preenchidos apenas na validação de instalação.
    UPROPERTY() TObjectPtr<UPCComponentDataAsset> Candidate = nullptr;
    UPROPERTY() FGameplayTag TargetSlot;
};

// Compatibility/PCCompatibilityRule.h — D2: UObject abstrato em vez de UINTERFACE.
UCLASS(Abstract, EditInlineNew, DefaultToInstanced, CollapseCategories)
class UPCCompatibilityRule : public UObject
{
    GENERATED_BODY()
public:
    // true = compatível OU regra não aplicável (componentes relevantes ausentes).
    virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
        PURE_VIRTUAL(UPCCompatibilityRule::Evaluate, return true;);
};

// Compatibility/PCCompatibilityRuleSet.h
UCLASS()
class UPCCompatibilityRuleSet : public UPrimaryDataAsset
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, Instanced) TArray<TObjectPtr<UPCCompatibilityRule>> Rules;
};
```

`FCompatibilityResult::ErrorCode` passa de `FName` para `FGameplayTag` (D3). Regras v1: `UPCCPUSocketRule`, `UPCRAMGenerationRule`, `UPCGPUSlotRule`, `UPCPSUWattageRule` e as novas `UPCFormFactorRule` e `UPCGPULengthRule`. **Adicionar uma regra** = uma subclasse nova + uma entrada no RuleSet. `UPCCompatibilitySystem` não muda (há teste para isso).

### 6.5 Slot

`UPCAssemblySlotComponent : USceneComponent`, anexado ao gabinete ou à placa-mãe. Não é `UObject` solto nem `AActor`.

| Propriedade | Tipo | Nota |
|---|---|---|
| `SlotTag` | `FGameplayTag` (`Slot.*`) | Identidade. |
| `AllowedTypes` | `FGameplayTagContainer` (`Component.*`) | |
| `RequiredSocket` | `FGameplayTag` (`Socket.*`) | **Preenchido em runtime a partir do DataAsset do dono** (ex.: o slot CPU herda `CpuSocket` da placa-mãe). Um BP de placa serve AM4, AM5 e LGA1700. Inválido = sem restrição de socket. |
| `Prerequisites` | `FGameplayTagContainer` (`Slot.*`) | Slots que precisam estar ocupados antes. |
| `SnapRadius` | `float` (cm) | Padrão 8 cm. |
| `AllowedYawOffsets` | `TArray<float>` | Orientações válidas (ex.: RAM = {0}, ventoinha = {0, 180}). |
| `IsOccupied()` / `GetOccupant()` | | O ocupante é `TWeakObjectPtr<AComputerComponent>`. |

A detecção de proximidade usa um `USphereComponent` filho com canal próprio. Não usa Tick: `OnComponentBeginOverlap/EndOverlap`.

### 6.6 Catálogo de eventos (delegates públicos)

| Emissor | Delegate | Assinatura |
|---|---|---|
| NetworkManager | `OnConnectionStateChanged` | `(EPCConnectionState Old, EPCConnectionState New)` |
| NetworkManager | `OnMessageReceived` | `(FName Type, const FString& RequestId, TSharedRef<FJsonObject> Payload)`. Delegate nativo `DECLARE_MULTICAST_DELEGATE_ThreeParams`, porque `TSharedRef<FJsonObject>` não é tipo de reflexão. **Exceção justificada ao "dynamic"**. |
| NetworkManager | `OnNetworkError` | `(FGameplayTag Code, const FString& Detail)` |
| BuildReceiver | `OnBuildAccepted` / `OnBuildRejected` | `(const FBuildConfiguration&)` / `(FGameplayTag, const FString&)` |
| BuildSpawner | `OnBuildSpawned` | `(const TArray<AComputerComponent*>&)` |
| AssemblySystem | `OnPickedUp`, `OnDropped`, `OnInstalled`, `OnRemoved` | `(AComputerComponent*, UPCAssemblySlotComponent*)` |
| AssemblySystem | `OnInstallFailed` | `(AComputerComponent*, FGameplayTag Code, FText Reason)` |
| ProgressTracker | `OnProgressChanged` | `(int32 Done, int32 Total)` |
| ProgressTracker | `OnAllRequirementsMet` | `()` |
| PowerSystem | `OnPowerSequenceStarted`, `OnBootCompleted`, `OnPowerFailed` | `()` / `()` / `(FGameplayTag)` |
| GameMode | `OnGameStateChanged` | `(EPCGameState Old, EPCGameState New)` |
| AnimNotify | `OnInstallationAnimCompleted` | `(AComputerComponent*)` |

---

## 7. GameplayTags: lista canônica

**Fonte da verdade:** `Config/DefaultGameplayTags.ini`. O C++ declara (`UE_DECLARE_GAMEPLAY_TAG_EXTERN` / `UE_DEFINE_GAMEPLAY_TAG`) apenas as tags que o código referencia. O teste `PCSimulator.Unit.Tags.NativeTagsExistInIni` falha se o C++ definir uma tag ausente do `.ini`.

| Tag | Categoria | Uso | Origem |
|---|---|---|---|
| `Component.CPU` | Tipo | Chave JSON, `AllowedTypes` | Prompt |
| `Component.GPU` | Tipo | | Prompt |
| `Component.Motherboard` | Tipo | | Prompt |
| `Component.RAM` | Tipo | | Prompt |
| `Component.Storage` | Tipo | | Prompt |
| `Component.PSU` | Tipo | | Prompt |
| `Component.Case` | Tipo | | Prompt |
| `Component.Fan` | Tipo | Opcional no JSON | Prompt |
| `Component.Cable` | Tipo | Conexões lógicas (D10) | Prompt |
| `Socket.CPU.AM4` / `AM5` / `LGA1700` | Socket | CPU ↔ placa | Prompt |
| `Socket.RAM.DDR4` / `DDR5` | Socket | RAM ↔ placa | Prompt |
| `Socket.PCIe.x16` | Socket | GPU ↔ placa | Prompt |
| `Socket.M2.NVMe` | Socket | SSD ↔ placa | Prompt |
| `Socket.PSU.ATX24` | Socket | Conector 24 pinos da placa (cabo) | Prompt |
| `Socket.Power.EPS8` | Socket | Energia da CPU (cabo) | **Novo** |
| `Socket.Power.PCIe8` | Socket | Energia da GPU (cabo) | **Novo** |
| `Slot.CPU` | Slot | Na placa | Prompt |
| `Slot.RAM.1` / `Slot.RAM.2` | Slot | Na placa | Prompt |
| `Slot.PCIe.1` | Slot | Na placa | Prompt |
| `Slot.M2.1` | Slot | Na placa | Prompt |
| `Slot.PSU` | Slot | No gabinete | Prompt |
| `Slot.Case.Motherboard` | Slot | No gabinete | Prompt |
| `Slot.Case.Fan.1` | Slot | No gabinete | **Novo** |
| `Slot.Case.SidePanel` | Slot | "Gabinete fechado" | **Novo** |
| `Slot.Cable.ATX24` / `Slot.Cable.EPS8` / `Slot.Cable.PCIe8` | Slot | Pontos de conexão (D10) | **Novo** |
| `FormFactor.ATX` / `FormFactor.MicroATX` / `FormFactor.MiniITX` | Form factor | Placa ↔ gabinete | **Novo** |
| `BuildError.*`, `AssemblyError.*`, `NetworkError.*` | Erro | §6.3 (23 folhas) | **Novo** (D3) |

---

## 8. Modelo de dados e DataAssets

### 8.1 Hierarquia

```text
UPrimaryDataAsset
└── UPCComponentDataAsset          (campos do §8 do prompt: ComponentId, Type, DisplayName,
    │                               RequiredSocket, ActorClass, Mesh, PowerDrawWatts, RecommendedPsuWatts)
    ├── UPCCPUDataAsset            TdpWatts, Cores, Threads   (socket = RequiredSocket da base)
    ├── UPCGPUDataAsset            LengthMm, PowerConnectors (FGameplayTagContainer Socket.Power.*)
    ├── UPCMotherboardDataAsset    CpuSocket, RamSocket, RamSlotCount, FormFactor, PcieSlots, M2Slots
    ├── UPCRAMDataAsset            ModuleCount (kit), CapacityPerModuleGB, SpeedMTs   [D4]
    ├── UPCStorageDataAsset        CapacityGB
    ├── UPCPSUDataAsset            CapacityWatts, Efficiency (FText), Connectors
    ├── UPCCaseDataAsset           SupportedFormFactors, MaxGpuLengthMm, FanSlots
    └── UPCFanDataAsset            SizeMm, bRGB, RGB profile (Fase de VFX)
```

`GetPrimaryAssetId()` → `FPrimaryAssetId("PCComponent", ComponentId)` em todas as subclasses (um tipo primário). A classe base é `Abstract` para impedir asset sem tipo. O `ComponentId` vazio é pego pelo `IsDataValid` (UE 5.4: `EDataValidationResult IsDataValid(FDataValidationContext&) const`), que também valida o formato do ID e a coerência de `Type` com a subclasse.

O catálogo indexa **sem carregar assets**: `GetAssetRegistryTags` publica `PCType` e `PCComponentId` no Asset Registry. 1.000+ entradas custam só metadados. Na 5.4 a sobrecarga nova recebe `FAssetRegistryTagsContext`; confirmar a assinatura exata na Fase 2.

### 8.2 DataAssets a criar (catálogo v1 = a build de referência)

Pasta: `/Game/PC/Components/<Tipo>/`. Todos com `ActorClass` e `Mesh` = **`// [ASSET PENDENTE]`** até a fase de modelos. Até lá usam placeholders `BP_<Tipo>_Placeholder` com `/Engine/BasicShapes/Cube` escalado.

| Asset | ComponentId | Classe | Dados-chave (valores de referência; conferir com a ficha do fabricante na Fase 2) |
|---|---|---|---|
| `DA_CPU_Ryzen5_5600` | `ryzen_5_5600` | CPU | AM4 · TDP 65 W · 6C/12T |
| `DA_GPU_RX7600` | `rx_7600` | GPU | PCIe x16 · ~165 W · 1× PCIe 8-pin · PSU recomendada 550 W · comprimento conforme o modelo placeholder |
| `DA_MB_B550M` | `b550m` | Motherboard | AM4 · DDR4 · Micro-ATX · 2 slots RAM (v1) · 1 PCIe x16 · 1 M.2 |
| `DA_RAM_16GB_DDR4_3200` | `16gb_ddr4_3200` | RAM | DDR4 · kit 2×8 GB · 3200 MT/s |
| `DA_SSD_NVMe_1TB` | `ssd_nvme_1tb` | Storage | M.2 NVMe · 1 TB |
| `DA_PSU_650W_80Plus` | `psu_650w_80plus` | PSU | 650 W · 24p + EPS8 + PCIe8 |
| `DA_Case_MidTower_ATX` | `case_midtower_atx` | Case | ATX/mATX/ITX · GPU máx. conforme o placeholder · 1 slot de fã |
| `DA_Fan_120mm` | `fan_120mm` | Fan | 120 mm · padrão do gabinete |

**Fixtures de teste negativo** (em `/Game/PC/Components/_Test/`: escaneadas pelo AssetManager no editor e excluídas do cook por `DirectoriesToNeverCook`, então não existem no Shipping):
`DA_CPU_i5_13600K` (LGA1700), `DA_RAM_32GB_DDR5_6000` (DDR5), `DA_PSU_300W` (subdimensionada), `DA_GPU_Long_400mm` (não cabe), `DA_MB_ATX_Z790` (form factor/socket divergentes).

Assets não-componentes: `DA_CompatibilityRules_Default` (`UPCCompatibilityRuleSet`), `ST_PlayerMessages` (String Table), `IMC_Default` + `IA_Move`, `IA_Look`, `IA_Interact`, `IA_Rotate`, `IA_Drop`, `IA_Zoom`, `IA_Inspect`, `IA_Power` (os três últimos são **novos**, exigidos pelas Fases 3 e 18).

### 8.3 Configuração do AssetManager (`DefaultGame.ini`)

```ini
[/Script/Engine.AssetManagerSettings]
+PrimaryAssetTypesToScan=(PrimaryAssetType="PCComponent",AssetBaseClass="/Script/PCSimulator.PCComponentDataAsset",bHasBlueprintClasses=False,bIsEditorOnly=False,Directories=((Path="/Game/PC/Components")),Rules=(Priority=-1,ChunkId=-1,bApplyRecursively=True,CookRule=AlwaysCook))
```

```ini
[/Script/UnrealEd.ProjectPackagingSettings]
+DirectoriesToNeverCook=(Path="/Game/PC/Components/_Test")
```

`CookRule=AlwaysCook` garante que assets referenciados só por ID (via JSON) entrem no Shipping. Sem isso, a build final perde assets (risco R3). `DirectoriesToNeverCook` tem precedência e mantém as fixtures fora do pacote. O teste `PCSimulator.Unit.Catalog.TestFixturesNotInProductionIds` confirma que nenhum ID de fixture colide com um de produção.

---

## 9. Máquina de estados (`EPCGameState`)

Mantida exatamente como §10 do prompt. Transições **explícitas** numa tabela `const` no GameMode. Transição fora da tabela → `ensureMsgf` + log `Error` + ida para `Error`.

| De | Para | Gatilho (delegate) |
|---|---|---|
| WaitingForBuild | LoadingBuild | `BuildReceiver.OnBuildAccepted` |
| LoadingBuild | BuildReady | `BuildSpawner.OnBuildSpawned` |
| LoadingBuild | Error | `BuildSpawner.OnSpawnFailed` |
| BuildReady | AssemblyInProgress | `AssemblySystem.OnPickedUp` (primeiro) |
| AssemblyInProgress | AssemblyCompleted | `ProgressTracker.OnAllRequirementsMet` |
| AssemblyCompleted | AssemblyInProgress | `AssemblySystem.OnRemoved` (jogador desfez algo) |
| AssemblyCompleted | PowerSequence | `IA_Power` → `PowerSystem.OnPowerSequenceStarted` |
| PowerSequence | ComputerRunning | `PowerSystem.OnBootCompleted` |
| PowerSequence | AssemblyCompleted | `PowerSystem.OnPowerFailed` |
| qualquer | Error | Falha irrecuperável |
| qualquer | WaitingForBuild | `ResetSession()` (limpa atores, mantém a conexão; console `PCResetSession`) |

Com D6 aprovada, `build.deliver` só é aceita em `WaitingForBuild`.

---

## 10. Ordem de implementação (reordenada: D7)

Princípio da reordenação: **domínio puro primeiro** (testável sem World e sem assets), depois o mundo, depois a integração com placeholders, e **só então** a apresentação. Todo gate depende apenas de fases anteriores.

| Nova | Original | Fase | Depende de | Arquivos (código/config) | Assets UE |
|---|---|---|---|---|---|
| 1 | 1 | Projeto e esqueleto (+ `Target.cs` ×2, módulo de testes vazio) | — | ~16 | ~10 (mapa, IMC, IAs) |
| 2 | 2 | Contratos e dados base (tags, log, settings, DataAssets tipados, AssetManager) | 1 | ~20 + Docs | 8 DAs + 5 fixtures |
| 3 | 8 | Component Catalog | 2 | 2 + 1 spec | — |
| 4 | 9 | JSON parser (+ schema formal) | 2 | 2 + 1 spec + 1 schema | — |
| 5 | 7 | Compatibility System + 6 regras | 2 | 2 + 12 + 1 spec | 1 RuleSet |
| 6 | 3 | Player, câmera, raycast (timer 30 Hz) | 1 | ~6 | canal de trace |
| 7 | 4 | Componentes (base + 8) | 2, 6 | 18 + 1 spec | 8 BPs placeholder |
| 8 | 5 | Slots | 7 | 2 + teste funcional | — |
| 9 | 6 | Assembly System + ProgressTracker | 5, 8 | 4 + 1 spec + funcional | `L_Tests` |
| 10 | 10 | Networking + servidor mock | 1 | 4 + mock (`Tools/MockServer`) | — |
| 11 | 11 | Build Receiver + Spawner | 3, 4, 5, 7, 10 | 4 + integração | — |
| 12 | 18 | Power System (FSM completa) | 9 | 2 + spec FSM | — |
| 13 | 17 | UI HUD (mínima funcional) | 9, 12 | 2 C++ | 1 WBP |
| 14 | 13 | **Integração E2E com placeholders** (gravação) | 11, 12, 13 | teste de integração | — |
| 15 | 12 | Modelos finais (+ re-gravação E2E) | 14 | 0 | 8+ meshes |
| 16 | 14 | Animações + AnimNotifies | 15 | ~6 | montages CPU/GPU |
| 17 | 15 | Áudio (7 sons) | 9, 12 | 2 | 7 SoundCues/MetaSounds `[ASSET PENDENTE]` |
| 18 | 16 | VFX e RGB | 12 | 2 | materiais emissivos |
| 19 | 19 | Suíte completa via linha de comando (A13) | todas | script CI | — |
| 20 | 20 | Otimização (Insights) | 19 | — | — |
| 21 | 21 | Build final Shipping + README | 20 | — | — |

**Estimativa total:** cerca de 115 arquivos de código/config e cerca de 60 assets.

---

## 11. Política de testes (nomes exatos por fase)

| Suite | Casos mínimos |
|---|---|
| `PCSimulator.Unit.Tags.*` | `NativeTagsExistInIni` |
| `PCSimulator.Unit.Catalog.*` | `ResolvesKnownId`, `UnknownIdFails`, `TypeMismatchFails`, `IdsAreGloballyUnique`, `NewAssetDiscoveredWithoutCode`, `DoesNotLoadAssetsOnIndex` |
| `PCSimulator.Unit.Json.*` | `Valid`, `Malformed`, `FutureSchema`, `MissingField`, `UnknownTag`, `UnknownId`*, `DuplicateComponentTag`, `InvalidIdFormat`, `MissingRequiredComponent`, `ExtraRootFieldIgnored`, `PerfUnder50ms` (* no receiver) |
| `PCSimulator.Unit.Compatibility.*` | 8+: `ValidBuildPasses`, `CpuSocketMismatch`, `RamGenerationMismatch`, `GpuNoPcieSlot`, `PsuUnderpowered`, `PsuBelowGpuRecommendation`, `FormFactorUnsupported`, `GpuTooLong`, `RuleNotApplicableWhenMissing`, `NewRuleWithoutSystemChange` |
| `PCSimulator.Unit.FSM.*` | Toda transição válida; toda transição inválida vai para `Error` |
| `PCSimulator.Unit.Network.*` | `BackoffSequence`, `EnvelopeValidation`, `OversizeRejected` (lógica pura, sem socket) |
| `PCSimulator.Functional.Assembly.*` | `InstallValid`, `WrongType`, `WrongSocket`, `WrongOrientation`, `SlotOccupied`, `OutOfRange`, `MissingPrerequisite` |
| `PCSimulator.Integration.*` | `ConnectAndHello`, `ReconnectAfterDrop`, `HeartbeatTimeout`, `BuildToSpawn`, `BuildToBoot` (contra o mock) |

Regression-first: todo bug corrigido ganha um caso nomeado `...Regression.<IssueId>`.

---

## 12. Riscos e mitigações

| # | Risco | Prob. | Impacto | Mitigação |
|---|---|---|---|---|
| R1 | Callbacks do `IWebSocket` fora da game thread ou após a destruição do subsystem | Média | Crash | Captura só `TWeakObjectPtr`. Marshal defensivo para a game thread. Teste `ReconnectAfterDrop` com teardown. |
| R2 | Carga assíncrona gera hitch no spawn | Média | Meta de 200 ms | Pré-carregar o bundle completo antes do spawn. Medir "spawn" separado de "IO" (a meta de 200 ms vale para o spawn com classes já carregadas). |
| R3 | Assets referenciados só por ID ficam fora do cook | Alta sem config | Shipping quebrado | `CookRule=AlwaysCook` (§8.3) e o teste de Shipping na Fase 1 com 1 DA. |
| R4 | UX do snap frustrante (15° + tolerância) | Média | Produto | `SnapRadius` e tolerância em `UPCSimulatorSettings`, ajustáveis sem recompilar. Playtest na Fase 9. |
| R5 | Escopo de 21 fases | Alta | Prazo | Gates estritos e não-objetivos explícitos. O E2E com placeholders (fase 14) cria cedo um produto demonstrável. |
| R6 | Divergência entre o schema do servidor e o validador C++ | Média | Builds rejeitadas | O schema formal versionado é a fonte compartilhada. O mock server valida contra ele. |
| R7 | UE 5.4 não é a versão mais recente da engine | Certa | Futuro | Versão fixada no README. Migração para versões novas é um projeto separado, fora do v1. |
| R8 | `wss://` e certificados no Shipping | Baixa | Conexão | URL e esquema em settings. O teste de integração com `wss` local fica na Fase 10. |
| R9 | Máquina limpa sem runtime VC++/DirectX | Média | Fase 21 | Empacotar com o instalador de pré-requisitos da UE habilitado. |

---

## 13. Decisões (APLICADAS no padrão recomendado; reversíveis antes da Fase 1)

| ID | Decisão | Opções | Aplicado e motivo |
|---|---|---|---|
| D1 | StateTree no v1 | usar / remover | **Remover.** A FSM de 8 estados é um enum com tabela. Não há dependência sem uso. |
| D2 | Forma das regras | `UINTERFACE` / `UObject` abstrato Instanced | **UObject Instanced em RuleSet DataAsset.** Configurável no editor, sem boilerplate de interface e compatível com §11. |
| D3 | Tipo dos códigos de erro | `FName` / `FGameplayTag` | **GameplayTag.** Coerente com a regra "nunca string solta", permite hierarquia e o fio não muda. |
| D4 | Várias unidades do mesmo tipo | Kit via `ModuleCount` / schema v2 com array | **Kit.** Preserva o schema v1 e espelha o varejo. Array fica para o v2. |
| D5 | Build incompatível recebida | rejeitar na entrega / aceitar e o jogador descobre | **Rejeitar** (`IncompatibleBuild`). É determinístico, e o servidor é a fonte de builds válidas. Mudar para "modo desafio" depois é só uma flag. |
| D6 | Build chegando durante a montagem | rejeitar / substituir | **Rejeitar** (`InvalidState`). O jogador nunca perde progresso sem pedir. |
| D7 | Ordem das fases | original / reordenada (§10) | **Reordenada.** Sem ela os gates 6 e 13 não podem ser aprovados. |
| D8 | Atualização da interação | timer 30 Hz / exceção de Tick | **Timer 30 Hz** para o trace. O objeto segurado segue a câmera (Tick de câmera já permitido). |
| D9 | Pawn | `APawn` orbital / `ACharacter` FPS | **APawn orbital.** O modo inspeção e a órbita são o núcleo; locomoção é escopo extra. |
| D10 | Cabos | conexão lógica por slots / física com spline | **Lógica.** A física de encaixe já é não-objetivo. |
| D11 | Testes | módulo `PCSimulatorTests` (Editor) / dentro do runtime | **Módulo separado.** |
| D12 | Servidor mock | Python 3 + `websockets` / Node + `ws` | **Python** em `Tools/MockServer`. É tooling de dev, não entra no jogo, e fica justificado por escrito. |
| D13 | Índice do catálogo | AssetManager + registry tags / DataTable extra | **AssetManager como fonte única.** "Uma linha no catálogo" passa a ser zero linhas. |
| D14 | Nomes de arquivo | com prefixo (prompt) / convenção UE | **Convenção UE** (`PCComponentDataAsset.h`). |

---

## 14. Gate de aprovação

A Fase 1 começa com a aprovação desta versão 0.2 (correções e decisões D1–D14 já aplicadas). Para reverter uma decisão, basta citar o ID. Até a aprovação, nenhum código C++ é escrito.
