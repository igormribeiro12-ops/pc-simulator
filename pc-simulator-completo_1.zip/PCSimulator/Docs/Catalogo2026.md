# Catálogo de peças 2026

**95 peças** · retrato de **2026-09-24** · preços em dólar (EUA), só referência.

> **Mercado em 2026:** a demanda de IA encareceu memória e armazenamento. Um kit de 32 GB DDR5-6000 saiu de ~US$ 80 (meados de 2025) para mais de US$ 430, e o Samsung 9100 Pro 2TB foi de ~US$ 320 para ~US$ 680. Placas de vídeo estão bem acima do preço oficial (MSRP): a RTX 5070 Ti tem MSRP de US$ 750, mas sai por ~US$ 1.099.

**Ainda não lançados:** AMD Zen 6 / Ryzen 10000 (previsto para 2027, AM5) e Intel Nova Lake (fim de 2026, soquete LGA1954). Única GPU "nova" de 2026: RX 9070 GRE, que chegou ao mundo todo depois da Computex.

## Processadores (18)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| AMD Ryzen 7 9800X3D | `ryzen_7_9800x3d` | AM5 · 8N/16T · 120 W | US$ 419.99 |
| AMD Ryzen 7 9700X | `ryzen_7_9700x` | AM5 · 8N/16T · 65 W | US$ 249.99 |
| AMD Ryzen 9 9950X3D2 | `ryzen_9_9950x3d2` | AM5 · 16N/32T · 200 W | US$ 899.00 |
| AMD Ryzen 5 7600X3D | `ryzen_5_7600x3d` | AM5 · 6N/12T · 65 W | US$ 249.99 |
| AMD Ryzen 5 7600X | `ryzen_5_7600x` | AM5 · 6N/12T · 105 W | US$ 138.52 |
| AMD Ryzen 5 5600 | `ryzen_5_5600` | AM4 · 6N/12T · 65 W | US$ 92.49 |
| Intel Core Ultra 7 270K Plus | `core_ultra_7_270k_plus` | LGA1851 · 24N/24T · 125 W | US$ 319.99 |
| Intel Core Ultra 5 250K Plus | `core_ultra_5_250k_plus` | LGA1851 · 18N/18T · 125 W | US$ 219.99 |
| Intel Core i7-14700K | `core_i7_14700k` | LGA1700 · 20N/28T · 125 W | US$ 360.00 |
| AMD Ryzen 5 9600X | `ryzen_5_9600x` | AM5 · 6N/12T · 65 W | US$ 170.00 |
| AMD Ryzen 9 9900X | `ryzen_9_9900x` | AM5 · 12N/24T · 120 W | US$ 335.00 |
| AMD Ryzen 9 9950X3D | `ryzen_9_9950x3d` | AM5 · 16N/32T · 170 W | US$ 569.00 |
| AMD Ryzen 5 8600G | `ryzen_5_8600g` | AM5 · 6N/12T · 65 W | US$ 191.00 |
| AMD Ryzen 9 5900XT | `ryzen_9_5900xt` | AM4 · 16N/32T · 105 W | US$ 311.00 |
| AMD Ryzen 7 5800X3D 10th Anniversary | `ryzen_7_5800x3d` | AM4 · 8N/16T · 105 W | US$ 349.00 |
| Intel Core Ultra 9 285K | `core_ultra_9_285k` | LGA1851 · 24N/24T · 125 W | US$ 495.00 |
| Intel Core i9-14900K | `core_i9_14900k` | LGA1700 · 24N/32T · 125 W | US$ 469.99 |
| Intel Core i7-14700KF | `core_i7_14700kf` | LGA1700 · 20N/28T · 125 W | US$ 275.00 |

## Placas de vídeo (15)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| NVIDIA GeForce RTX 5050 | `rtx_5050` | 8GB GDDR6 · 130 W · fonte rec. ~550 W · PCIe8 · ~200 mm | US$ 309.00 (MSRP 250) |
| NVIDIA GeForce RTX 5060 | `rtx_5060` | 8GB GDDR7 · 145 W · fonte rec. ~550 W · PCIe8 · ~200 mm | US$ 369.00 (MSRP 300) |
| NVIDIA GeForce RTX 5070 | `rtx_5070` | 12GB GDDR7 · 250 W · fonte rec. ~650 W · 12V2x6 · ~242 mm | US$ 659.00 (MSRP 550) |
| NVIDIA GeForce RTX 5070 Ti | `rtx_5070_ti` | 16GB GDDR7 · 300 W · fonte rec. ~750 W · 12V2x6 · ~305 mm | US$ 1,099.00 (MSRP 750) |
| NVIDIA GeForce RTX 5080 | `rtx_5080` | 16GB GDDR7 · 360 W · fonte rec. ~850 W · 12V2x6 · ~304 mm | US$ 999.99 (MSRP) |
| NVIDIA GeForce RTX 5090 | `rtx_5090` | 32GB GDDR7 · 575 W · fonte rec. ~1000 W · 12V2x6 · ~304 mm | US$ 4,299.00 (MSRP 2,000) |
| AMD Radeon RX 9060 XT 16GB | `rx_9060_xt_16gb` | 16GB GDDR6 · 160 W · fonte rec. ~450 W · PCIe8 · ~240 mm | US$ 464.00 (MSRP 350) |
| AMD Radeon RX 9070 | `rx_9070` | 16GB GDDR6 · 220 W · fonte rec. ~650 W · PCIe8 · ~280 mm | US$ 634.00 (MSRP 550) |
| AMD Radeon RX 9070 XT | `rx_9070_xt` | 16GB GDDR6 · 304 W · fonte rec. ~750 W · PCIe8 · ~305 mm | US$ 759.00 (MSRP 600) |
| NVIDIA GeForce RTX 5060 Ti 16GB | `rtx_5060_ti_16gb` | 16GB GDDR7 · 180 W · fonte rec. ~550 W · PCIe8 · ~220 mm | US$ 429.99 (MSRP) |
| NVIDIA GeForce RTX 5060 Ti 8GB | `rtx_5060_ti_8gb` | 8GB GDDR7 · 180 W · fonte rec. ~550 W · PCIe8 · ~220 mm | US$ 379.99 (MSRP) |
| AMD Radeon RX 9070 GRE | `rx_9070_gre` | 12GB GDDR6 · 220 W · fonte rec. ~650 W · PCIe8 · ~280 mm | US$ 549.99 (MSRP) |
| AMD Radeon RX 9060 XT 8GB | `rx_9060_xt_8gb` | 8GB GDDR6 · 150 W · fonte rec. ~450 W · PCIe8 · ~240 mm | US$ 299.99 (MSRP) |
| Intel Arc B580 | `arc_b580` | 12GB GDDR6 · 190 W · fonte rec. ~600 W · PCIe8 · ~272 mm | US$ 249.99 (MSRP) |
| Intel Arc B570 | `arc_b570` | 10GB GDDR6 · 150 W · fonte rec. ~500 W · PCIe8 · ~250 mm | US$ 219.99 (MSRP) |

## Placas-mãe (13)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| MSI MAG B850 Tomahawk WiFi II | `msi_b850_tomahawk_wifi_ii` | AM5 · DDR5 · ATX · 4 slots RAM | US$ 229.99 |
| Gigabyte B650 Aorus Elite AX | `gigabyte_b650_aorus_elite_ax` | AM5 · DDR5 · ATX · 4 slots RAM | US$ 149.99 |
| ASRock B850I Lightning | `asrock_b850i_lightning` | AM5 · DDR5 · MiniITX · 2 slots RAM | US$ 200.00 |
| Gigabyte X870E Aero X3D Wood | `gigabyte_x870e_aero_x3d` | AM5 · DDR5 · ATX · 4 slots RAM | US$ 499.99 |
| ASUS Prime Z890-P WiFi | `asus_prime_z890_p_wifi` | LGA1851 · DDR5 · ATX · 4 slots RAM | US$ 199.99 |
| MSI MAG B860 Tomahawk WiFi | `msi_b860_tomahawk_wifi` | LGA1851 · DDR5 · ATX · 4 slots RAM | US$ 229.99 |
| ASRock Z790 Taichi Lite | `asrock_z790_taichi_lite` | LGA1700 · DDR5 · EATX · 4 slots RAM | US$ 350.00 |
| ASUS ROG Strix B550-F Gaming | `asus_strix_b550_f` | AM4 · DDR4 · ATX · 4 slots RAM | US$ 240.00 |
| Placa B550M genérica | `b550m` | AM4 · DDR4 · MicroATX · 2 slots RAM | — |
| MSI MAG B850M Mortar WiFi | `msi_b850m_mortar_wifi` | AM5 · DDR5 · MicroATX · 4 slots RAM | — |
| ASUS TUF Gaming B850M-Plus WiFi | `asus_tuf_b850m_plus_wifi` | AM5 · DDR5 · MicroATX · 4 slots RAM | — |
| Gigabyte B860M Aorus Elite WiFi6E | `gigabyte_b860m_aorus_elite_wifi6e` | LGA1851 · DDR5 · MicroATX · 4 slots RAM | — |
| ASRock B550M Pro4 | `asrock_b550m_pro4` | AM4 · DDR4 · MicroATX · 4 slots RAM | — |

## Memória RAM (8)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| Corsair Vengeance RGB 32GB (2x16) DDR5-6000 CL36 | `corsair_vengeance_rgb_32gb_ddr5_6000` | 2x16 GB · 6000 MT/s CL36 | US$ 439.99 |
| Klevv 32GB (2x16) DDR5-6000 CL30 | `klevv_32gb_ddr5_6000_cl30` | 2x16 GB · 6000 MT/s CL30 | US$ 472.99 |
| G.Skill Flare X5 64GB (2x32) DDR5-6000 CL36 | `gskill_flare_x5_64gb_ddr5_6000` | 2x32 GB · 6000 MT/s CL36 | US$ 1,079.99 |
| Kingston Fury Renegade 96GB (2x48) DDR5-6000 CL32 | `kingston_fury_renegade_96gb_ddr5_6000` | 2x48 GB · 6000 MT/s CL32 | US$ 1,899.99 |
| Kit 16GB (2x8) DDR4-3200 | `16gb_ddr4_3200` | 2x8 GB · 3200 MT/s CL16 | — |
| Kingston Fury Beast 32GB (2x16) DDR5-6000 CL30 | `kingston_fury_beast_32gb_ddr5_6000` | 2x16 GB · 6000 MT/s CL30 | — |
| Crucial Pro 32GB (2x16) DDR5-5600 CL46 | `crucial_pro_32gb_ddr5_5600` | 2x16 GB · 5600 MT/s CL46 | — |
| Corsair Vengeance LPX 32GB (2x16) DDR4-3600 CL18 | `corsair_vengeance_lpx_32gb_ddr4_3600` | 2x16 GB · 3600 MT/s CL18 | — |

## SSDs (8)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| Samsung 990 Pro 2TB | `samsung_990_pro_2tb` | 2 TB · PCIe 4.0 NVMe | US$ 388.95 |
| WD Black SN850X 2TB | `wd_black_sn850x_2tb` | 2 TB · PCIe 4.0 NVMe | US$ 338.52 |
| Lexar NM1090 Pro 2TB | `lexar_nm1090_pro_2tb` | 2 TB · PCIe 5.0 NVMe | US$ 359.79 |
| Biwin NV7400 2TB | `biwin_nv7400_2tb` | 2 TB · PCIe 4.0 NVMe | — |
| SSD NVMe 1TB genérico | `ssd_nvme_1tb` | 1 TB · PCIe 4.0 NVMe | — |
| WD Black SN8100 2TB | `wd_black_sn8100_2tb` | 2 TB · PCIe 5.0 NVMe | US$ 290.00 |
| Samsung 9100 Pro 2TB | `samsung_9100_pro_2tb` | 2 TB · PCIe 5.0 NVMe | US$ 680.00 |
| Crucial T710 4TB | `crucial_t710_4tb` | 4 TB · PCIe 5.0 NVMe | US$ 725.00 |

## Fontes (14)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| be quiet! Pure Power 13 M 650W | `bequiet_pure_power_13m_650w` | 650 W · 80 Plus Gold · 12V-2x6: sim | US$ 100.00 |
| be quiet! Straight Power 12 750W | `bequiet_straight_power_12_750w` | 750 W · 80 Plus Gold · 12V-2x6: sim | US$ 99.90 |
| Cooler Master MWE Gold 850 V3 | `coolermaster_mwe_gold_850_v3` | 850 W · 80 Plus Gold · 12V-2x6: não | US$ 109.99 |
| be quiet! Dark Power 13 1000W | `bequiet_dark_power_13_1000w` | 1000 W · 80 Plus Titanium · 12V-2x6: sim | US$ 219.90 |
| Lian Li RS1200G | `lianli_rs1200g` | 1200 W · 80 Plus Gold · 12V-2x6: sim | US$ 184.99 |
| Fonte 650W 80 Plus genérica | `psu_650w_80plus` | 650 W · 80 Plus · 12V-2x6: não | — |
| Corsair RM850x | `corsair_rm850x` | 850 W · Cybenetics Gold · 12V-2x6: sim | — |
| Corsair RM1000x | `corsair_rm1000x` | 1000 W · Cybenetics Gold · 12V-2x6: sim | — |
| Seasonic Focus GX-850 | `seasonic_focus_gx_850` | 850 W · 80 Plus Gold · 12V-2x6: sim | — |
| ASRock PRO-650G | `asrock_pro_650g` | 650 W · 80 Plus Gold · 12V-2x6: não | — |
| Corsair SF750 (2024) SFX | `corsair_sf750_2024` | 750 W · 80 Plus Platinum · 12V-2x6: sim | US$ 154.99 |
| Corsair SF850 (2024) SFX | `corsair_sf850_2024` | 850 W · 80 Plus Platinum · 12V-2x6: sim | — |
| NZXT C1500 Platinum | `nzxt_c1500_platinum` | 1500 W · 80 Plus Platinum · 12V-2x6: sim | US$ 329.99 |
| MSI MPG Ai1600TS | `msi_mpg_ai1600ts` | 1600 W · 80 Plus Titanium · 12V-2x6: sim | — |

## Gabinetes (16)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| Fractal Design North | `fractal_north` | ATX, MicroATX, MiniITX · GPU até 356 mm | US$ 130.00 |
| Lian Li Lancool 207 Digital | `lianli_lancool_207_digital` | ATX, MicroATX, MiniITX · GPU até 375 mm | US$ 105.00 |
| Phanteks XT Pro Ultra | `phanteks_xt_pro_ultra` | ATX, MicroATX, MiniITX, EATX · GPU até 415 mm | US$ 80.00 |
| NZXT H9 Flow (2025) | `nzxt_h9_flow_2025` | ATX, MicroATX, MiniITX, EATX · GPU até 459 mm | US$ 169.00 |
| Corsair 2500D Airflow | `corsair_2500d_airflow` | MicroATX, MiniITX · GPU até 400 mm | US$ 159.00 |
| Fractal Design Terra | `fractal_terra` | MiniITX · GPU até 322 mm | US$ 180.00 |
| Gabinete Mid-Tower ATX genérico | `case_midtower_atx` | ATX, MicroATX, MiniITX · GPU até 330 mm | — |
| Corsair 3200D | `corsair_3200d` | ATX, MicroATX, MiniITX · GPU até ~400 mm | US$ 75.00 |
| Thermaltake View 380 | `thermaltake_view_380` | ATX, MicroATX, MiniITX · GPU até ~400 mm | US$ 120.00 |
| Thermaltake S100 TG | `thermaltake_s100_tg` | MicroATX, MiniITX · GPU até 330 mm | US$ 89.00 |
| NZXT H3 Flow | `nzxt_h3_flow` | MicroATX, MiniITX · GPU até 377 mm | US$ 50.00 |
| NZXT H7 Flow | `nzxt_h7_flow` | ATX, MicroATX, MiniITX, EATX · GPU até ~400 mm | US$ 100.00 |
| Lian Li Lancool 217 | `lianli_lancool_217` | ATX, MicroATX, MiniITX, EATX · GPU até ~400 mm | US$ 125.00 |
| Hyte X50 | `hyte_x50` | ATX, MicroATX, MiniITX, EATX · GPU até 430 mm | US$ 160.00 |
| Cooler Master HAF II 500 | `coolermaster_haf_ii_500` | ATX, MicroATX, MiniITX, EATX · GPU até 430 mm | US$ 200.00 |
| Fractal Design Meshify 2 | `fractal_meshify_2` | ATX, MicroATX, MiniITX, EATX · GPU até 467 mm | — |

## Ventoinhas (3)

| Peça | ID no jogo | Detalhes | Preço ref. |
|---|---|---|---|
| Ventoinha 120mm | `fan_120mm` | 120 mm · 2 W | — |
| Arctic P12 Pro 120mm | `arctic_p12_pro` | 120 mm · 4 W | US$ 8.50 |
| Noctua NF-A12x25 G2 120mm | `noctua_nf_a12x25_g2` | 120 mm · 2 W | US$ 35.00 |

## Builds prontas para testar (14)

Em `Tools/MockServer/builds/`. Use com o mock ou com `PC.LoadBuildFile`. Todas conferidas com as mesmas regras do jogo.

| Build | Resultado | Resumo |
|---|---|---|
| `build_2026_am4_economica` | Compatível | Ryzen 5 5600 · RX 9060 XT 8GB · DDR4 |
| `build_2026_criador` | Compatível | Ryzen 9 9950X3D · RTX 5080 · 96 GB |
| `build_2026_custo_beneficio` | Compatível | Ryzen 7 9700X · RX 9060 XT 16GB |
| `build_2026_entusiasta` | Compatível | Ryzen 9 9950X3D2 · RTX 5090 · 1200 W |
| `build_2026_gamer` | Compatível | Ryzen 7 9800X3D · RTX 5070 Ti |
| `build_2026_intel` | Compatível | Core Ultra 7 270K Plus · RX 9070 XT |
| `build_2026_intel_arc` | Compatível | Core Ultra 5 250K Plus · Arc B580 · micro-ATX |
| `build_2026_mini_itx` | Compatível | Ryzen 5 7600X3D · RTX 5070 · Terra |
| `build_2026_sff` | Compatível | Ryzen 7 9800X3D · RTX 5070 · fonte SFX |
| `erro_2026_conector_gpu` | Rejeitada (conector da GPU) | RTX 5080 em fonte sem 12V-2x6 |
| `erro_2026_fonte_fraca_5090` | Rejeitada (fonte fraca (1001 W)) | RTX 5090 + 285K precisa de 1001 W, fonte tem 1000 W |
| `erro_2026_gabinete_pequeno` | Rejeitada (form factor) | placa ATX em gabinete micro-ATX |
| `erro_2026_ram_ddr4_em_am5` | Rejeitada (geração de RAM) | RAM DDR4 em placa DDR5 |
| `erro_2026_soquete_errado` | Rejeitada (soquete) | CPU AMD em placa Intel |

## Simplificações de jogo

- Consumo da CPU = TDP/potência base oficial (os Intel K passam disso em turbo, ~250 W).
- Placa-mãe ~45–50 W, RAM ~10 W, SSD 8–10 W: estimativas.
- Comprimento de GPU e fonte recomendada são aproximados (variam por fabricante); os marcados com "~" no gabinete também.
- "Preço não verificado": modelo real e atual, mas sem preço confirmado nas fontes desta pesquisa.
- GPUs AMD usam 2x 8 pinos; o jogo registra o tipo de conector, não a quantidade.

## Fontes

- [Tom's Hardware: Best CPUs](https://www.tomshardware.com/reviews/best-cpus,3986.html) · [ThirstyBear: Best CPUs](https://www.thirstybear.com/best-cpus/)
- [Tom's Hardware: Best GPUs](https://www.tomshardware.com/reviews/best-gpus,4380.html) · [GPU Hierarchy](https://www.tomshardware.com/reviews/gpu-hierarchy,4388.html)
- [Wikipedia: GeForce RTX 50](https://en.wikipedia.org/wiki/GeForce_RTX_50_series) · [Radeon RX 9000](https://en.wikipedia.org/wiki/Radeon_RX_9000_series)
- [Tom's Hardware: Best Motherboards](https://www.tomshardware.com/best-picks/best-motherboards)
- [TechFuelHQ: DDR5 2026](https://techfuelhq.com/articles/ddr5-ram-buying-guide-2025/)
- [Tom's Hardware: Best SSDs](https://www.tomshardware.com/reviews/best-ssds,3891.html) · [Tech Insider: SN8100 vs 9100 Pro](https://tech-insider.org/wd-black-sn8100-vs-samsung-9100-pro-2026/)
- [Tom's Hardware: Best PSUs](https://www.tomshardware.com/reviews/best-psus,4229.html) · [Newegg: Best PSUs 2026](https://www.newegg.com/insider/best-power-supplies-in-2026-for-every-build)
- [Tom's Hardware: Best PC Cases](https://www.tomshardware.com/reviews/best-pc-cases,4183.html) · [PC Gamer: Best PC Case](https://www.pcgamer.com/best-pc-case/)
- [Tom's Hardware: Arctic P12 Pro vs Noctua G2](https://www.tomshardware.com/pc-components/case-fans/pc-fan-faceoff-can-arctics-usd7-p12-pro-compete-with-the-usd40-noctua-nf-a12x25-g2)
- [DropReference: Zen 6](https://dropreference.com/en/blog/news/amd-zen-6-announcement-july-2026-upcoming-build) · [Wikipedia: Nova Lake](https://en.wikipedia.org/wiki/Nova_Lake_(microprocessor))
