# Contracts.md: contratos v1

Fonte única dos contratos entre o servidor e o jogo, e entre as camadas do jogo.
Extraído de `Architecture.md` §6. Schema formal da build: [`Schemas/build.v1.schema.json`](Schemas/build.v1.schema.json).
Mudar qualquer item aqui exige incrementar `version` (envelope) ou `schemaVersion` (build).

## Contratos v1


### 6.1 Envelope WebSocket, protocolo v1

```json
{
  "type": "build.deliver",
  "version": 1,
  "requestId": "3f1c2a9e-8d4b-4c7a-9e21-5b6d0f7a1c33",
  "timestamp": 1790000000,
  "payload": { }
}
```

| Campo | Tipo | Regra |
|---|---|---|
| `type` | string | Um dos tipos da tabela abaixo. Desconhecido → `NetworkError.ProtocolViolation` (log `Warning`, mensagem descartada, conexão mantida). |
| `version` | int | Versão do **protocolo** (envelope). ≠ 1 → `ProtocolViolation`. É independente do `schemaVersion` da build. |
| `requestId` | string | UUID em formato canônico lowercase `8-4-4-4-12`. Respostas ecoam o `requestId` da requisição. |
| `timestamp` | int64 | Unix epoch **segundos** UTC. Informativo, nunca usado para lógica. |
| `payload` | object | Obrigatório (pode ser `{}`). |

Limites: mensagem > **64 KiB** → `ProtocolViolation` e fechamento com código 1009. Codificação UTF-8.

| `type` | Direção | `payload` |
|---|---|---|
| `connection.hello` | C→S após conectar | `{ "clientVersion": "0.1.0", "protocolVersion": 1, "supportedSchemaVersions": [1] }` |
| `connection.hello` | S→C resposta | `{ "serverVersion": "x.y.z", "sessionId": "uuid" }`. Só depois dele a conexão é `Ready` e o backoff zera. |
| `build.deliver` | S→C | Build (§6.2) |
| `build.ack` | C→S | `{ "buildId": "uuid", "status": "accepted" }` |
| `build.error` | C→S | `{ "buildId": "uuid\|null", "code": "BuildError.UnknownComponentId", "detail": "texto técnico, não localizado", "field": "components.Component.GPU" }` |
| `ping` | ambos | `{}`. O cliente envia a cada **15 s** de silêncio. |
| `pong` | ambos | `{}`, ecoando o `requestId` do ping. Sem pong em **10 s** → `NetworkError.Timeout` → fecha e reconecta. |

**Reconexão:** 1 s → 2 s → 4 s → 8 s → 16 s → 30 s → 30 s… (teto 30 s, sem jitter: cliente único). Zera após `connection.hello` do servidor.

**Mapeamento de estados de conexão:** `Disconnected → Connecting → Handshaking → Ready`. Queda em qualquer estado → `NetworkError.Disconnected` → `Connecting` (com backoff).

### 6.2 Schema da Build, `schemaVersion: 1`

```json
{
  "schemaVersion": 1,
  "buildId": "a7e0c1d2-3b4f-4a5b-8c6d-7e8f9a0b1c2d",
  "components": {
    "Component.CPU":         "ryzen_5_5600",
    "Component.GPU":         "rx_7600",
    "Component.Motherboard": "b550m",
    "Component.RAM":         "16gb_ddr4_3200",
    "Component.Storage":     "ssd_nvme_1tb",
    "Component.PSU":         "psu_650w_80plus",
    "Component.Case":        "case_midtower_atx"
  }
}
```

**Ordem de validação (determinística; o primeiro erro vence e é o que vai no `build.error`):**

| # | Verificação | Erro |
|---|---|---|
| 1 | JSON sintaticamente válido | `BuildError.MalformedJson` |
| 2 | `schemaVersion` presente e inteiro | `BuildError.MissingField` / `InvalidFieldValue` |
| 3 | `schemaVersion == 1` (valores maiores = schema futuro) | `BuildError.SchemaVersionUnsupported` |
| 4 | `buildId` presente, UUID válido | `MissingField` / `InvalidFieldValue` |
| 5 | *(receiver, antes do catálogo)* `buildId` já aceito nesta sessão | `BuildError.DuplicateBuild` |
| 6 | `components` presente, objeto não vazio, ≤ 32 entradas | `MissingField` / `InvalidFieldValue` |
| 7 | Nenhuma chave repetida em `components` (varredura de tokens) | `BuildError.DuplicateComponentTag` |
| 8 | Cada chave é uma tag registrada e filha de `Component` | `BuildError.UnknownComponentTag` |
| 9 | Cada valor é uma string que casa `^[a-z0-9_]{1,64}$` | `BuildError.InvalidFieldValue` |
| 10 | Tipos obrigatórios v1 presentes: CPU, GPU, Motherboard, RAM, Storage, PSU, Case | `BuildError.MissingRequiredComponent` |
| 11 | *(receiver)* O ID existe no catálogo | `BuildError.UnknownComponentId` |
| 12 | *(receiver)* O `Type` do DataAsset == chave | `BuildError.ComponentTypeMismatch` |
| 13 | *(receiver)* A carga assíncrona do asset teve sucesso | `BuildError.AssetNotFound` |
| 14 | *(receiver)* A compatibilidade de build passa (D5) | `BuildError.IncompatibleBuild` |

Campos extras desconhecidos no nível raiz são **ignorados com `Verbose`** (compatibilidade futura). `Component.Fan` e `Component.Cable` são opcionais: se ausentes, valem os padrões do gabinete.

O schema formal fica em `/Docs/Schemas/build.v1.schema.json` (JSON Schema 2020-12) para o time do servidor. O jogo **não** usa biblioteca de JSON Schema (terceiros proibidos): o validador C++ espelha o schema, e os testes garantem a paridade.

### 6.3 Taxonomia de erros (códigos estáveis)

Os códigos marcados **(novo)** vêm da auditoria. Todos são GameplayTags se D3 for aprovada. A mensagem ao jogador vem da String Table `ST_PlayerMessages[<código>]`.

| Código | Origem | Quando | Visível ao jogador |
|---|---|---|---|
| `BuildError.None` | — | Sucesso (em C++ = `FGameplayTag` vazia; nunca é enviado no fio) | — |
| `BuildError.SchemaVersionUnsupported` | Parser | `schemaVersion` ≠ 1 | Sim |
| `BuildError.MalformedJson` | Parser | Sintaxe inválida | Sim (genérico) |
| `BuildError.MissingField` | Parser | Campo raiz ausente | Sim (genérico) |
| `BuildError.InvalidFieldValue` **(novo)** | Parser | Tipo ou formato errado | Sim (genérico) |
| `BuildError.UnknownComponentTag` | Parser | Chave não é `Component.*` registrada | Sim |
| `BuildError.DuplicateComponentTag` **(novo)** | Parser | Chave repetida | Sim (genérico) |
| `BuildError.MissingRequiredComponent` **(novo)** | Parser | Falta um tipo obrigatório | Sim |
| `BuildError.UnknownComponentId` | Catálogo | ID fora do catálogo | Sim |
| `BuildError.ComponentTypeMismatch` **(novo)** | Catálogo | ID existe, mas é de outro tipo | Sim |
| `BuildError.AssetNotFound` | Catálogo/carga | Soft pointer quebrado | Sim (genérico) |
| `BuildError.IncompatibleBuild` **(novo)** | Compatibilidade | A build viola uma regra (D5) | Sim, com o motivo da regra |
| `BuildError.DuplicateBuild` | Receiver | `buildId` repetido | Não (só log) |
| `BuildError.InvalidState` **(novo)** | Receiver | Build chegou fora de `WaitingForBuild` | Não (só log) |
| `AssemblyError.SlotOccupied` | Slot | O slot já tem componente | Sim |
| `AssemblyError.SlotMismatch` | Slot | Tipo ou socket incompatível com o slot | Sim |
| `AssemblyError.Incompatible` | Regras | Regra cruzada falhou na instalação | Sim, com o motivo |
| `AssemblyError.WrongOrientation` | Slot | Rotação fora da tolerância (padrão 5°) | Sim |
| `AssemblyError.OutOfRange` | Slot | O componente está a mais de `SnapRadius` do slot | Sim |
| `AssemblyError.MissingPrerequisite` **(novo)** | Slot | Ex.: GPU antes da placa-mãe estar no gabinete, fechar o gabinete sem cabos | Sim |
| `NetworkError.Timeout` | Rede | Sem pong/hello no prazo | Indicador de conexão |
| `NetworkError.Disconnected` | Rede | Socket caiu | Indicador de conexão |
| `NetworkError.ProtocolViolation` | Rede | Envelope inválido ou muito grande | Não (só log) |

**Divisão de responsabilidade (sem duplicar a fonte da verdade):**
- **Slot** = verificação física e local (tipo, socket, ocupação, orientação, alcance, pré-requisito) → `AssemblyError.*` exceto `Incompatible`.
- **Regras** = relação entre componentes (TDP/watts, form factor, geração de RAM, comprimento da GPU) → `AssemblyError.Incompatible` na instalação, `BuildError.IncompatibleBuild` na entrega. As mesmas regras rodam nos dois portões.

### 6.4 Interfaces e tipos de contrato C++ (assinaturas, não implementação)

```cpp
// Build/IPCBuildReceiver.h — interface nativa pura (sem UINTERFACE): usada só para
// injetar dublês nos testes do GameMode; não precisa de reflexão.
class IPCBuildReceiver
{
public:
    virtual void OnBuildReceived(const FBuildConfiguration& Build) = 0;
    virtual void OnBuildRejected(FGameplayTag ErrorCode, const FString& Detail) = 0; // D3
    virtual ~IPCBuildReceiver() = default;
};

// Compatibility/PCBuildContext.h
USTRUCT()
struct FPCBuildContext
{
    GENERATED_BODY()
    // Componentes considerados (instalados + candidato), já carregados.
    // Ponteiros não-const: o UHT não aceita TObjectPtr<const T> em UPROPERTY.
    // A imutabilidade vem do acesso const em UPCCompatibilityRule::Evaluate.
    UPROPERTY() TMap<FGameplayTag, TObjectPtr<UPCComponentDataAsset>> Components;
    // Preenchidos apenas na validação de instalação.
    UPROPERTY() TObjectPtr<UPCComponentDataAsset> Candidate = nullptr;
    UPROPERTY() FGameplayTag TargetSlot;
};

// Compatibility/PCCompatibilityRule.h — D2: UObject abstrato em vez de UINTERFACE.
UCLASS(Abstract, EditInlineNew, DefaultToInstanced, CollapseCategories)
class UPCCompatibilityRule : public UObject
{
    GENERATED_BODY()
public:
    // true = compatível OU regra não aplicável (componentes relevantes ausentes).
    virtual bool Evaluate(const FPCBuildContext& Context, FCompatibilityResult& Out) const
        PURE_VIRTUAL(UPCCompatibilityRule::Evaluate, return true;);
};

// Compatibility/PCCompatibilityRuleSet.h
UCLASS()
class UPCCompatibilityRuleSet : public UPrimaryDataAsset
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, Instanced) TArray<TObjectPtr<UPCCompatibilityRule>> Rules;
};
```

`FCompatibilityResult::ErrorCode` passa de `FName` para `FGameplayTag` (D3). Regras v1: `UPCCPUSocketRule`, `UPCRAMGenerationRule`, `UPCGPUSlotRule`, `UPCPSUWattageRule` e as novas `UPCFormFactorRule` e `UPCGPULengthRule`. **Adicionar uma regra** = uma subclasse nova + uma entrada no RuleSet. `UPCCompatibilitySystem` não muda (há teste para isso).

### 6.5 Slot

`UPCAssemblySlotComponent : USceneComponent`, anexado ao gabinete ou à placa-mãe. Não é `UObject` solto nem `AActor`.

| Propriedade | Tipo | Nota |
|---|---|---|
| `SlotTag` | `FGameplayTag` (`Slot.*`) | Identidade. |
| `AllowedTypes` | `FGameplayTagContainer` (`Component.*`) | |
| `RequiredSocket` | `FGameplayTag` (`Socket.*`) | **Preenchido em runtime a partir do DataAsset do dono** (ex.: o slot CPU herda `CpuSocket` da placa-mãe). Um BP de placa serve AM4, AM5 e LGA1700. Inválido = sem restrição de socket. |
| `Prerequisites` | `FGameplayTagContainer` (`Slot.*`) | Slots que precisam estar ocupados antes. |
| `SnapRadius` | `float` (cm) | Padrão 8 cm. |
| `AllowedYawOffsets` | `TArray<float>` | Orientações válidas (ex.: RAM = {0}, ventoinha = {0, 180}). |
| `IsOccupied()` / `GetOccupant()` | | O ocupante é `TWeakObjectPtr<AComputerComponent>`. |

A detecção de proximidade usa um `USphereComponent` filho com canal próprio. Não usa Tick: `OnComponentBeginOverlap/EndOverlap`.

### 6.6 Catálogo de eventos (delegates públicos)

| Emissor | Delegate | Assinatura |
|---|---|---|
| NetworkManager | `OnConnectionStateChanged` | `(EPCConnectionState Old, EPCConnectionState New)` |
| NetworkManager | `OnMessageReceived` | `(FName Type, const FString& RequestId, TSharedRef<FJsonObject> Payload)`. Delegate nativo `DECLARE_MULTICAST_DELEGATE_ThreeParams`, porque `TSharedRef<FJsonObject>` não é tipo de reflexão. **Exceção justificada ao "dynamic"**. |
| NetworkManager | `OnNetworkError` | `(FGameplayTag Code, const FString& Detail)` |
| BuildReceiver | `OnBuildAccepted` / `OnBuildRejected` | `(const FBuildConfiguration&)` / `(FGameplayTag, const FString&)` |
| BuildSpawner | `OnBuildSpawned` | `(const TArray<AComputerComponent*>&)` |
| AssemblySystem | `OnPickedUp`, `OnDropped`, `OnInstalled`, `OnRemoved` | `(AComputerComponent*, UPCAssemblySlotComponent*)` |
| AssemblySystem | `OnInstallFailed` | `(AComputerComponent*, FGameplayTag Code, FText Reason)` |
| ProgressTracker | `OnProgressChanged` | `(int32 Done, int32 Total)` |
| ProgressTracker | `OnAllRequirementsMet` | `()` |
| PowerSystem | `OnPowerSequenceStarted`, `OnBootCompleted`, `OnPowerFailed` | `()` / `()` / `(FGameplayTag)` |
| GameMode | `OnGameStateChanged` | `(EPCGameState Old, EPCGameState New)` |
| AnimNotify | `OnInstallationAnimCompleted` | `(AComputerComponent*)` |

---

